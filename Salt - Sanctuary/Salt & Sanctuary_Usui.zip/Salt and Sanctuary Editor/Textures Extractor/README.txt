﻿• This package includes XNBNode 0.2.1 by Draivin

1. Put .xnb files in folder "Packed";
2. Run "UnpackFiles.bat";
3. Edit texture (.png) from folder "Unpacked";
4. Run "PackFiles.bat";
5. Take edited xnb from folder "Packed";

Tip: Befor pack png to xnb need a little blur (Gaussian Blur in Photoshop: 0,4 pixels)