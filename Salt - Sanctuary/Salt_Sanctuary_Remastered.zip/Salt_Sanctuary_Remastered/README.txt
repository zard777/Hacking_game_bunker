Salt and Sanctuary Edtior by Usui

1) Copy dialog.zdx, loot.zlx, monsters.zox, skilltree.zsx, strings.ztx from game to packed folder
2) Run unpack.bat
3) Edit .xml files in unpacked folder
4) Run pack.bat
5) Copy dialog.zdx, loot.zlx, monsters.zox, skilltree.zsx, strings.ztx from packed to game folder