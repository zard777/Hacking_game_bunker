﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x020000B4 RID: 180
	public class SaltStatue
	{

		// Token: 0x06000462 RID: 1122 RVA: 0x000845DA File Offset: 0x000827DA
		public SaltStatue()
		{
			this.exists = false;
		}


		// Token: 0x06000466 RID: 1126 RVA: 0x00084A8B File Offset: 0x00082C8B
		internal void Write(BinaryWriter writer)
		{
			writer.Write(this.loc.X);
			writer.Write(this.loc.Y);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00084AAF File Offset: 0x00082CAF
		internal void Read(BinaryReader reader)
		{
			this.loc = new Vector2(reader.ReadSingle(), reader.ReadSingle());
			this.exists = true;
		}

		// Token: 0x040010BF RID: 4287
		private const int W = 200;

		// Token: 0x040010C0 RID: 4288
		private const float Y_PLAT = 20f;


		// Token: 0x040010C2 RID: 4290
		public Vector2 loc;

		// Token: 0x040010C3 RID: 4291
		public bool exists;

		// Token: 0x040010C4 RID: 4292
		public float frame;

		// Token: 0x040010C5 RID: 4293
		public int salt;

		// Token: 0x040010C6 RID: 4294
		public float destroyFrame;
	}
}
