﻿using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x02000189 RID: 393
	internal class ChallengeCatLoadout : ChallengeCategory
	{
		// Token: 0x060007D7 RID: 2007 RVA: 0x000B67FC File Offset: 0x000B49FC
		public ChallengeCatLoadout(Player p)
		{
			this.itemStr = new StringBuilder[]
			{
				new StringBuilder(LocStrings.GetLocStr(427)),
				new StringBuilder(LocStrings.GetLocStr(428)),
				new StringBuilder(LocStrings.GetLocStr(429))
			};
			base.Init(p);
		}

		// Token: 0x04001221 RID: 4641
		public const int MAGIC_ONLY = 0;

		// Token: 0x04001222 RID: 4642
		public const int IRON_POT_ONLY = 1;

		// Token: 0x04001223 RID: 4643
		public const int OAR_ONLY = 2;
	}
}
