﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x020001CF RID: 463
	public class PlayerBeasts
	{
		// Token: 0x060008EF RID: 2287 RVA: 0x000D6A96 File Offset: 0x000D4C96
		public PlayerBeasts(Player player)
		{
			this.player = player;
			this.playerBeast = new Dictionary<string, PlayerBeast>();
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x000D6AB0 File Offset: 0x000D4CB0
		public void Write(BinaryWriter writer)
		{
			Dictionary<string, PlayerBeast>.Enumerator enumerator;
			KeyValuePair<string, PlayerBeast> current;
			writer.Write(this.playerBeast.Count);
			enumerator = this.playerBeast.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					current = enumerator.Current;
					writer.Write(current.Key);
					current.Value.Write(writer);
				}
			}
			finally
			{
				((IDisposable)enumerator).Dispose();
			}
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x000D6B28 File Offset: 0x000D4D28
		public void Read(BinaryReader reader)
		{
			int num;
			int i;
			string key;
			PlayerBeast value;
			this.playerBeast = new Dictionary<string, PlayerBeast>();
			num = reader.ReadInt32();
			i = 0;
			while (i < num)
			{
				key = reader.ReadString();
				value = new PlayerBeast(reader);
				this.playerBeast.Add(key, value);
				i = i + 1;
			}
		}


		// Token: 0x060008FA RID: 2298 RVA: 0x000D6DC0 File Offset: 0x000D4FC0
		internal void Reset()
		{
			this.playerBeast = new Dictionary<string, PlayerBeast>();
		}

		// Token: 0x040014F0 RID: 5360
		private Player player;

		// Token: 0x040014F1 RID: 5361
		public Dictionary<string, PlayerBeast> playerBeast;
	}
}
