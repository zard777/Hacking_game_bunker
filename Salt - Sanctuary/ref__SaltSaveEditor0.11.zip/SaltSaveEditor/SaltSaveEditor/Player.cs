﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaltSaveEditor
{
    public class Player
    {

        // Token: 0x06000A87 RID: 2695 RVA: 0x0010155C File Offset: 0x000FF75C
        public Player()
        {
            this.playerInv = new PlayerInv(this);
            this.stats = new PlayerStats(this);
            this.statue = new SaltStatue();
            this.playerBeasts = new PlayerBeasts(this);
            this.challenge = new PlayerChallenges(this);
            this.Reset();
        }


        // Token: 0x06000A8B RID: 2699 RVA: 0x001019A8 File Offset: 0x000FFBA8
        public void GetElapsedTimeStr()
        {
            int num;
            int num2;
            int num3;
            num = (int)(this.elapsedTimeTicks / 10000000L);
            num2 = num / 60;
            num = num % 60;
            num3 = num2 / 60;
            num2 = num2 % 60;
            this.elapsedTimeStr = new StringBuilder(string.Concat(new string[]
            {
                num3.ToString(),
                ":",
                (num2 < 10) ? "0" : "",
                num2.ToString(),
                ":",
                (num < 10) ? "0" : "",
                num.ToString()
            }));
        }


        // Token: 0x06000A8D RID: 2701 RVA: 0x00101A7C File Offset: 0x000FFC7C
        public void Write(BinaryWriter writer)
        {
            long ticks;
            int i;
            int j;
            int k;
            int l;
            int m;
            int n;
            int num;
            int num2;
            int num3;

            writer.Write(29);
            writer.Write(this.name);
            writer.Write(this.hardcore);
            writer.Write(this.kills);
            writer.Write(this.deaths);
            writer.Write(this.sanctuaryRestCount);
            writer.Write(this.corruption);
            writer.Write(this.challengeType);
            ticks = DateTime.UtcNow.Ticks;
            this.elapsedTimeTicks = this.elapsedTimeTicks + (ticks - this.sessionStartTicks);
            this.sessionStartTicks = ticks;
            this.GetElapsedTimeStr();
            writer.Write(this.elapsedTimeTicks);
            writer.Write(this.playthroughNumber);
            writer.Write(this.lastSanctuaryIdx);
            this.currentCreedIdx = -1;
            i = 0;
            while (i < 10)
            {
                if (!(this.creedLevel[i] <= 0))
                {
                    this.currentCreedIdx = i;
                }
                i = i + 1;
            }
            writer.Write(this.currentCreedIdx);
            writer.Write(this.respawnLoc.X);
            writer.Write(this.respawnLoc.Y);
            writer.Write(this.sanctuaryRespawnLoc.X);
            writer.Write(this.sanctuaryRespawnLoc.Y);
            this.stats.Write(writer);
            j = 0;
            while (j < this.creedStanding.Length)
            {
                writer.Write(this.creedStanding[j]);
                j = j + 1;
            }
            k = 0;
            while (k < 10)
            {
                l = 0;
                while (l < 4)
                {
                    writer.Write(this.creedUnlocks[k, l]);
                    l = l + 1;
                }
                k = k + 1;
            }
            m = 0;
            while (m < this.creedLevel.Length)
            {
                writer.Write(this.creedLevel[m]);
                m = m + 1;
            }
            n = 0;
            while (n < this.npcStanding.Length)
            {
                writer.Write(this.npcStanding[n]);
                n = n + 1;
            }
            writer.Write(this.expungedCount);
            writer.Write(this.salt);
            writer.Write(this.gold);
            writer.Write(this.skinIdx);
            writer.Write(this.skinClass);
            writer.Write(this.hair);
            writer.Write(this.hairColor);
            writer.Write(this.beard);
            writer.Write(this.beardColor);
            writer.Write(this.eyeColor);
            this.charEquipment.Write(writer);
            this.playerInv.Write(writer);
            this.playerBeasts.Write(writer);
            this.challenge.WriteFlags();
            writer.Write(this.flags.Count);
            num = 0;
            while (num < this.flags.Count)
            {
                writer.Write(this.flags[num]);
                num = num + 1;
            }
            num2 = 0;
            while (num2 < this.sanctuaryCreed.Length)
            {
                writer.Write(this.sanctuaryCreed[num2]);
                writer.Write(this.sanctuaryVisitCount[num2]);
                num3 = 0;
                while (num3 < 4)
                {
                    writer.Write(this.sanctuaryPilgrim[num2, num3]);
                    num3 = num3 + 1;
                }
                num2 = num2 + 1;
            }
            if (!(this.saltOwnerVec.X == 0f && this.saltOwnerVec.Y == 0f))
            {
                writer.Write(true);
                writer.Write(this.saltTiedUp);
                writer.Write(this.saltOwnerVec.X);
                writer.Write(this.saltOwnerVec.Y);
            }
            else
            {
                writer.Write(false);
            }
            if (!(!this.statue.exists))
            {
                writer.Write(true);
                writer.Write(this.saltStatueVec.X);
                writer.Write(this.saltStatueVec.Y);
                writer.Write(this.saltStatueAnim);
                writer.Write(this.saltStatueKey);
                writer.Write(this.saltStatueFace);
                writer.Write(this.statue.salt);
                return;
            }
            writer.Write(false);
        }

        // Token: 0x06000A8E RID: 2702 RVA: 0x00101E64 File Offset: 0x00100064
        public void Read(BinaryReader reader)
        {
            int i;
            int j;
            int k;
            int l;
            int m;
            int num;
            int n;
            int num2;
            int num3;

            //read int
            this.sessionStartTicks = DateTime.UtcNow.Ticks;
            reader.ReadInt32();
            this.name = reader.ReadString();
            this.hardcore = reader.ReadBoolean();
            this.kills = reader.ReadInt32();
            this.deaths = reader.ReadInt32();
            this.sanctuaryRestCount = reader.ReadInt32();
            this.corruption = reader.ReadInt32();
            this.challengeType = reader.ReadInt32();
            this.elapsedTimeTicks = reader.ReadInt64();
            this.playthroughNumber = reader.ReadInt32();
            this.lastSanctuaryIdx = reader.ReadInt32();
            this.currentCreedIdx = reader.ReadInt32();
           // Sanctuary s = SanctuaryMgr.sanctuaries[30];
            //Console.WriteLine(ToHexString(s.loc.X) + " " + ToHexString(s.loc.Y));
            this.GetElapsedTimeStr();
            this.respawnLoc = new Vector2(reader.ReadSingle(), reader.ReadSingle());
            this.sanctuaryRespawnLoc = new Vector2(reader.ReadSingle(), reader.ReadSingle());
            this.stats.Read(reader);
            i = 0;
            while (i < this.creedStanding.Length)
            {
                this.creedStanding[i] = reader.ReadInt32();
                i = i + 1;
            }
            j = 0;
            while (j < 10)
            {
                k = 0;
                while (k < 4)
                {
                    this.creedUnlocks[j, k] = reader.ReadInt32();
                    k = k + 1;
                }
                j = j + 1;
            }
            l = 0;
            while (l < this.creedLevel.Length)
            {
                this.creedLevel[l] = reader.ReadInt32();
                l = l + 1;
            }
            m = 0;
            while (m < this.npcStanding.Length)
            {
                this.npcStanding[m] = reader.ReadInt32();
                m = m + 1;
            }
            this.expungedCount = reader.ReadInt32();
            this.salt = reader.ReadInt32();
            this.gold = reader.ReadInt32();
            this.skinIdx = reader.ReadInt32();
            this.skinClass = reader.ReadInt32();
            this.hair = reader.ReadInt32();
            this.hairColor = reader.ReadInt32();
            this.beard = reader.ReadInt32();
            this.beardColor = reader.ReadInt32();
            this.eyeColor = reader.ReadInt32();
            this.charEquipment.Read(reader);
            this.charEquipment.skinIdx = this.skinIdx;
            this.charEquipment.skinClass = this.skinClass;
            this.charEquipment.hair = this.hair;
            this.charEquipment.hairColor = this.hairColor;
            this.charEquipment.beard = this.beard;
            this.charEquipment.beardColor = this.beardColor;
            this.charEquipment.eyeColor = this.eyeColor;
            this.playerInv.Read(reader);
            this.playerBeasts.Read(reader);
            this.flags.Clear();
            num = reader.ReadInt32();
            n = 0;
            while (n < num)
            {
                this.flags.Add(reader.ReadString());
                n = n + 1;
            }
            num2 = 0;
            while (num2 < this.sanctuaryCreed.Length)
            {
                this.sanctuaryCreed[num2] = reader.ReadInt32();
                this.sanctuaryVisitCount[num2] = reader.ReadInt32();
                num3 = 0;
                while (num3 < 4)
                {
                    this.sanctuaryPilgrim[num2, num3] = reader.ReadInt32();
                    num3 = num3 + 1;
                }
                num2 = num2 + 1;
            }
            if (!(!reader.ReadBoolean()))
            {
                this.saltTiedUp = reader.ReadInt32();
                this.saltOwnerVec = new Vector2(reader.ReadSingle(), reader.ReadSingle());
            }
            if (!(!reader.ReadBoolean()))
            {
                this.saltStatueVec = new Vector2(reader.ReadSingle(), reader.ReadSingle());
                this.saltStatueAnim = reader.ReadInt32();
                this.saltStatueKey = reader.ReadInt32();
                this.saltStatueFace = reader.ReadInt32();
                this.statue.salt = reader.ReadInt32();
                this.needsSaltStatue = true;
            }
            else
            {
                this.statue.exists = false;
            }
            this.challenge.ReadFlags();
        }

        
        // Token: 0x06000A9F RID: 2719 RVA: 0x001043DC File Offset: 0x001025DC
        internal void Reset()
        {
            int i;
            int j;
            this.kills = 0;
            this.deaths = 0;
            this.hardcore = false;
            this.sanctuaryRestCount = 0;
            this.corruption = 0;
            this.challengeType = 0;
            this.statue.exists = false;
            this.saltStatueVec = new Vector2(0,0);
            this.saltOwnerVec = new Vector2(0, 0);
            this.saltTiedUp = 0;
            this.lastSanctuaryIdx = -1;
            this.elapsedTimeTicks = 0L;
            this.sessionStartTicks = DateTime.UtcNow.Ticks;
            this.playthroughNumber = 0;
            this.salt = 0;
            this.gold = 0;
            this.playerBeasts.Reset();
            this.needsSaltStatue = false;
            this.runes = new bool[8];
            this.creedStanding = new int[10];
            this.creedLevel = new int[10];
            this.creedUnlocks = new int[10, 4];
            this.sanctuaryCreed = new int[40];
            this.sanctuaryVisitCount = new int[40];
            this.sanctuaryPilgrim = new int[40, 4];
            i = 0;
            while (i < this.sanctuaryCreed.Length)
            {
                this.sanctuaryCreed[i] = 0;
                j = 0;
                while (j < 4)
                {
                    this.sanctuaryPilgrim[i, j] = 0;
                    j = j + 1;
                }
                this.sanctuaryVisitCount[i] = 0;
                i = i + 1;
            }
            this.npcStanding = new int[32];
            this.flags = new List<string>();
            this.flags.Add("___empty___");
            this.charEquipment = new CharEquipment();
        }

        // Token: 0x04001897 RID: 6295
        public PlayerStats stats;

        // Token: 0x0400189C RID: 6300
        public PlayerInv playerInv;

        // Token: 0x040018A0 RID: 6304
        public SaltStatue statue;

        // Token: 0x040018A3 RID: 6307
        public PlayerBeasts playerBeasts;

        // Token: 0x040018A4 RID: 6308
        public PlayerChallenges challenge;

        // Token: 0x040018A7 RID: 6311
        public bool needsSaltStatue;

        // Token: 0x040018A8 RID: 6312
        public int gold;

        // Token: 0x040018AC RID: 6316
        public int salt;

        // Token: 0x040018AD RID: 6317
        public int drawSalt;

        // Token: 0x040018B0 RID: 6320
        public long elapsedTimeTicks;

        // Token: 0x040018B1 RID: 6321
        public StringBuilder elapsedTimeStr;

        // Token: 0x040018B2 RID: 6322
        public int playthroughNumber;

        // Token: 0x040018B3 RID: 6323
        public int lastSanctuaryIdx;

        // Token: 0x040018B4 RID: 6324
        public int currentCreedIdx;

        // Token: 0x040018B5 RID: 6325
        public long sessionStartTicks;

        // Token: 0x040018B6 RID: 6326
        public int pSanctIn;

        // Token: 0x040018B7 RID: 6327
        public int expungedCount;

        // Token: 0x040018B8 RID: 6328
        public int skinIdx;

        // Token: 0x040018B9 RID: 6329
        public int skinClass;

        // Token: 0x040018BA RID: 6330
        public int hair;

        // Token: 0x040018BB RID: 6331
        public int hairColor;

        // Token: 0x040018BC RID: 6332
        public int beard;

        // Token: 0x040018BD RID: 6333
        public int beardColor;

        // Token: 0x040018BE RID: 6334
        public int eyeColor;

        // Token: 0x040018BF RID: 6335
        public int deaths;

        // Token: 0x040018C0 RID: 6336
        public int kills;

        // Token: 0x040018C1 RID: 6337
        public bool hardcore;

        // Token: 0x040018C2 RID: 6338
        public int sanctuaryRestCount;

        // Token: 0x040018C3 RID: 6339
        public int corruption;

        // Token: 0x040018C4 RID: 6340
        public int challengeType;

        // Token: 0x040018C5 RID: 6341
        public string name;

        // Token: 0x040018C6 RID: 6342
        public StringBuilder nameStr;

        // Token: 0x040018C7 RID: 6343
        public Vector2 saltOwnerVec;

        // Token: 0x040018C8 RID: 6344
        public Vector2 lastSaltLocReserve;

        // Token: 0x040018C9 RID: 6345
        public int saltTiedUp;

        // Token: 0x040018CA RID: 6346
        public Vector2 saltStatueVec;

        // Token: 0x040018CB RID: 6347
        public int saltStatueAnim;

        // Token: 0x040018CC RID: 6348
        public int saltStatueKey;

        // Token: 0x040018CD RID: 6349
        public int saltStatueFace;

        // Token: 0x040018CE RID: 6350
        public bool[] runes;
        
        // Token: 0x040018E6 RID: 6374
        public float consumableScroll;

        // Token: 0x040018E7 RID: 6375
        public int[] creedStanding;

        // Token: 0x040018E8 RID: 6376
        public int[] creedLevel;

        // Token: 0x040018E9 RID: 6377
        public int[] npcStanding;

        // Token: 0x040018EA RID: 6378
        public int[,] creedUnlocks;

        // Token: 0x040018EB RID: 6379
        public int[] sanctuaryCreed;

        // Token: 0x040018EC RID: 6380
        public int[,] sanctuaryPilgrim;

        // Token: 0x040018ED RID: 6381
        public int[] sanctuaryVisitCount;

        // Token: 0x040018EE RID: 6382
        public Vector2 respawnLoc;

        // Token: 0x040018EF RID: 6383
        public Vector2 sanctuaryRespawnLoc;

        // Token: 0x04001911 RID: 6417
        public List<string> flags;

        // Token: 0x04001913 RID: 6419
        public Vector2 lastSaltLoc;
        // Token: 0x0400191C RID: 6428

        public CharEquipment charEquipment;

     
    }
}
