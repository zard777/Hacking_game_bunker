﻿namespace SaltSaveEditor
{
	// Token: 0x02000220 RID: 544
	public class Sanctuary
	{
		// Token: 0x06000B53 RID: 2899 RVA: 0x001129B8 File Offset: 0x00110BB8
		public Sanctuary(Seg seg, int ID)
		{
            this.name = Game1.getSanctNameFromId(ID);
			this.ID = ID;
            if(seg != null)
            {
                this.x = (int)(seg.loc.X / 64f);
                this.y = (int)(seg.loc.Y / 32f);
                this.loc = new Vector2((float)this.x * 64f + 32f, (float)this.y * 64f * 0.5f + 6.4f);
            } else
            {
                this.x = -1;
                this.y = -1;
                this.loc = new Vector2(-1, -1);
            }

		
		}

        public const int MERCHANT_OFF = 0;

        // Token: 0x04001A3C RID: 6716
        public const int MERCHANT_PRIEST = 1;

        // Token: 0x04001A3D RID: 6717
        public const int MERCHANT_MERCHANT = 2;

        // Token: 0x04001A3E RID: 6718
        public const int MERCHANT_BLACKSMITH = 3;

        // Token: 0x04001A3F RID: 6719
        public const int MERCHANT_MAGE = 4;

        // Token: 0x04001A40 RID: 6720
        public const int MERCHANT_ALCHEMIST = 5;

        // Token: 0x04001A41 RID: 6721
        public const int MERCHANT_GUIDE = 6;

        // Token: 0x04001A42 RID: 6722
        public const int MERCHANT_LEADER = 7;

        // Token: 0x04001A43 RID: 6723
        public const int MERCHANT_SELLSWORD = 8;

        // Token: 0x04001A48 RID: 6728
        public int x;

		// Token: 0x04001A49 RID: 6729
		public int y;

		// Token: 0x04001A4F RID: 6735
		public Vector2 loc;

        public string name { get; set; }
        // Token: 0x04001A5B RID: 6747
        public int ID;

	}
}
