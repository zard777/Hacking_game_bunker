﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200000B RID: 11
	public class DialogMgr
	{
		// Token: 0x06000032 RID: 50 RVA: 0x00002D0A File Offset: 0x00000F0A
		public DialogMgr()
		{
			this.locStrings = new List<LocPair>();
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00002D1D File Offset: 0x00000F1D
		public StringBuilder GetLocString(int i)
		{
			return new StringBuilder(this.locStrings[i].locStr[Game1.language]);
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00002D3B File Offset: 0x00000F3B
		public string GetLocStr(int i)
		{
			return this.locStrings[i].locStr[Game1.language];
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00002D54 File Offset: 0x00000F54
		public string GetEnglishLocStr(int i)
		{
			return this.locStrings[i].locStr[0];
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00002D6C File Offset: 0x00000F6C
		public void ReadLocText()
		{

            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.dialog.data.strings.ztx");
            BinaryReader br = new BinaryReader(_fileStream);
            this.ReadLocText(br);
            br.Close();

            //BinaryReader binaryReader;
			//binaryReader = new BinaryReader(File.Open("dialog/data/strings.ztx", FileMode.Open, FileAccess.Read));
			//this.ReadLocText(binaryReader);
			//binaryReader.Close();
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00002DB8 File Offset: 0x00000FB8
		public void ReadLocText(BinaryReader reader)
		{
			int num;
			int i;
			LocPair locPair;
			int j;
			this.locStrings = new List<LocPair>();
			num = reader.ReadInt32();
			i = 0;
			while (i < num)
			{
				locPair = new LocPair(reader.ReadString());
				j = 0;
				while (j < locPair.locStr.Length)
				{
					locPair.locStr[j] = reader.ReadString();
					j = j + 1;
				}
				this.locStrings.Add(locPair);
				i = i + 1;
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00002E1C File Offset: 0x0000101C
		public void WriteLocText(BinaryWriter writer)
		{
			List<LocPair>.Enumerator enumerator;
			LocPair current;
			int i;
			writer.Write(this.locStrings.Count);
			enumerator = this.locStrings.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					current = enumerator.Current;
					writer.Write(current.orig);
					i = 0;
					while (i < current.locStr.Length)
					{
						writer.Write(current.locStr[i]);
						i = i + 1;
					}
				}
			}
			finally
			{
				((IDisposable)enumerator).Dispose();
			}
		}

        public void ReadMaster()
        {

            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.dialog.data.dialog.zdx");
            BinaryReader br = new BinaryReader(_fileStream);
            this.Read(br);
            br.Close();

        }

        // Token: 0x06000039 RID: 57 RVA: 0x00002EA8 File Offset: 0x000010A8
        public void Read(BinaryReader reader)
        {
            int num;
            int i;
            num = reader.ReadInt32();
            this.dialogList = new NPCDialog[num];
            i = 0;
            while (i < num)
            {
                this.dialogList[i] = new NPCDialog();
                this.dialogList[i].Read(reader);
                i = i + 1;
            }
        }

        // Token: 0x0400001E RID: 30
        public NPCDialog[] dialogList;

        // Token: 0x04000020 RID: 32
        public List<LocPair> locStrings;
	}
}
