﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x02000211 RID: 529
	public class PlayerInv
	{
		// Token: 0x06000AAC RID: 2732 RVA: 0x00104E50 File Offset: 0x00103050
		public PlayerInv(Player p)
		{
			this.p = p;
			this.inventory = new InvLoot[1024];
			this.invEquip = new PlayerInvEquip(p);
		}

		// Token: 0x06000AAD RID: 2733 RVA: 0x00104EAC File Offset: 0x001030AC
		public void Write(BinaryWriter writer)
		{
			int i;
			i = 0;
			while (i < this.inventory.Length)
			{
				writer.Write(this.inventory[i] != null);
				if (!(!(this.inventory[i] != null)))
				{
					this.inventory[i].Write(writer);
				}
				i = i + 1;
			}
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x00104EF8 File Offset: 0x001030F8
		public void Read(BinaryReader reader)
		{
			int i;
			i = 0;
			while (i < this.inventory.Length)
			{
				if (!(!reader.ReadBoolean()))
				{
					this.inventory[i] = new InvLoot(reader);
				}
				else
				{
					this.inventory[i] = null;
				}
				i = i + 1;
			}
			this.UpdateRunes(null);
		}

	
		// Token: 0x06000AB4 RID: 2740 RVA: 0x0010733B File Offset: 0x0010553B
		public LootDef GetLootFromIdx(int idx)
		{
			if (!(!(this.inventory[idx] != null)))
			{
				return Game1.lootCatalog.category[this.inventory[idx].category].loot[this.inventory[idx].catalogIdx];
			}
			return null;
		}

		// Token: 0x06000ABB RID: 2747 RVA: 0x00108110 File Offset: 0x00106310
		internal int Add(InvLoot loot, bool autoSelect, int count)
		{
			bool flag;
			int type;
			int type2;
			int flags;
			int flags2;
			int i;
			int num;
			int j;
			int k;
			Character playerCharacter;
			int l;
			int m;
			int n;
			int num2;
			int num3;
			bool flag2;
			LootDef lootDef;
			int flags3;
			bool flag3;
			int num4;
			int num5;
			flag = true;
			switch (loot.category)
			{
			case 1:
			{
				type = Game1.lootCatalog.category[1].loot[loot.catalogIdx].type;
				if (!(type != 4))
				{
					flag = false;
				}
				break;
			}
			case 3:
			{
				type2 = Game1.lootCatalog.category[3].loot[loot.catalogIdx].type;
				if (!(type2 != 2))
				{
					flag = false;
				}
				break;
			}
			case 4:
			{
				flags = Game1.lootCatalog.category[4].loot[loot.catalogIdx].flags;
				switch (flags)
				{
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				case 8:
				case 9:
				{
					break;
				}
				default:
				{
					if (!(!(flags != 91)))
					{
						goto IL_114;
					}
					break;
				}
				}
				flag = false;
				break;
			}
			case 6:
			{
				flag = false;
				break;
			}
			case 7:
			{
				flags2 = Game1.lootCatalog.category[7].loot[loot.catalogIdx].flags;
				if (!(flags2 != 14 && flags2 != 27))
				{
					flag = false;
				}
				break;
			}
			}
			IL_114:
			if (!(loot.category != 4 && loot.category != 7))
			{
				i = 0;
				while (i < this.inventory.Length)
				{
					if (!(!(this.inventory[i] != null) || this.inventory[i].category != loot.category || this.inventory[i].catalogIdx != loot.catalogIdx))
					{
						this.inventory[i].count += count;
						return i;
					}
					i = i + 1;
				}
			}
			if (!(!flag))
			{
				num = 0;
				j = 0;
				while (j < this.inventory.Length)
				{
					if (!(!(this.inventory[j] != null)))
					{
						num = num + 1;
						if (!(num < this.inventory.Length - 50))
						{
							return -1;
						}
					}
					j = j + 1;
				}
			}
			k = 0;
			while (k < this.inventory.Length)
			{
				if (!(this.inventory[k] != null))
				{
					this.inventory[k] = new InvLoot(loot);
					this.inventory[k].count = count;
					playerCharacter = Game1.c; // ottieni il Character
					if (!(!(playerCharacter != null)))
					{
						if (!(playerCharacter.equipment.helm.invIdx != k))
						{
							playerCharacter.equipment.helm.catalogIdx = -1;
						}
						if (!(playerCharacter.equipment.armor.invIdx != k))
						{
							playerCharacter.equipment.armor.catalogIdx = -1;
						}
						if (!(playerCharacter.equipment.boots.invIdx != k))
						{
							playerCharacter.equipment.boots.catalogIdx = -1;
						}
						if (!(playerCharacter.equipment.gloves.invIdx != k))
						{
							playerCharacter.equipment.gloves.catalogIdx = -1;
						}
						l = 0;
						while (l < 4)
						{
							if (!(playerCharacter.equipment.ring[l].invIdx != k))
							{
								playerCharacter.equipment.ring[l].catalogIdx = -1;
							}
							l = l + 1;
						}
						m = 0;
						while (m < 6)
						{
							if (!(playerCharacter.equipment.consumable[m].invIdx != k))
							{
								playerCharacter.equipment.consumable[m].catalogIdx = -1;
							}
							m = m + 1;
						}
						n = 0;
						while (n < 6)
						{
							if (!(playerCharacter.equipment.incantation[n].invIdx != k))
							{
								playerCharacter.equipment.incantation[n].catalogIdx = -1;
							}
							n = n + 1;
						}
						num2 = 0;
						while (num2 < 2)
						{
							num3 = 0;
							while (num3 < 3)
							{
								if (!(playerCharacter.equipment.loadout[num2, num3].invIdx != k))
								{
									playerCharacter.equipment.loadout[num2, num3].catalogIdx = -1;
								}
								num3 = num3 + 1;
							}
							num2 = num2 + 1;
						}
					}
					if (!(loot.category != 4))
					{
						flag2 = false;
						lootDef = Game1.lootCatalog.category[4].loot[loot.catalogIdx];
						switch (lootDef.type)
						{
						case 0:
						{
							flags3 = lootDef.flags;
							if (!(flags3 != 68))
							{
								flag2 = true;
							}
							break;
						}
						case 1:
						case 2:
						case 3:
						{
							flag2 = true;
							break;
						}
						}
						if (!(!(playerCharacter != null) || !autoSelect || flag2))
						{
							flag3 = false;
							num4 = 0;
							while (num4 < playerCharacter.equipment.consumable.Length)
							{
								if (!(playerCharacter.equipment.consumable[num4].catalogIdx != this.inventory[k].catalogIdx))
								{
									flag3 = true;
									break;
								}
								num4 = num4 + 1;
							}
							if (!flag3)
							{
								num5 = 0;
								while (num5 < playerCharacter.equipment.consumable.Length)
								{
									if (!(playerCharacter.equipment.consumable[num5].catalogIdx != -1))
									{
										playerCharacter.equipment.consumable[num5].catalogIdx = loot.catalogIdx;
										playerCharacter.equipment.consumable[num5].invIdx = k;
										break;
									}
									num5 = num5 + 1;
								}
								if (!(playerCharacter.equipment.selConsumable >= 6 || playerCharacter.equipment.consumable[playerCharacter.equipment.selConsumable].catalogIdx != -1))
								{
									this.SelectNextConsumable(playerCharacter);
								}
							}
						}
					}
					this.UpdateRunes(this.inventory[k]);
					return k;
				}
				k = k + 1;
			}
			return -1;
		}

		
		// Token: 0x06000AC1 RID: 2753 RVA: 0x00109578 File Offset: 0x00107778
		public void UpdateRunes(InvLoot invLoot)
		{
			int num;
			int i;
			int j;
			InvLoot invLoot2;
			LootDef lootDef;
			num = 0;
			i = 0;
			while (i < this.p.runes.Length)
			{
				this.p.runes[i] = false;
				i = i + 1;
			}
			j = 0;
			while (j < this.inventory.Length)
			{
				invLoot2 = this.inventory[j];
				if (!(!(invLoot2 != null) || invLoot2.category != 3))
				{
					lootDef = Game1.lootCatalog.category[invLoot2.category].loot[invLoot2.catalogIdx];
					if (!(lootDef.type != 2 || lootDef.flags >= this.p.runes.Length))
					{
						this.p.runes[lootDef.flags] = true;
						num = num + 1;
					}
				}
				j = j + 1;
			}

		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x00109D0C File Offset: 0x00107F0C
		public bool RemoveConsumable(int idx, Character c, bool removeSanctuaryItems)
		{
			int i;
			if (!(idx >= 0))
			{
				return false;
			}
			this.inventory[idx].count -= 1;
			if (!(this.inventory[idx].count > 0))
			{
				if (!(!(this.inventory[idx].sanctuaryConsumableCreed <= 0 || removeSanctuaryItems)))
				{
					i = 0;
					while (i < c.equipment.consumable.Length)
					{
						if (!(c.equipment.consumable[i].invIdx != idx))
						{
							c.equipment.consumable[i].catalogIdx = -1;
							c.equipment.consumable[i].invIdx = -1;
							this.inventory[idx] = null;
							return true;
						}
						i = i + 1;
					}
					this.inventory[idx] = null;
					return true;
				}
				this.inventory[idx].count = 0;
			}
			return false;
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x00109DE0 File Offset: 0x00107FE0
		public void SelectNextConsumable(Character c)
		{
			int i;
			i = 0;
			while (i < c.equipment.consumable.Length)
			{
				c.equipment.selConsumable = (c.equipment.selConsumable + 1) % c.equipment.consumable.Length;
				if (!(c.equipment.consumable[c.equipment.selConsumable].catalogIdx <= -1))
				{
					return;
				}
				i = i + 1;
			}
		}


		
		// Token: 0x06000AD0 RID: 2768 RVA: 0x0010A20C File Offset: 0x0010840C
		internal void Reset()
		{
			int i;
			i = 0;
			while (i < this.inventory.Length)
			{
				this.inventory[i] = null;
				i = i + 1;
			}
		}		

		// Token: 0x06000AD2 RID: 2770 RVA: 0x0010A28C File Offset: 0x0010848C
		internal string GetKeyName(string key)
		{
			int i;
			i = 0;
			while (i < this.inventory.Length)
			{
				if (!(!(this.inventory[i] != null) || this.inventory[i].category != 6 || this.inventory[i].name!= key))
				{
					return Game1.lootCatalog.category[6].loot[this.inventory[i].catalogIdx].title[Game1.language];
				}
				i = i + 1;
			}
			return "";
		}

		// Token: 0x06000ADB RID: 2779 RVA: 0x0010A734 File Offset: 0x00108934
		internal int GetMaterialDefCount(int category, int catalogIdx)
		{
			int i;
			i = 0;
			while (i < this.inventory.Length)
			{
				if (!(!(this.inventory[i] != null) || this.inventory[i].category != category || this.inventory[i].catalogIdx != catalogIdx))
				{
					return this.inventory[i].count;
				}
				i = i + 1;
			}
			return 0;
		}

		
		// Token: 0x06000ADE RID: 2782 RVA: 0x0010A850 File Offset: 0x00108A50
		internal bool HasInvItem(string p)
		{
			int i;
			i = 0;
			while (i < this.inventory.Length)
			{
				if (!(!(this.inventory[i] != null) || Game1.lootCatalog.category[this.inventory[i].category].loot[this.inventory[i].catalogIdx].name!= p))
				{
					return true;
				}
				i = i + 1;
			}
			return false;
		}

		// Token: 0x0400192A RID: 6442
		public const int CATEGORY_EQUIP = 0;

		// Token: 0x0400192B RID: 6443
		public const int CATEGORY_CONSUMABLES = 1;

		// Token: 0x0400192C RID: 6444
		public const int CATEGORY_MAGIC = 2;

		// Token: 0x0400192D RID: 6445
		public const int CATEGORY_ARMOR = 3;

		// Token: 0x0400192E RID: 6446
		public const int CATEGORY_WEAPONS = 4;

		// Token: 0x0400192F RID: 6447
		public const int CATEGORY_RINGS = 5;

		// Token: 0x04001930 RID: 6448
		public const int CATEGORY_KEYS = 6;

		// Token: 0x04001931 RID: 6449
		public const int CATEGORY_BLACKSMITH = 7;

		// Token: 0x04001932 RID: 6450
		public const int CATEGORY_RUNES = 8;

		// Token: 0x04001933 RID: 6451
		public const int CATEGORY_SETTINGS = 9;

		// Token: 0x04001934 RID: 6452
		public const int TOTAL_CATEGORIES = 10;

		// Token: 0x04001935 RID: 6453
		public const int ITEM_HELM = 0;

		// Token: 0x04001936 RID: 6454
		public const int ITEM_ARMOR = 1;

		// Token: 0x04001937 RID: 6455
		public const int ITEM_GLOVES = 2;

		// Token: 0x04001938 RID: 6456
		public const int ITEM_BOOTS = 3;

		// Token: 0x04001939 RID: 6457
		public const int ITEM_LOADOUT_1_1 = 4;

		// Token: 0x0400193A RID: 6458
		public const int ITEM_LOADOUT_1_2 = 5;

		// Token: 0x0400193B RID: 6459
		public const int ITEM_LOADOUT_1_3 = 6;

		// Token: 0x0400193C RID: 6460
		public const int ITEM_LOADOUT_2_1 = 7;

		// Token: 0x0400193D RID: 6461
		public const int ITEM_LOADOUT_2_2 = 8;

		// Token: 0x0400193E RID: 6462
		public const int ITEM_LOADOUT_2_3 = 9;

		// Token: 0x0400193F RID: 6463
		public const int ITEM_CONSUMABLE_1 = 10;

		// Token: 0x04001940 RID: 6464
		public const int ITEM_CONSUMABLE_2 = 11;

		// Token: 0x04001941 RID: 6465
		public const int ITEM_CONSUMABLE_3 = 12;

		// Token: 0x04001942 RID: 6466
		public const int ITEM_CONSUMABLE_4 = 13;

		// Token: 0x04001943 RID: 6467
		public const int ITEM_CONSUMABLE_5 = 14;

		// Token: 0x04001944 RID: 6468
		public const int ITEM_CONSUMABLE_6 = 15;

		// Token: 0x04001945 RID: 6469
		public const int ITEM_RING_1 = 16;

		// Token: 0x04001946 RID: 6470
		public const int ITEM_RING_2 = 17;

		// Token: 0x04001947 RID: 6471
		public const int ITEM_RING_3 = 18;

		// Token: 0x04001948 RID: 6472
		public const int ITEM_RING_4 = 19;

		// Token: 0x04001949 RID: 6473
		public const int ITEM_INCANTATION_1 = 20;

		// Token: 0x0400194A RID: 6474
		public const int ITEM_INCANTATION_2 = 21;

		// Token: 0x0400194B RID: 6475
		public const int ITEM_INCANTATION_3 = 22;

		// Token: 0x0400194C RID: 6476
		public const int ITEM_INCANTATION_4 = 23;

		// Token: 0x0400194D RID: 6477
		public const int ITEM_INCANTATION_5 = 24;

		// Token: 0x0400194E RID: 6478
		public const int ITEM_INCANTATION_6 = 25;

		// Token: 0x0400194F RID: 6479
		public const int ITEM_MENU_INVENTORY = 26;

		// Token: 0x04001950 RID: 6480
		public const int ITEM_MENU_BESTIARY = 27;

		// Token: 0x04001951 RID: 6481
		public const int ITEM_MENU_SETTINGS = 28;

		// Token: 0x04001952 RID: 6482
		public const int TOTAL_ITEMS = 29;

		// Token: 0x04001953 RID: 6483
		public const int PICK_NONE = 0;

		// Token: 0x04001954 RID: 6484
		public const int PICK_HELM = 1;

		// Token: 0x04001955 RID: 6485
		public const int PICK_ARMOR = 2;

		// Token: 0x04001956 RID: 6486
		public const int PICK_BOOTS = 3;

		// Token: 0x04001957 RID: 6487
		public const int PICK_GLOVES = 4;

		// Token: 0x04001958 RID: 6488
		public const int PICK_WEAPON = 5;

		// Token: 0x04001959 RID: 6489
		public const int PICK_SHIELD = 6;

		// Token: 0x0400195A RID: 6490
		public const int PICK_CHARM = 7;

		// Token: 0x0400195B RID: 6491
		public const int PICK_ARROWS = 8;

		// Token: 0x0400195C RID: 6492
		public const int PICK_SPELLS = 9;

		// Token: 0x0400195D RID: 6493
		public const int PICK_INCANTATION = 10;

		// Token: 0x0400195E RID: 6494
		public const int PICK_CONSUMABLE = 11;

		// Token: 0x0400195F RID: 6495
		public const int PICK_RING = 12;

		// Token: 0x04001960 RID: 6496
		public const int PICK_OFFHAND = 13;

		// Token: 0x04001961 RID: 6497
		public const int PICK_LOADOUT_ITEM = 14;

		// Token: 0x04001962 RID: 6498
		private Player p;

		// Token: 0x04001963 RID: 6499
		public InvLoot[] inventory;

		// Token: 0x04001964 RID: 6500
		public PlayerInvEquip invEquip;

		// Token: 0x04001965 RID: 6501
		public int selCategory;

		// Token: 0x04001966 RID: 6502
		public int selItem;

		// Token: 0x04001967 RID: 6503
		public Vector2 selVector;

	}
}
