﻿namespace SaltSaveEditor
{
	// Token: 0x0200000C RID: 12
	public class TextSeries
	{
		// Token: 0x0600003D RID: 61 RVA: 0x00003168 File Offset: 0x00001368
		public TextSeries()
		{
		}

		// Token: 0x04000021 RID: 33
		public string[] text;
	}
}
