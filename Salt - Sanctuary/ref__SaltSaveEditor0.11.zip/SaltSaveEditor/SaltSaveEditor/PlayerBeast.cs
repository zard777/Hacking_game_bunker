﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x020001CE RID: 462
	public class PlayerBeast
	{
		// Token: 0x060008EB RID: 2283 RVA: 0x000D6978 File Offset: 0x000D4B78
		public PlayerBeast()
		{
			this.kills = 0;
			this.killedBy = 0;
			this.drops = new int[6];
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x000D699C File Offset: 0x000D4B9C
		public PlayerBeast(BinaryReader reader)
		{
			int i;
			this.kills = reader.ReadInt32();
			this.killedBy = reader.ReadInt32();
			this.drops = new int[6];
			i = 0;
			while (i < this.drops.Length)
			{
				this.drops[i] = reader.ReadInt32();
				i = i + 1;
			}
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x000D69F4 File Offset: 0x000D4BF4
		public PlayerBeast(PlayerBeast playerBeast)
		{
			int i;
			this.kills = playerBeast.kills;
			this.killedBy = playerBeast.killedBy;
			this.drops = new int[6];
			i = 0;
			while (i < this.drops.Length)
			{
				this.drops[i] = playerBeast.drops[i];
				i = i + 1;
			}
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x000D6A50 File Offset: 0x000D4C50
		internal void Write(BinaryWriter writer)
		{
			int i;
			writer.Write(this.kills);
			writer.Write(this.killedBy);
			i = 0;
			while (i < this.drops.Length)
			{
				writer.Write(this.drops[i]);
				i = i + 1;
			}
		}

		// Token: 0x040014ED RID: 5357
		public int kills;

		// Token: 0x040014EE RID: 5358
		public int killedBy;

		// Token: 0x040014EF RID: 5359
		public int[] drops;
	}
}
