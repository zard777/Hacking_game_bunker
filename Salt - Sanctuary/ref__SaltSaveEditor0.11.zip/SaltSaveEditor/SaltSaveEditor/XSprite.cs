﻿namespace SaltSaveEditor
{
	// Token: 0x0200002C RID: 44
	public class XSprite
	{
		// Token: 0x060000D8 RID: 216 RVA: 0x0000A443 File Offset: 0x00008643
		public XSprite()
		{
		}

		// Token: 0x0400034A RID: 842
		public Rectangle srcRect;

		// Token: 0x0400034B RID: 843
		public Vector2 origin;

		// Token: 0x0400034C RID: 844
		public string name;

		// Token: 0x0400034D RID: 845
		public int flags;

		// Token: 0x0400034E RID: 846
		public int char_ref;
	}
}
