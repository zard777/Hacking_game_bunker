﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaltSaveEditor
{
    public partial class Form1 : Form
    {

        string filePath = "";

        BindingList<string> bindinglist = new BindingList<string>();

        public Form1()
        {
            InitializeComponent();
            Game1.init();
            Sanctuary[] s = new Sanctuary[33];
            s[0] = new Sanctuary(null, -1);
            int i = 1;
            while (i < 33)
            {
                s[i] = SanctuaryMgr.sanctuaries[i-1];
                i++;
            }
            lastSanctuaryComboBox.DataSource = s;
            lastSanctuaryComboBox.DisplayMember = "name";

            s = new Sanctuary[32];
            i = 0;
            while (i < 32)
            {
                s[i] = SanctuaryMgr.sanctuaries[i];
                i++;
            }
            sanctuaryCreedListComboBox.DataSource = s;
            sanctuaryCreedListComboBox.DisplayMember = "name";

            sanctuaryCreedComboBox.Items.Add("None");
            sanctuaryCreedComboBox.Items.Add("The Iron Ones");
            sanctuaryCreedComboBox.Items.Add("Devara's Light");
            sanctuaryCreedComboBox.Items.Add("The Three");
            sanctuaryCreedComboBox.Items.Add("The Stone Roots");
            sanctuaryCreedComboBox.Items.Add("Order of the Betrayer");
            sanctuaryCreedComboBox.Items.Add("The House of Splendor");
            sanctuaryCreedComboBox.Items.Add("Keepers of Fire and Sky");

            ironStanding.Items.Add("Apostate");
            ironStanding.Items.Add("Unaffiliated");
            ironStanding.Items.Add("Buff");
            devaraStanding.Items.Add("Apostate");
            devaraStanding.Items.Add("Unaffiliated");
            devaraStanding.Items.Add("Buff");
            threeStanding.Items.Add("Apostate");
            threeStanding.Items.Add("Unaffiliated");
            threeStanding.Items.Add("Buff");
            stoneStanding.Items.Add("Apostate");
            stoneStanding.Items.Add("Unaffiliated");
            stoneStanding.Items.Add("Buff");
            darkStanding.Items.Add("Apostate");
            darkStanding.Items.Add("Unaffiliated");
            darkStanding.Items.Add("Buff");
            splendorStanding.Items.Add("Apostate");
            splendorStanding.Items.Add("Unaffiliated");
            splendorStanding.Items.Add("Buff");
            keeperStanding.Items.Add("Apostate");
            keeperStanding.Items.Add("Unaffiliated");
            keeperStanding.Items.Add("Buff");
            ironLevel.Items.Add("0");
            ironLevel.Items.Add("1");
            ironLevel.Items.Add("2");
            ironLevel.Items.Add("3");
            ironLevel.Items.Add("4");
            ironLevel.Items.Add("5");
            ironLevel.Items.Add("6");
            ironLevel.Items.Add("7");
            devaraLevel.Items.Add("0");
            devaraLevel.Items.Add("1");
            devaraLevel.Items.Add("2");
            devaraLevel.Items.Add("3");
            devaraLevel.Items.Add("4");
            devaraLevel.Items.Add("5");
            devaraLevel.Items.Add("6");
            devaraLevel.Items.Add("7");
            threeLevel.Items.Add("0");
            threeLevel.Items.Add("1");
            threeLevel.Items.Add("2");
            threeLevel.Items.Add("3");
            threeLevel.Items.Add("4");
            threeLevel.Items.Add("5");
            threeLevel.Items.Add("6");
            threeLevel.Items.Add("7");
            stoneLevel.Items.Add("0");
            stoneLevel.Items.Add("1");
            stoneLevel.Items.Add("2");
            stoneLevel.Items.Add("3");
            stoneLevel.Items.Add("4");
            stoneLevel.Items.Add("5");
            stoneLevel.Items.Add("6");
            stoneLevel.Items.Add("7");
            darkLevel.Items.Add("-1");
            darkLevel.Items.Add("0");
            darkLevel.Items.Add("1");
            darkLevel.Items.Add("2");
            darkLevel.Items.Add("3");
            darkLevel.Items.Add("4");
            darkLevel.Items.Add("5");
            darkLevel.Items.Add("6");
            darkLevel.Items.Add("7");
            splendorLevel.Items.Add("0");
            splendorLevel.Items.Add("1");
            splendorLevel.Items.Add("2");
            splendorLevel.Items.Add("3");
            splendorLevel.Items.Add("4");
            splendorLevel.Items.Add("5");
            splendorLevel.Items.Add("6");
            splendorLevel.Items.Add("7");
            keeperLevel.Items.Add("0");
            keeperLevel.Items.Add("1");
            keeperLevel.Items.Add("2");
            keeperLevel.Items.Add("3");
            keeperLevel.Items.Add("4");
            keeperLevel.Items.Add("5");
            keeperLevel.Items.Add("6");
            keeperLevel.Items.Add("7");
            creedBox.Items.Add("None");
            creedBox.Items.Add("The Iron Ones");
            creedBox.Items.Add("Devara's Light");
            creedBox.Items.Add("The Three");
            creedBox.Items.Add("The Stone Roots");
            creedBox.Items.Add("Order of the Betrayer");
            creedBox.Items.Add("The House of Splendor");
            creedBox.Items.Add("Keepers of Fire and Sky");
            merchant1ComboBox.Items.Add("None");
            merchant1ComboBox.Items.Add("Priest");
            merchant1ComboBox.Items.Add("Sellsword");
            merchant1ComboBox.Items.Add("Leader");
            merchant1ComboBox.Items.Add("Mage");
            merchant1ComboBox.Items.Add("Alchemist");
            merchant1ComboBox.Items.Add("Guide");
            merchant1ComboBox.Items.Add("Blacksmith");
            merchant1ComboBox.Items.Add("Merchant");

            merchant2ComboBox.Items.Add("None");
            merchant2ComboBox.Items.Add("Priest");
            merchant2ComboBox.Items.Add("Sellsword");
            merchant2ComboBox.Items.Add("Leader");
            merchant2ComboBox.Items.Add("Mage");
            merchant2ComboBox.Items.Add("Alchemist");
            merchant2ComboBox.Items.Add("Guide");
            merchant2ComboBox.Items.Add("Blacksmith");
            merchant2ComboBox.Items.Add("Merchant");

            merchant3ComboBox.Items.Add("None");
            merchant3ComboBox.Items.Add("Priest");
            merchant3ComboBox.Items.Add("Sellsword");
            merchant3ComboBox.Items.Add("Leader");
            merchant3ComboBox.Items.Add("Mage");
            merchant3ComboBox.Items.Add("Alchemist");
            merchant3ComboBox.Items.Add("Guide");
            merchant3ComboBox.Items.Add("Blacksmith");
            merchant3ComboBox.Items.Add("Merchant");

            merchant4ComboBox.Items.Add("None");
            merchant4ComboBox.Items.Add("Priest");
            merchant4ComboBox.Items.Add("Sellsword");
            merchant4ComboBox.Items.Add("Leader");
            merchant4ComboBox.Items.Add("Mage");
            merchant4ComboBox.Items.Add("Alchemist");
            merchant4ComboBox.Items.Add("Guide");
            merchant4ComboBox.Items.Add("Blacksmith");
            merchant4ComboBox.Items.Add("Merchant");


        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = "";
            OpenFileDialog file = new OpenFileDialog();
            if (file.ShowDialog() == DialogResult.OK)
            {
                path = file.FileName;
                this.filePath = path;
                BinaryReader binaryReader = new BinaryReader(File.OpenRead(path));
                Game1.p = new Player();
                Game1.c = new Character();
                Player p = Game1.p;
                p.Read(binaryReader);
                binaryReader.Close();

                nameBox.Text = p.name;
                hardcoreCheck.Checked = p.hardcore;
                killsBox.Text = p.kills + "";
                deathsBox.Text = p.deaths + "";
                restCountBox.Text = p.sanctuaryRestCount + "";
                corruptionBox.Text = p.corruption + "";
                playthroughBox.Text = p.playthroughNumber + "";
                string creed = Game1.getCreedFromId(p.currentCreedIdx);
                creedBox.SelectedIndex = creedBox.FindStringExact(creed);
                string curSanct = Game1.getSanctNameFromId(p.lastSanctuaryIdx);
                lastSanctuaryComboBox.SelectedIndex = lastSanctuaryComboBox.FindStringExact(curSanct);

                updateCreeds();

                expungedBox.Text = p.expungedCount + "";
                saltBox.Text = p.salt + "";
                goldBox.Text = p.gold + "";

                updateInventories();


                bindinglist = new BindingList<string>();
                for (int i = 0; i < Game1.p.flags.Count; i++)
                {
                    bindinglist.Add(Game1.p.flags[i]);
                }
                BindingSource bSource = new BindingSource();
                bSource.DataSource = bindinglist;
                playerflagsComboBox.DataSource = bSource;
            }
            
        }

        private void updateInventories()
        {
            Player p = Game1.p;

            List<InvLoot> weapons = new List<InvLoot>();
            List<InvLoot> shields = new List<InvLoot>();
            List<InvLoot> armor = new List<InvLoot>();
            List<InvLoot> rings = new List<InvLoot>();
            List<InvLoot> utility = new List<InvLoot>();
            List<InvLoot> spells = new List<InvLoot>();
            List<InvLoot> keys = new List<InvLoot>();
            List<InvLoot> materials = new List<InvLoot>();

            for (int i = 0; i < p.playerInv.inventory.Length; i++)
            {
                InvLoot item = p.playerInv.inventory[i];

                if (item != null)
                {
                    switch (item.category)
                    {
                        case 0:
                            weapons.Add(item);
                            break;
                        case 1:
                            shields.Add(item);
                            break;
                        case 2:
                            armor.Add(item);
                            break;
                        case 3:
                            rings.Add(item);
                            break;
                        case 4:
                            utility.Add(item);
                            break;
                        case 5:
                            spells.Add(item);
                            break;
                        case 6:
                            keys.Add(item);
                            break;
                        case 7:
                            materials.Add(item);
                            break;
                    }
                }
            }

            weaponComboBox.DataSource = weapons;
            weaponComboBox.DisplayMember = "baseName";
            shieldsComboBox.DataSource = shields;
            shieldsComboBox.DisplayMember = "baseName";
            armorComboBox.DataSource = armor;
            armorComboBox.DisplayMember = "baseName";
            ringsComboBox.DataSource = rings;
            ringsComboBox.DisplayMember = "baseName";
            utilityComboBox.DataSource = utility;
            utilityComboBox.DisplayMember = "baseName";
            spellsComboBox.DataSource = spells;
            spellsComboBox.DisplayMember = "baseName";
            keysComboBox.DataSource = keys;
            keysComboBox.DisplayMember = "baseName";
            materialsComboBox.DataSource = materials;
            materialsComboBox.DisplayMember = "baseName";
        }

        private void updateCreeds()
        {
            setStanding(ironStanding, Creeds.CREED_IRON);
            setStanding(devaraStanding, Creeds.CREED_CLERIC);
            setStanding(threeStanding, Creeds.CREED_THREE);
            setStanding(darkStanding, Creeds.CREED_DARK);
            setStanding(stoneStanding, Creeds.CREED_WOODS);
            setStanding(splendorStanding, Creeds.CREED_SPLENDOR);
            setStanding(keeperStanding, Creeds.CREED_FIRE);

            setLevel(ironLevel, Creeds.CREED_IRON);
            setLevel(devaraLevel, Creeds.CREED_CLERIC);
            setLevel(threeLevel, Creeds.CREED_THREE);
            setLevel(darkLevel, Creeds.CREED_DARK);
            setLevel(stoneLevel, Creeds.CREED_WOODS);
            setLevel(splendorLevel, Creeds.CREED_SPLENDOR);
            setLevel(keeperLevel, Creeds.CREED_FIRE);
        }

        private void setStanding(ComboBox a, int id)
        {
            int[] stand = Game1.p.creedStanding;
            int standing = stand[id];
            switch (standing)
            {
                case -1: a.SelectedIndex = a.FindStringExact("Apostate");
                    break;
                case 0: a.SelectedIndex = a.FindStringExact("Unaffiliated");
                    break;
                case 1: a.SelectedIndex = a.FindStringExact("Buff");
                    break;
            }
        }

        private void setLevel(ComboBox a, int id)
        {
            int[] levels = Game1.p.creedLevel;
            int level = levels[id];
            switch (level)
            {
                case -1:
                    a.SelectedIndex = a.FindStringExact("-1");
                    break;
                case 0:
                    a.SelectedIndex = a.FindStringExact("0");
                    break;
                case 1:
                    a.SelectedIndex = a.FindStringExact("1");
                    break;
                case 2:
                    a.SelectedIndex = a.FindStringExact("2");
                    break;
                case 3:
                    a.SelectedIndex = a.FindStringExact("3");
                    break;
                case 4:
                    a.SelectedIndex = a.FindStringExact("4");
                    break;
                case 5:
                    a.SelectedIndex = a.FindStringExact("5");
                    break;
                case 6:
                    a.SelectedIndex = a.FindStringExact("6");
                    break;
                case 7:
                    a.SelectedIndex = a.FindStringExact("7");
                    break;
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (filePath != "")
            {
                string backupPath = filePath + ".bak";
                while (File.Exists(backupPath))
                {
                    backupPath = backupPath + ".bak";
                }
                File.Copy(filePath, backupPath, true);

                BinaryWriter binaryWriter = new BinaryWriter(File.Open(filePath, FileMode.Truncate, FileAccess.Write));
                Game1.p.Write(binaryWriter);
                binaryWriter.Close();

            }
        }

        private void nameBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.name = nameBox.Text;
        }

        private void hardcoreCheck_CheckedChanged(object sender, EventArgs e)
        {
            Game1.p.hardcore = hardcoreCheck.Checked;
        }

        private void killsBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.kills = Int32.Parse(killsBox.Text);
        }

        private void deathsBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.deaths = Int32.Parse(deathsBox.Text);
        }

        private void restCountBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.sanctuaryRestCount = Int32.Parse(restCountBox.Text);
        }

        private void corruptionBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.corruption = Int32.Parse(corruptionBox.Text);
        }

        private void playthroughBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.playthroughNumber = Int32.Parse(playthroughBox.Text);
        }

        private void expungedBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.expungedCount = Int32.Parse(expungedBox.Text);
        }

        private void saltBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.salt = Int32.Parse(saltBox.Text);
        }

        private void goldBox_TextChanged(object sender, EventArgs e)
        {
            Game1.p.gold = Int32.Parse(goldBox.Text);
        }

        private void creedBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int creedId = Game1.getIdFromCreed((string)creedBox.SelectedItem);
            Player p = Game1.p;
            p.currentCreedIdx = creedId;

            for(int i = 0; i<p.creedLevel.Length; i++)
            {
                p.creedLevel[i] = 0;
            }
           /* for (int i = 0; i < p.creedStanding.Length; i++)
            {
                p.creedStanding[i] = 0;
            }*/
            p.creedLevel[creedId] = 1;
            updateCreeds();
        }

        private void lastSanctuaryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int sanctId = Game1.getSanctIdFromName(((Sanctuary)lastSanctuaryComboBox.SelectedItem).name);
            if (sanctId >= 0)
            {
                Sanctuary newSanct = SanctuaryMgr.sanctuaries[sanctId];
                Player p = Game1.p;
                p.lastSanctuaryIdx = sanctId;
                p.respawnLoc = newSanct.loc;
                p.sanctuaryRespawnLoc = newSanct.loc;
            }
            
        }

        private void ironStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)ironStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate": Game1.p.creedStanding[Creeds.CREED_IRON] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_IRON] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_IRON] = 1;
                    break;
            }
        }

        private void devaraStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)devaraStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate":
                    Game1.p.creedStanding[Creeds.CREED_CLERIC] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_CLERIC] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_CLERIC] = 1;
                    break;
            }
        }

        private void threeStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)threeStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate":
                    Game1.p.creedStanding[Creeds.CREED_THREE] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_THREE] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_THREE] = 1;
                    break;
            }
        }

        private void stoneStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)stoneStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate":
                    Game1.p.creedStanding[Creeds.CREED_WOODS] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_WOODS] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_WOODS] = 1;
                    break;
            }
        }

        private void darkStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)darkStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate":
                    Game1.p.creedStanding[Creeds.CREED_DARK] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_DARK] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_DARK] = 1;
                    break;
            }
        }

        private void splendorStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)splendorStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate":
                    Game1.p.creedStanding[Creeds.CREED_SPLENDOR] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_SPLENDOR] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_SPLENDOR] = 1;
                    break;
            }
        }

        private void keeperStanding_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)keeperStanding.SelectedItem;
            switch (selection)
            {
                case "Apostate":
                    Game1.p.creedStanding[Creeds.CREED_FIRE] = -1;
                    break;
                case "Unaffiliated":
                    Game1.p.creedStanding[Creeds.CREED_FIRE] = 0;
                    break;
                case "Buff":
                    Game1.p.creedStanding[Creeds.CREED_FIRE] = 1;
                    break;
            }


        }

        private void ironLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)ironLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_IRON] = Int32.Parse(selection);
        }

        private void devaraLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)devaraLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_CLERIC] = Int32.Parse(selection);
        }

        private void threeLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)threeLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_THREE] = Int32.Parse(selection);
        }

        private void stoneLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)stoneLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_WOODS] = Int32.Parse(selection);
        }

        private void darkLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)darkLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_DARK] = Int32.Parse(selection);
        }

        private void splendorLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)splendorLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_SPLENDOR] = Int32.Parse(selection);
        }

        private void keeperLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selection = (string)keeperLevel.SelectedItem;
            Game1.p.creedLevel[Creeds.CREED_FIRE] = Int32.Parse(selection);
        }

        private void weaponAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(0);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void shieldAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(1);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void armorAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(2);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void ringsAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(3);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void utilityAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(4);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void spellsAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(5);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void keysAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(6);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        private void materialsAdd_Click(object sender, EventArgs e)
        {
            InvLoot item = AddPrompt.ShowDialog(7);
            if (item != null)
            {
                Game1.p.playerInv.Add(item, false, item.count);
                updateInventories();
            }
        }

        public static class EditPrompt
        {
            public static void ShowDialog(InvLoot loot, bool isUpgradable)
            {
                Form prompt = new Form();
                prompt.Text = "Edit "+loot.baseName;
                ComboBox upgradeComboBox = new ComboBox();
                TextBox qtyBox = new TextBox();

                if (isUpgradable)
                {
                    prompt.Width = 300;
                    prompt.Height = 130;
                    upgradeComboBox.FormattingEnabled = true;
                    upgradeComboBox.Location = new System.Drawing.Point(90, 10);
                    upgradeComboBox.Size = new System.Drawing.Size(50, 200);
                    upgradeComboBox.TabIndex = 0;
                    upgradeComboBox.Items.Add("0");
                    upgradeComboBox.Items.Add("1");
                    upgradeComboBox.Items.Add("2");
                    upgradeComboBox.Items.Add("3");
                    upgradeComboBox.Items.Add("4");
                    upgradeComboBox.Items.Add("5");
                    upgradeComboBox.Items.Add("6");
                    upgradeComboBox.Items.Add("7");
                    upgradeComboBox.SelectedIndex = loot.upgrade;
                    Label upgrade = new Label() { Text = "Upgrade Level", Width = 90, Left = 10, Top = 13 };

                    Label qty = new Label() { Text = "Quantity", Width = 50, Left = 10, Top = 43 };
                    qtyBox = new TextBox { Text = loot.count + "", Left = 60, Width = 40, Top = 40 };

                    Button confirmation = new Button() { Text = "Ok", Left = 50, Width = 80, Top = 65 };
                    confirmation.DialogResult = DialogResult.OK;

                    prompt.Controls.Add(upgradeComboBox);
                    prompt.Controls.Add(upgrade);
                    prompt.Controls.Add(confirmation);
                    prompt.Controls.Add(qty);
                    prompt.Controls.Add(qtyBox);
                }
                else
                {
                    prompt.Width = 300;
                    prompt.Height = 115;
                    
                    Label qty = new Label() { Text = "Quantity", Width = 50, Left = 10, Top = 13 };
                    qtyBox = new TextBox { Text = loot.count + "", Left = 60, Width = 40, Top = 10 };

                    Button confirmation = new Button() { Text = "Ok", Left = 50, Width = 80, Top = 35 };
                    confirmation.DialogResult = DialogResult.OK;

                    prompt.Controls.Add(confirmation);
                    prompt.Controls.Add(qty);
                    prompt.Controls.Add(qtyBox);
                }


               
                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    if (isUpgradable)
                    {
                        loot.upgrade = Int32.Parse((string)upgradeComboBox.SelectedItem);
                    }
                    loot.count = Int32.Parse(qtyBox.Text);
                }
            }
        }

        public static class AddPrompt
        {
            public static InvLoot ShowDialog(int category)
            {
                Form prompt = new Form();
                prompt.Width = 205;
                prompt.Height = 390;
                prompt.Text = "Add Item";
                ComboBox lootComboBox = new ComboBox();
                lootComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
                lootComboBox.FormattingEnabled = true;
                lootComboBox.Location = new System.Drawing.Point(10, 10);
                lootComboBox.Size = new System.Drawing.Size(170, 300);
                lootComboBox.TabIndex = 0;

                Label qty = new Label() { Text = "Quantity", Width = 50, Left = 10, Top = 324 };
                TextBox qtyBox = new TextBox { Text = "1", Left = 60, Width = 40, Top = 320 };


                LootDef[] items = Game1.lootCatalog.category[category].loot;
                lootComboBox.DataSource = items;
                lootComboBox.DisplayMember = "baseName";

                Button confirmation = new Button() { Text = "Add", Left = 110, Width = 55, Top = 320 };
                confirmation.DialogResult = DialogResult.OK;
                prompt.Controls.Add(lootComboBox);
                prompt.Controls.Add(confirmation);
                prompt.Controls.Add(qty);
                prompt.Controls.Add(qtyBox);
                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    InvLoot res = new InvLoot();
                    res.InitFromName(((LootDef)lootComboBox.SelectedItem).name);
                    res.count = Int32.Parse(qtyBox.Text);
                    return res;
                }
                else
                    return (InvLoot)null;
            }
        }

        private void weaponEdit_Click(object sender, EventArgs e)
        {
            if(weaponComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)weaponComboBox.SelectedItem, true);
        }

        private void materialsEdit_Click(object sender, EventArgs e)
        {
            if (materialsComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)materialsComboBox.SelectedItem, false);
        }

        private void shieldEdit_Click(object sender, EventArgs e)
        {
            if (shieldsComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)shieldsComboBox.SelectedItem, true);
        }

        private void armorEdit_Click(object sender, EventArgs e)
        {
            if (armorComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)armorComboBox.SelectedItem, true);
        }

        private void ringsEdit_Click(object sender, EventArgs e)
        {
            if (ringsComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)ringsComboBox.SelectedItem, false);
        }

        private void utilityEdit_Click(object sender, EventArgs e)
        {
            if (utilityComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)utilityComboBox.SelectedItem, false);
        }

        private void spellsEdit_Click(object sender, EventArgs e)
        {
            if (spellsComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)spellsComboBox.SelectedItem, false);
        }

        private void keysEdit_Click(object sender, EventArgs e)
        {
            if (keysComboBox.SelectedItem != null)
                EditPrompt.ShowDialog((InvLoot)keysComboBox.SelectedItem, false);
        }

        private void sanctuaryCreedListComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Player p = Game1.p;
            int selectedSanctCreed = Game1.p.sanctuaryCreed[((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).ID];
            int selectedSanctId = Game1.getSanctIdFromName(((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).name);
            sanctuaryCreedComboBox.SelectedIndex = sanctuaryCreedComboBox.FindStringExact(Game1.getCreedFromId(selectedSanctCreed));
            merchant1ComboBox.SelectedIndex = merchant1ComboBox.FindStringExact(Game1.getMerchantNameFromId(Game1.p.sanctuaryPilgrim[selectedSanctId, 0]));
            merchant2ComboBox.SelectedIndex = merchant2ComboBox.FindStringExact(Game1.getMerchantNameFromId(Game1.p.sanctuaryPilgrim[selectedSanctId, 1]));
            merchant3ComboBox.SelectedIndex = merchant3ComboBox.FindStringExact(Game1.getMerchantNameFromId(Game1.p.sanctuaryPilgrim[selectedSanctId, 2]));
            merchant4ComboBox.SelectedIndex = merchant4ComboBox.FindStringExact(Game1.getMerchantNameFromId(Game1.p.sanctuaryPilgrim[selectedSanctId, 3]));
        }

        private void sanctuaryCreedComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedSanctId = Game1.getSanctIdFromName(((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).name);
            int selectedCreedId = Game1.getIdFromCreed((string)sanctuaryCreedComboBox.SelectedItem);
            Game1.p.sanctuaryCreed[selectedSanctId] = selectedCreedId;
        }

        private void merchant1ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedSanctId = Game1.getSanctIdFromName(((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).name);
            int selectedMerchantId = Game1.getMerchantIdFromName((string)merchant1ComboBox.SelectedItem);
            Game1.p.sanctuaryPilgrim[selectedSanctId, 0] = selectedMerchantId;
        }

        private void merchant2ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedSanctId = Game1.getSanctIdFromName(((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).name);
            int selectedMerchantId = Game1.getMerchantIdFromName((string)merchant2ComboBox.SelectedItem);
            Game1.p.sanctuaryPilgrim[selectedSanctId, 1] = selectedMerchantId;
        }

        private void merchant3ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedSanctId = Game1.getSanctIdFromName(((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).name);
            int selectedMerchantId = Game1.getMerchantIdFromName((string)merchant3ComboBox.SelectedItem);
            Game1.p.sanctuaryPilgrim[selectedSanctId, 2] = selectedMerchantId;
        }

        private void merchant4ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedSanctId = Game1.getSanctIdFromName(((Sanctuary)sanctuaryCreedListComboBox.SelectedItem).name);
            int selectedMerchantId = Game1.getMerchantIdFromName((string)merchant4ComboBox.SelectedItem);
            Game1.p.sanctuaryPilgrim[selectedSanctId, 3] = selectedMerchantId;
        }

        private void goodbyeMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void removeFlagButton_Click(object sender, EventArgs e)
        {
            string selectedFlag = (string)playerflagsComboBox.SelectedItem;
            Game1.p.flags.Remove(selectedFlag);
            bindinglist.Remove(selectedFlag);
        }

        private void addFlagButton_Click(object sender, EventArgs e)
        {
            string newFlag = AddFlagPrompt.ShowDialog();
            if(newFlag != null && !bindinglist.Contains(newFlag))
            {
                Game1.p.flags.Add(newFlag);
                bindinglist.Add(newFlag);
            }
        }

        public static class AddFlagPrompt
        {
            public static string ShowDialog()
            {
                Form prompt = new Form();
                prompt.Width = 205;
                prompt.Height = 390;
                prompt.Text = "Add Flag";
                ComboBox flagsComboBox = new ComboBox();
                flagsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
                flagsComboBox.FormattingEnabled = true;
                flagsComboBox.Location = new System.Drawing.Point(10, 10);
                flagsComboBox.Size = new System.Drawing.Size(170, 300);
                flagsComboBox.TabIndex = 0;

                List<string> items = new List<string>();

                items.Add("dread");
                items.Add("bull");
                items.Add("dragon");
                items.Add("alchemist");
                items.Add("gasbag");
                items.Add("lakewitch");
                items.Add("fauxjester");
                items.Add("squiddragon");
                items.Add("nameless");
                items.Add("cloak");
                items.Add("murderfly");
                items.Add("cutqueen");
                items.Add("torturetree");
                items.Add("pirate");
                items.Add("griffin");
                items.Add("mummy");
                items.Add("monster");
                items.Add("ruinaxe");
                items.Add("clay");
                items.Add("deadking");
                items.Add("inquisitor");

                for (int i = 0; i < Map.layer.Length; i++)
                {
                    for (int j = 0; j < Map.layer[i].seg.Length; j++)
                    {
                        if (Map.layer[i].seg[j].strFlag != null && Map.layer[i].seg[j].strFlag.StartsWith("flag"))
                        {
                            items.Add(Map.layer[i].seg[j].strFlag.Split(new string[] { "flag " }, StringSplitOptions.None)[1].Split(new string[] { "\r\n" }, StringSplitOptions.None)[0]);
                        }
                    }
                }

                flagsComboBox.DataSource = items;
              

                Button confirmation = new Button() { Text = "Add", Left = 50, Width = 80, Top = 320 };
                confirmation.DialogResult = DialogResult.OK;
                prompt.Controls.Add(flagsComboBox);
                prompt.Controls.Add(confirmation);

                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    return (string)flagsComboBox.SelectedItem;
                }
                else
                    return null;
            }
        }

        private void addflagManuallyButton_Click(object sender, EventArgs e)
        {
            if (flagTextBox.Text != "" && !bindinglist.Contains(flagTextBox.Text))
            {
                Game1.p.flags.Add(flagTextBox.Text);
                bindinglist.Add(flagTextBox.Text);
            }
        }
    }
}
