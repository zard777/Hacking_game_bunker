﻿namespace SaltSaveEditor
{
	// Token: 0x02000222 RID: 546
	public class SanctuaryMgr
	{

		// Token: 0x06000B6C RID: 2924 RVA: 0x00116EB8 File Offset: 0x001150B8
		public static void Init()
		{
			int num;
			int i;
			int j;
			Layer layer;
			int k;
			Seg seg;
			XTexture xTexture;
			XSprite originalCell;
			num = 0;
			i = 0;
            SanctuaryMgr.sanctuaries = new Sanctuary[40];
            while (i < SanctuaryMgr.sanctuaries.Length)
			{
                SanctuaryMgr.sanctuaries[i] = null;
				i = i + 1;
			}
			j = 0;
			while (j < 2)
			{
				layer = Map.layer[(!(j != 0)) ? 15 : 5];
				k = 0;
				while (k < layer.seg.Length)
				{
					seg = layer.seg[k];
					if (!(!(seg != null)))
					{
						xTexture = Textures.tex[seg.textureIdx];
						originalCell = xTexture.GetOriginalCell(seg.idx);
						if (!(originalCell.flags != 11 || num >= SanctuaryMgr.sanctuaries.Length))
						{
                            SanctuaryMgr.sanctuaries[num] = new Sanctuary(seg, num);
							num = num + 1;
						}
					}
					k = k + 1;
				}
				j = j + 1;
			}
		}

		// Token: 0x04001A61 RID: 6753
		public const int SANCTUARY_ASHEN_SHORE = 0;

		// Token: 0x04001A62 RID: 6754
		public const int SANCTUARY_FORSAKEN_VILLAGE = 1;

		// Token: 0x04001A63 RID: 6755
		public const int SANCTUARY_BANDITS_PASS = 2;

		// Token: 0x04001A64 RID: 6756
		public const int SANCTUARY_CASTLE_OF_STORMS = 3;

		// Token: 0x04001A65 RID: 6757
		public const int SANCTUARY_SUNKEN_KEEP = 4;

		// Token: 0x04001A66 RID: 6758
		public const int SANCTUARY_RED_DUNGEON = 5;

		// Token: 0x04001A67 RID: 6759
		public const int SANCTUARY_LOST_WOODS = 6;

		// Token: 0x04001A68 RID: 6760
		public const int SANCTUARY_CAVES = 7;

		// Token: 0x04001A69 RID: 6761
		public const int SANCTUARY_SWAMP = 8;

		// Token: 0x04001A6A RID: 6762
		public const int SANCTUARY_DOME = 9;

		// Token: 0x04001A6B RID: 6763
		public const int SANCTUARY_SKY_CASTLE = 10;

		// Token: 0x04001A6C RID: 6764
		public const int SANCTUARY_DUNGEON_CAVE = 11;

		// Token: 0x04001A6D RID: 6765
		public const int SANCTUARY_FAR_BEACH = 12;

		// Token: 0x04001A6E RID: 6766
		public const int SANCTUARY_COASTAL_FORT = 13;

		// Token: 0x04001A6F RID: 6767
		public const int SANCTUARY_SIAM_LAKE = 14;

		// Token: 0x04001A70 RID: 6768
		public const int SANCTUARY_DARKWOOD = 15;

		// Token: 0x04001A71 RID: 6769
		public const int SANCTUARY_ZIGGURAT = 16;

		// Token: 0x04001A72 RID: 6770
		public const int SANCTUARY_RUINS = 17;

		// Token: 0x04001A73 RID: 6771
		public const int SHRINE_PARTY_FORT = 18;

		// Token: 0x04001A74 RID: 6772
		public const int SHRINE_SUNKEN_KEEP = 19;

		// Token: 0x04001A75 RID: 6773
		public const int SHRINE_RED_DUNGEON = 20;

		// Token: 0x04001A76 RID: 6774
		public const int SHRINE_DOME = 21;

		// Token: 0x04001A77 RID: 6775
		public const int SANCTUARY_LAB = 22;

		// Token: 0x04001A78 RID: 6776
		public const int SHRINE_SWAMP = 23;

		// Token: 0x04001A79 RID: 6777
		public const int SHRINE_CASTLE_OF_STORMS = 24;

		// Token: 0x04001A7A RID: 6778
		public const int SHRINE_CAVES = 25;

		// Token: 0x04001A7B RID: 6779
		public const int SANCTUARY_TOMB = 26;

		// Token: 0x04001A7C RID: 6780
		public const int SHRINE_TOMB = 27;

		// Token: 0x04001A7D RID: 6781
		public const int SHRINE_PALACE = 28;

		// Token: 0x04001A7E RID: 6782
		public const int SHRINE_DARKWOODS = 29;

		// Token: 0x04001A7F RID: 6783
		public const int SHRINE_UNKNOWN = 30;

		// Token: 0x04001A80 RID: 6784
		public const int SANCTUARY_BLACKEST_VAULT = 31;

		// Token: 0x04001A81 RID: 6785
		public const int MAX_SANCTUARIES = 40;

		// Token: 0x04001A82 RID: 6786
		public const int SANCTUARY_OTHER_CREED = 1000;

		// Token: 0x04001A83 RID: 6787
		public static Sanctuary[] sanctuaries;
	}
}
