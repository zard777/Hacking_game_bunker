﻿using System.IO;
using System.Reflection;

namespace SaltSaveEditor
{ 
	// Token: 0x02000020 RID: 32
	public class SkillTree
	{
		// Token: 0x0600009E RID: 158 RVA: 0x00007A0C File Offset: 0x00005C0C
		public static void Init()
		{
            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.skilltree.data.skilltree.zsx");
            BinaryReader br = new BinaryReader(_fileStream);
            SkillTree.Read(br);
            br.Close();
            /*	BinaryReader binaryReader;
                binaryReader = new BinaryReader(File.Open("skilltree/data/skilltree.zsx", FileMode.Open, FileAccess.Read));
                SkillTree.Read(binaryReader);
                binaryReader.Close();*/
        }

		// Token: 0x0600009F RID: 159 RVA: 0x00007A38 File Offset: 0x00005C38
		internal static void Read(BinaryReader reader)
		{
			int num;
			int i;
			int j;
			num = reader.ReadInt32();
			SkillTree.nodes = new SkillNode[num];
			i = 0;
			while (i < num)
			{
				SkillTree.nodes[i] = new SkillNode(reader, i);
				i = i + 1;
			}
			num = reader.ReadInt32();
			j = 0;
			while (j < num)
			{
                reader.ReadInt32();
                reader.ReadSingle();
                reader.ReadSingle();
                reader.ReadSingle();
                reader.ReadSingle();
                reader.ReadSingle();
                j = j + 1;
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00007C28 File Offset: 0x00005E28
		public SkillTree()
		{
		}

		// Token: 0x04000301 RID: 769
		public static SkillNode[] nodes;
	}
}
