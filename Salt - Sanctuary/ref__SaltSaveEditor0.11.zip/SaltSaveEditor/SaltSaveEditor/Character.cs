﻿namespace SaltSaveEditor
{
	// Token: 0x02000042 RID: 66
	public class Character
	{
		
		// Token: 0x0600014C RID: 332 RVA: 0x0000FAA0 File Offset: 0x0000DCA0
		public Character()
		{
			this.equipment = new CharEquipment();
		}


		// Token: 0x06000153 RID: 339 RVA: 0x00010ACA File Offset: 0x0000ECCA
		internal void SetPlayerIdx(int p)
		{
			this.equipment.active = true;
		}

		// Token: 0x04000638 RID: 1592
		public CharEquipment equipment;

	}
}
