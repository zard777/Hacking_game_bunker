﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace SaltSaveEditor
{
	// Token: 0x02000013 RID: 19
	public class LootCatalog
	{
		// Token: 0x06000050 RID: 80 RVA: 0x00003964 File Offset: 0x00001B64
		public LootCatalog()
		{
			int i;
			this.category = new LootCategory[8];
			i = 0;
			while (i < this.category.Length)
			{
				this.category[i] = new LootCategory();
				i = i + 1;
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x000039A4 File Offset: 0x00001BA4
		public void Read(BinaryReader reader)
		{
			int i;
			int j;
			int k;
			i = 0;
			while (i < this.category.Length)
			{
				this.category[i].Read(reader);
				i = i + 1;
			}
			j = 0;
			while (j < this.category.Length)
			{
				k = 0;
				while (k < this.category[j].loot.Length)
				{
					if (!(j != 2))
					{
						if (this.category[j].loot[k].name == "smallclothes_boots")
						{
							this.smallclothesBootsIdx = k;
						}
						if (this.category[j].loot[k].name == "smallclothes_armor")
						{
							this.smallclothesArmorIdx = k;
						}
					}
					k = k + 1;
				}
				j = j + 1;
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00003B6C File Offset: 0x00001D6C
		public void ReadMaster()
		{
            //FileMgr.Open("loot/data/loot.zlx");


            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.loot.data.loot.zlx");
            BinaryReader br = new BinaryReader(_fileStream);
            this.Read(br);
            br.Close();
			//FileMgr.Close();
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00003B88 File Offset: 0x00001D88
		internal int[] GetCategories(Player p)
		{
			List<int> list;
			int i;
			InvLoot invLoot;
			LootDef lootDef;
			list = new List<int>();
			i = 0;
			while (i < p.playerInv.inventory.Length)
			{
				invLoot = p.playerInv.inventory[i];
				if (!(!(invLoot != null)))
				{
					lootDef = this.category[invLoot.category].loot[invLoot.catalogIdx];
					if (!(!LootCatalog.CanSell(lootDef)))
					{
						switch (lootDef.category)
						{
						case 5:
						case 6:
						{
							break;
						}
						default:
						{
							if (!list.Contains(lootDef.category))
							{
								list.Add(lootDef.category);
							}
							break;
						}
						}
					}
				}
				i = i + 1;
			}
			return list.ToArray();
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00003C20 File Offset: 0x00001E20
		internal static bool CanSell(LootDef lDef)
		{
			int type;
			int type2;
			int type3;
			int flags;
			switch (lDef.category)
			{
			case 0:
			{
				type = lDef.type;
				if (!(type != 15))
				{
					return false;
				}
				break;
			}
			case 1:
			{
				type2 = lDef.type;
				if (!(type2 != 4))
				{
					return false;
				}
				break;
			}
			case 3:
			{
				type3 = lDef.type;
				if (!(type3 != 2))
				{
					return false;
				}
				break;
			}
			case 4:
			{
				flags = lDef.flags;
				switch (flags)
				{
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				case 8:
				case 9:
				{
					break;
				}
				default:
				{
					if (!(!(flags != 68)))
					{
						return true;
					}
					break;
				}
				}
				return false;
			}
			}
			return true;
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00003CB8 File Offset: 0x00001EB8
		internal int[] GetCategories(string[] loot)
		{
			List<int> list;
			int i;
			LootDef lootDef;
			int j;
			int k;
			list = new List<int>();
			i = 0;
			while (i < loot.Length)
			{
				lootDef = null;
				j = 0;
				while (j < this.category.Length)
				{
					k = 0;
					while (k < this.category[j].loot.Length)
					{
						if (this.category[j].loot[k].name == loot[i])
						{
							lootDef = this.category[j].loot[k];
						}
						k = k + 1;
					}
					j = j + 1;
				}
				if (!(!(lootDef != null) || list.Contains(lootDef.category)))
				{
					list.Add(lootDef.category);
				}
				i = i + 1;
			}
			return list.ToArray();
		}

		// Token: 0x0400009F RID: 159
		public const int CATEGORY_WEAPON = 0;

		// Token: 0x040000A0 RID: 160
		public const int CATEGORY_SHIELD = 1;

		// Token: 0x040000A1 RID: 161
		public const int CATEGORY_ARMOR = 2;

		// Token: 0x040000A2 RID: 162
		public const int CATEGORY_RING = 3;

		// Token: 0x040000A3 RID: 163
		public const int CATEGORY_CONSUMABLE = 4;

		// Token: 0x040000A4 RID: 164
		public const int CATEGORY_MAGIC = 5;

		// Token: 0x040000A5 RID: 165
		public const int CATEGORY_KEYS = 6;

		// Token: 0x040000A6 RID: 166
		public const int CATEGORY_MATERIALS = 7;

		// Token: 0x040000A7 RID: 167
		public const int TOTAL_CATEGORIES = 8;

		// Token: 0x040000A8 RID: 168
		public int smallclothesBootsIdx;

		// Token: 0x040000A9 RID: 169
		public int smallclothesArmorIdx;

		// Token: 0x040000AA RID: 170
		public LootCategory[] category;
	}
}
