﻿namespace SaltSaveEditor
{
	// Token: 0x0200000A RID: 10
	public class LocPair
	{
		// Token: 0x06000030 RID: 48 RVA: 0x00002C6C File Offset: 0x00000E6C
		public LocPair(int ID)
		{
			int i;
			this.orig = string.Concat("NEW_", ID.ToString());
			this.locStr = new string[7];
			i = 0;
			while (i < this.locStr.Length)
			{
				this.locStr[i] = "";
				i = i + 1;
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00002CC4 File Offset: 0x00000EC4
		public LocPair(string p)
		{
			int i;
			this.orig = p;
			this.locStr = new string[7];
			i = 0;
			while (i < this.locStr.Length)
			{
				this.locStr[i] = "";
				i = i + 1;
			}
		}

		// Token: 0x0400001B RID: 27
		public string orig;

		// Token: 0x0400001C RID: 28
		public string[] locStr;

		// Token: 0x0400001D RID: 29
		private string p;
	}
}
