﻿using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200018C RID: 396
	internal class ChallengeCatHealing : ChallengeCategory
	{
		// Token: 0x060007DA RID: 2010 RVA: 0x000B68D4 File Offset: 0x000B4AD4
		public ChallengeCatHealing(Player p)
		{
			this.itemStr = new StringBuilder[]
			{
				new StringBuilder(LocStrings.GetLocStr(426))
			};
			base.Init(p);
		}

		// Token: 0x04001226 RID: 4646
		public const int NO_HEALING = 0;
	}
}
