﻿using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x02000187 RID: 391
	public class ChallengeCategory
	{
		// Token: 0x060007D4 RID: 2004 RVA: 0x000B67A6 File Offset: 0x000B49A6
		public virtual void Init(Player p)
		{
			this.p = p;
			this.activeChallenge = -1;
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x000B67B6 File Offset: 0x000B49B6
		public ChallengeCategory()
		{
		}

		// Token: 0x0400121C RID: 4636
		private Player p;

		// Token: 0x0400121D RID: 4637
		public StringBuilder[] itemStr;

		// Token: 0x0400121E RID: 4638
		public int activeChallenge;
	}
}
