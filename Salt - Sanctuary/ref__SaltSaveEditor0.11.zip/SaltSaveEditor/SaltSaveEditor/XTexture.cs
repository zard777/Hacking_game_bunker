﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x0200002E RID: 46
	public class XTexture
	{
			
		// Token: 0x060000E1 RID: 225 RVA: 0x0000AE42 File Offset: 0x00009042
		public void Read(string path)
		{
			FileMgr.Open(path);
			this.ReadData(FileMgr.reader);
			FileMgr.Close();
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x0000AE5C File Offset: 0x0000905C
		public void ReadData(BinaryReader reader)
		{
			int num;
			int i;
			bool flag;
			XSprite xSprite;
			this.type = reader.ReadInt32();
			num = reader.ReadInt32();
			this.cell = new XSprite[num];
			i = 0;
			while (i < num)
			{
				flag = reader.ReadBoolean();
				if (!(!flag))
				{
					this.cell[i] = new XSprite();
					xSprite = this.cell[i];
					xSprite.name = reader.ReadString();
					xSprite.srcRect = new Rectangle(reader.ReadInt32(), reader.ReadInt32(), reader.ReadInt32(), reader.ReadInt32());
					xSprite.origin = new Vector2(reader.ReadSingle(), reader.ReadSingle());
					switch (this.type)
					{
					case 1:
					{
						xSprite.char_ref = reader.ReadInt32();
						xSprite.flags = reader.ReadInt32();
						break;
					}
					case 2:
					{
						xSprite.flags = reader.ReadInt32();
						break;
					}
					case 4:
					{
						xSprite.flags = reader.ReadInt32();
						break;
					}
					}
				}
				i = i + 1;
			}
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0000B001 File Offset: 0x00009201
		public string GetSpriteName(int idx)
		{
			if (!(idx >= this.cell.Length || !(this.cell[idx] != null)))
			{
				return this.cell[idx].name;
			}
			return "";
		}


		// Token: 0x060000EA RID: 234 RVA: 0x0000B245 File Offset: 0x00009445
		public XSprite GetOriginalCell(int idx)
		{
			return this.cell[idx];
		}


		// Token: 0x060000EC RID: 236 RVA: 0x0000B29F File Offset: 0x0000949F
		public int GetOriginalCellCount()
		{
			return this.cell.Length;
		}


		// Token: 0x060000EE RID: 238 RVA: 0x0000B4AC File Offset: 0x000096AC
		public XTexture(BinaryReader reader)
		{
			string a;
			this.name = "";
			this.ugcPackageIdx = -1;
			this.ugcSheetIdx = -1;
			this.name = reader.ReadString();
			this.ReadData(reader);
		}

		


		// Token: 0x040003DC RID: 988
		public const int TYPE_NORMAL = 0;

		// Token: 0x040003DD RID: 989
		public const int TYPE_CLOTHES = 1;

		// Token: 0x040003DE RID: 990
		public const int TYPE_MAP = 2;

		// Token: 0x040003DF RID: 991
		public const int TYPE_CHARACTER = 3;

		// Token: 0x040003E0 RID: 992
		public const int TYPE_CHAR = 4;

		// Token: 0x040003E1 RID: 993
		public const int TYPE_CHAR_VAR = 5;

		// Token: 0x040003E2 RID: 994
		public const int MAX_CELLS = 128;

		// Token: 0x040003E3 RID: 995
		public XSprite[] cell;

		// Token: 0x040003E5 RID: 997
		public string name;

		// Token: 0x040003E6 RID: 998
		public int ugcPackageIdx;

		// Token: 0x040003E7 RID: 999
		public int ugcSheetIdx;

		// Token: 0x040003E8 RID: 1000
		private bool isLoading;

		// Token: 0x040003E9 RID: 1001
		private bool isLoaded;

		// Token: 0x040003EA RID: 1002
		public bool needsUnload;

		// Token: 0x040003EB RID: 1003
		public int type;
	}
}
