﻿using System.IO;
using System.Reflection;

namespace SaltSaveEditor
{
	// Token: 0x0200001B RID: 27
	public class MonsterCatalog
	{
		// Token: 0x0600007D RID: 125 RVA: 0x0000550B File Offset: 0x0000370B
		public MonsterCatalog()
		{
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00005513 File Offset: 0x00003713
		internal void Write(BinaryWriter writer)
		{
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00005518 File Offset: 0x00003718
		internal void Read(BinaryReader reader)
		{
			int num;
			int i;
			num = reader.ReadInt32();
			this.catalog = new MonsterDef[num];
			i = 0;
			while (i < num)
			{
				this.catalog[i] = new MonsterDef(reader);
				i = i + 1;
			}
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00005554 File Offset: 0x00003754
		public int GetIdxFromString(string monster)
		{
			int i;
			i = 0;
			while (i < this.catalog.Length)
			{
				if (this.catalog[i].name == monster)
				{
					return i;
				}
				i = i + 1;
			}
			return -1;
		}

		// Token: 0x06000081 RID: 129 RVA: 0x0000558C File Offset: 0x0000378C
		public void ReadMaster()
		{
			int i;
			int j;
            //FileMgr.Open("monsters/data/monsters.zox");
            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.monsters.data.monsters.zox");
            BinaryReader br = new BinaryReader(_fileStream);
            this.Read(br);
            br.Close();
			//FileMgr.Close();
		}

		// Token: 0x04000226 RID: 550
		public MonsterDef[] catalog;
	}
}
