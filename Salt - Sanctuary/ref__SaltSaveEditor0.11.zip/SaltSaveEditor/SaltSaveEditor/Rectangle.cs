﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaltSaveEditor
{
    // Token: 0x020001FE RID: 510
    [Serializable]
    public struct Rectangle : IEquatable<Rectangle>
    {
        // Token: 0x1700031E RID: 798
        // (get) Token: 0x06000C35 RID: 3125 RVA: 0x0003F9A8 File Offset: 0x0003EDA8
        public int Left
        {
            get
            {
                return this.X;
            }
        }

        // Token: 0x1700031F RID: 799
        // (get) Token: 0x06000C36 RID: 3126 RVA: 0x0003F9BC File Offset: 0x0003EDBC
        public int Right
        {
            get
            {
                return this.X + this.Width;
            }
        }

        // Token: 0x17000320 RID: 800
        // (get) Token: 0x06000C37 RID: 3127 RVA: 0x0003F9D8 File Offset: 0x0003EDD8
        public int Top
        {
            get
            {
                return this.Y;
            }
        }

        // Token: 0x17000321 RID: 801
        // (get) Token: 0x06000C38 RID: 3128 RVA: 0x0003F9EC File Offset: 0x0003EDEC
        public int Bottom
        {
            get
            {
                return this.Y + this.Height;
            }
        }

        // Token: 0x17000322 RID: 802
        // (get) Token: 0x06000C39 RID: 3129 RVA: 0x0003FA08 File Offset: 0x0003EE08
        // (set) Token: 0x06000C3A RID: 3130 RVA: 0x0003FA28 File Offset: 0x0003EE28
        public Point Location
        {
            get
            {
                return new Point(this.X, this.Y);
            }
            set
            {
                this.X = value.X;
                this.Y = value.Y;
            }
        }

        // Token: 0x17000323 RID: 803
        // (get) Token: 0x06000C3B RID: 3131 RVA: 0x0003FA50 File Offset: 0x0003EE50
        public Point Center
        {
            get
            {
                return new Point(this.X + this.Width / 2, this.Y + this.Height / 2);
            }
        }

        // Token: 0x17000324 RID: 804
        // (get) Token: 0x06000C3C RID: 3132 RVA: 0x0003FA80 File Offset: 0x0003EE80
        public static Rectangle Empty
        {
            get
            {
                return Rectangle._empty;
            }
        }

        // Token: 0x17000325 RID: 805
        // (get) Token: 0x06000C3D RID: 3133 RVA: 0x0003FA94 File Offset: 0x0003EE94
        public bool IsEmpty
        {
            get
            {
                return !(this.Width != 0 || this.Height != 0 || this.X != 0) && this.Y == 0;
            }
        }

        // Token: 0x06000C3E RID: 3134 RVA: 0x0003FAC4 File Offset: 0x0003EEC4
        public Rectangle(int x, int y, int width, int height)
        {
            this.X = x;
            this.Y = y;
            this.Width = width;
            this.Height = height;
        }

        // Token: 0x06000C3F RID: 3135 RVA: 0x0003FAF0 File Offset: 0x0003EEF0
        public void Offset(Point amount)
        {
            this.X = this.X + amount.X;
            this.Y = this.Y + amount.Y;
        }

        // Token: 0x06000C40 RID: 3136 RVA: 0x0003FB28 File Offset: 0x0003EF28
        public void Offset(int offsetX, int offsetY)
        {
            this.X = this.X + offsetX;
            this.Y = this.Y + offsetY;
        }

        // Token: 0x06000C41 RID: 3137 RVA: 0x0003FB54 File Offset: 0x0003EF54
        public void Inflate(int horizontalAmount, int verticalAmount)
        {
            this.X = this.X - horizontalAmount;
            this.Y = this.Y - verticalAmount;
            this.Width = this.Width + horizontalAmount * 2;
            this.Height = this.Height + verticalAmount * 2;
        }

        // Token: 0x06000C42 RID: 3138 RVA: 0x0003FBA0 File Offset: 0x0003EFA0
        public bool Contains(int x, int y)
        {
            return !(this.X > x || x >= this.X + this.Width || this.Y > y) && y < this.Y + this.Height;
        }

        // Token: 0x06000C43 RID: 3139 RVA: 0x0003FBE4 File Offset: 0x0003EFE4
        public bool Contains(Point value)
        {
            return !(this.X > value.X || value.X >= this.X + this.Width || this.Y > value.Y) && value.Y < this.Y + this.Height;
        }

        // Token: 0x06000C44 RID: 3140 RVA: 0x0003FC40 File Offset: 0x0003F040
        public void Contains(ref Point value, out bool result)
        {
            result = (!(this.X > value.X || value.X >= this.X + this.Width || this.Y > value.Y) && value.Y < this.Y + this.Height);
        }

        // Token: 0x06000C45 RID: 3141 RVA: 0x0003FC98 File Offset: 0x0003F098
        public bool Contains(Rectangle value)
        {
            return !(this.X > value.X || value.X + value.Width > this.X + this.Width || this.Y > value.Y) && value.Y + value.Height <= this.Y + this.Height;
        }

        // Token: 0x06000C46 RID: 3142 RVA: 0x0003FD04 File Offset: 0x0003F104
        public void Contains(ref Rectangle value, out bool result)
        {
            result = (!(this.X > value.X || value.X + value.Width > this.X + this.Width || this.Y > value.Y) && value.Y + value.Height <= this.Y + this.Height);
        }

        // Token: 0x06000C47 RID: 3143 RVA: 0x0003FD70 File Offset: 0x0003F170
        public bool Intersects(Rectangle value)
        {
            return !(value.X >= this.X + this.Width || this.X >= value.X + value.Width || value.Y >= this.Y + this.Height) && this.Y < value.Y + value.Height;
        }

        // Token: 0x06000C48 RID: 3144 RVA: 0x0003FDDC File Offset: 0x0003F1DC
        public void Intersects(ref Rectangle value, out bool result)
        {
            result = (!(value.X >= this.X + this.Width || this.X >= value.X + value.Width || value.Y >= this.Y + this.Height) && this.Y < value.Y + value.Height);
        }

        // Token: 0x06000C49 RID: 3145 RVA: 0x0003FE44 File Offset: 0x0003F244
        public static Rectangle Intersect(Rectangle value1, Rectangle value2)
        {
            int num;
            int num2;
            int num3;
            int num4;
            int num5;
            int num6;
            int num7;
            int num8;
            Rectangle result;
            num = value1.X + value1.Width;
            num2 = value2.X + value2.Width;
            num3 = value1.Y + value1.Height;
            num4 = value2.Y + value2.Height;
            num5 = ((value1.X > value2.X) ? value1.X : value2.X);
            num6 = ((value1.Y > value2.Y) ? value1.Y : value2.Y);
            num7 = ((num < num2) ? num : num2);
            num8 = ((num3 < num4) ? num3 : num4);
            if (!(num7 <= num5 || num8 <= num6))
            {
                result.X = num5;
                result.Y = num6;
                result.Width = num7 - num5;
                result.Height = num8 - num6;
            }
            else
            {
                result.X = 0;
                result.Y = 0;
                result.Width = 0;
                result.Height = 0;
            }
            return result;
        }

        // Token: 0x06000C4A RID: 3146 RVA: 0x0003FF44 File Offset: 0x0003F344
        public static void Intersect(ref Rectangle value1, ref Rectangle value2, out Rectangle result)
        {
            int num;
            int num2;
            int num3;
            int num4;
            int num5;
            int num6;
            int num7;
            int num8;
            num = value1.X + value1.Width;
            num2 = value2.X + value2.Width;
            num3 = value1.Y + value1.Height;
            num4 = value2.Y + value2.Height;
            num5 = ((value1.X > value2.X) ? value1.X : value2.X);
            num6 = ((value1.Y > value2.Y) ? value1.Y : value2.Y);
            num7 = ((num < num2) ? num : num2);
            num8 = ((num3 < num4) ? num3 : num4);
            if (!(num7 <= num5 || num8 <= num6))
            {
                result.X = num5;
                result.Y = num6;
                result.Width = num7 - num5;
                result.Height = num8 - num6;
                return;
            }
            result.X = 0;
            result.Y = 0;
            result.Width = 0;
            result.Height = 0;
        }

        // Token: 0x06000C4B RID: 3147 RVA: 0x00040028 File Offset: 0x0003F428
        public static Rectangle Union(Rectangle value1, Rectangle value2)
        {
            int num;
            int num2;
            int num3;
            int num4;
            int num5;
            int num6;
            int num7;
            int num8;
            Rectangle result;
            num = value1.X + value1.Width;
            num2 = value2.X + value2.Width;
            num3 = value1.Y + value1.Height;
            num4 = value2.Y + value2.Height;
            num5 = ((value1.X < value2.X) ? value1.X : value2.X);
            num6 = ((value1.Y < value2.Y) ? value1.Y : value2.Y);
            num7 = ((num > num2) ? num : num2);
            num8 = ((num3 > num4) ? num3 : num4);
            result.X = num5;
            result.Y = num6;
            result.Width = num7 - num5;
            result.Height = num8 - num6;
            return result;
        }

        // Token: 0x06000C4C RID: 3148 RVA: 0x000400FC File Offset: 0x0003F4FC
        public static void Union(ref Rectangle value1, ref Rectangle value2, out Rectangle result)
        {
            int num;
            int num2;
            int num3;
            int num4;
            int num5;
            int num6;
            int num7;
            int num8;
            num = value1.X + value1.Width;
            num2 = value2.X + value2.Width;
            num3 = value1.Y + value1.Height;
            num4 = value2.Y + value2.Height;
            num5 = ((value1.X < value2.X) ? value1.X : value2.X);
            num6 = ((value1.Y < value2.Y) ? value1.Y : value2.Y);
            num7 = ((num > num2) ? num : num2);
            num8 = ((num3 > num4) ? num3 : num4);
            result.X = num5;
            result.Y = num6;
            result.Width = num7 - num5;
            result.Height = num8 - num6;
        }

        // Token: 0x06000C4D RID: 3149 RVA: 0x000401B8 File Offset: 0x0003F5B8
        public bool Equals(Rectangle other)
        {
            return !(this.X != other.X || this.Y != other.Y || this.Width != other.Width) && this.Height == other.Height;
        }


        // Token: 0x06000C50 RID: 3152 RVA: 0x00040290 File Offset: 0x0003F690
        public override int GetHashCode()
        {
            return this.X.GetHashCode() + this.Y.GetHashCode() + this.Width.GetHashCode() + this.Height.GetHashCode();
        }

        // Token: 0x06000C51 RID: 3153 RVA: 0x000402CC File Offset: 0x0003F6CC
        public static bool operator ==(Rectangle a, Rectangle b)
        {
            return !(a.X != b.X || a.Y != b.Y || a.Width != b.Width) && a.Height == b.Height;
        }

        // Token: 0x06000C52 RID: 3154 RVA: 0x0004031C File Offset: 0x0003F71C
        public static bool operator !=(Rectangle a, Rectangle b)
        {
            return a.X != b.X || a.Y != b.Y || a.Width != b.Width || a.Height != b.Height;
        }

        // Token: 0x06000C53 RID: 3155 RVA: 0x00040370 File Offset: 0x0003F770
        static Rectangle()
        {
            // Note: this type is marked as 'beforefieldinit'.
            Rectangle._empty = default(Rectangle);
        }

        // Token: 0x040005F0 RID: 1520
        public int X;

        // Token: 0x040005F1 RID: 1521
        public int Y;

        // Token: 0x040005F2 RID: 1522
        public int Width;

        // Token: 0x040005F3 RID: 1523
        public int Height;

        // Token: 0x040005F4 RID: 1524
        private static Rectangle _empty;
    }
}
