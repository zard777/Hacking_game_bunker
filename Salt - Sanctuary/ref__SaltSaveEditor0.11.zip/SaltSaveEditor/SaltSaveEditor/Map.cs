﻿using System;
using System.IO;
using System.Reflection;

namespace SaltSaveEditor
{
	// Token: 0x020001DD RID: 477
	public class Map
	{
		// Token: 0x06000965 RID: 2405 RVA: 0x000E78DC File Offset: 0x000E5ADC
		public static void ResetLayers()
		{
			int i;
			Map.layer = new Layer[20];
			i = 0;
			while (i < Map.layer.Length)
			{
				Map.layer[i] = new Layer();
				i = i + 1;
			}
			Map.layer[0].depth = 20f;
			Map.layer[1].depth = 12f;
			Map.layer[2].depth = 8f;
			Map.layer[3].depth = 4f;
			Map.layer[4].depth = 2f;
			Map.layer[5].depth = 1f;
			Map.layer[6].depth = 1f;
			Map.layer[7].depth = 0f;
			Map.layer[8].depth = -1f;
			Map.layer[9].depth = -2f;
			Map.layer[10].depth = -4f;
			Map.layer[11].depth = 12f;
			Map.layer[12].depth = 8f;
			Map.layer[13].depth = 4f;
			Map.layer[14].depth = 2f;
			Map.layer[15].depth = 1f;
			Map.layer[16].depth = 1f;
			Map.layer[17].depth = 0f;
			Map.layer[18].depth = -1f;
			Map.layer[19].depth = 1f;
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x000EE15C File Offset: 0x000EC35C
		public static void Read()
		{
			int i;
			int j;
			int num;
			int num2;
			int num3;
			int k;
			int l;
			int num4;
			int num5;
			int num6;
			int m;
            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.map.data.fortress.zax");
            BinaryReader br = new BinaryReader(_fileStream);

            //FileMgr.Open(string.Concat("map/data/", "fortress", ".zax"));
			Map.ResetLayers();
			Map.xUnits = br.ReadInt32();
			Map.yUnits = br.ReadInt32();
			Map.col = new Map.Col[Map.xUnits, Map.yUnits];
			i = 0;
			while (i < Map.layer.Length)
			{
				if (!(i != 19))
				{
					Map.layer[i].ReadEntities(br);
				}
				else
				{
					Map.layer[i].Read(br);
				}
				i = i + 1;
			}
			j = 0;
			while (j < Map.xUnits)
			{
				num = 0;
				while (true)
				{
					num2 = br.ReadInt32();
					if (!(!(num2 == -1)))
					{
						break;
					}
					num3 = (int)br.ReadByte();
					k = 0;
					while (k < num2)
					{
						Map.col[j, num].col = num3;
						num = num + 1;
						k = k + 1;
					}
				}
				j = j + 1;
			}
			l = 0;
			while (l < Map.xUnits)
			{
				num4 = 0;
				while (true)
				{
					num5 = br.ReadInt32();
					if (!(!(num5 == -1)))
					{
						break;
					}
					num6 = (int)br.ReadByte();
					m = 0;
					while (m < num5)
					{
						Map.col[l, num4].layer = num6;
						num4 = num4 + 1;
						m = m + 1;
					}
				}
				l = l + 1;
			}
			br.Close();
			Map.RefreshDepths();
		}

        public static void RefreshDepths()
        {
            int i;
            i = 0;
            while (i < 20)
            {
                Map.layer[i].RefreshDepths();
                i = i + 1;
            }
        }

	
		// Token: 0x04001605 RID: 5637
		public static Layer[] layer;

		// Token: 0x04001609 RID: 5641
		public static int xUnits;

		// Token: 0x0400160A RID: 5642
		public static int yUnits;

		// Token: 0x0400160B RID: 5643
		public static Map.Col[,] col;

		// Token: 0x020001DE RID: 478
		public struct Col
		{
			// Token: 0x0600097B RID: 2427 RVA: 0x000EE464 File Offset: 0x000EC664
			internal void Read(BinaryReader reader)
			{
				this.col = (int)reader.ReadByte();
				this.layer = (int)reader.ReadByte();
			}

			// Token: 0x0600097C RID: 2428 RVA: 0x000EE47E File Offset: 0x000EC67E
			internal void Write(BinaryWriter writer)
			{
				writer.Write((byte)this.col);
				writer.Write((byte)this.layer);
			}

			// Token: 0x04001616 RID: 5654
			public int col;

			// Token: 0x04001617 RID: 5655
			public int layer;
		}

	}
}
