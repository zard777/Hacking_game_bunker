﻿namespace SaltSaveEditor
{
    public class Vector2
    {
        public float X;
        public float Y;

        public Vector2(float v1, float v2)
        {
            this.X = v1;
            this.Y = v2;
        }
    }
}