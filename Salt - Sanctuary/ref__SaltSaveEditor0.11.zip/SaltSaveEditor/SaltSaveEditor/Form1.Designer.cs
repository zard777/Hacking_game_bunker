﻿namespace SaltSaveEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goodbyeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.killsBox = new System.Windows.Forms.TextBox();
            this.deathsBox = new System.Windows.Forms.TextBox();
            this.restCountBox = new System.Windows.Forms.TextBox();
            this.corruptionBox = new System.Windows.Forms.TextBox();
            this.playthroughBox = new System.Windows.Forms.TextBox();
            this.expungedBox = new System.Windows.Forms.TextBox();
            this.saltBox = new System.Windows.Forms.TextBox();
            this.goldBox = new System.Windows.Forms.TextBox();
            this.hardcoreCheck = new System.Windows.Forms.CheckBox();
            this.creedBox = new System.Windows.Forms.ComboBox();
            this.ironStanding = new System.Windows.Forms.ComboBox();
            this.devaraStanding = new System.Windows.Forms.ComboBox();
            this.threeStanding = new System.Windows.Forms.ComboBox();
            this.stoneStanding = new System.Windows.Forms.ComboBox();
            this.darkStanding = new System.Windows.Forms.ComboBox();
            this.splendorStanding = new System.Windows.Forms.ComboBox();
            this.keeperStanding = new System.Windows.Forms.ComboBox();
            this.keeperLevel = new System.Windows.Forms.ComboBox();
            this.splendorLevel = new System.Windows.Forms.ComboBox();
            this.darkLevel = new System.Windows.Forms.ComboBox();
            this.stoneLevel = new System.Windows.Forms.ComboBox();
            this.threeLevel = new System.Windows.Forms.ComboBox();
            this.devaraLevel = new System.Windows.Forms.ComboBox();
            this.ironLevel = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lastSanctuaryComboBox = new System.Windows.Forms.ComboBox();
            this.tabs = new System.Windows.Forms.TabControl();
            this.inventoryTab = new System.Windows.Forms.TabPage();
            this.materialsEdit = new System.Windows.Forms.Button();
            this.keysEdit = new System.Windows.Forms.Button();
            this.spellsEdit = new System.Windows.Forms.Button();
            this.utilityEdit = new System.Windows.Forms.Button();
            this.ringsEdit = new System.Windows.Forms.Button();
            this.armorEdit = new System.Windows.Forms.Button();
            this.shieldEdit = new System.Windows.Forms.Button();
            this.weaponEdit = new System.Windows.Forms.Button();
            this.materialsAdd = new System.Windows.Forms.Button();
            this.keysAdd = new System.Windows.Forms.Button();
            this.spellsAdd = new System.Windows.Forms.Button();
            this.utilityAdd = new System.Windows.Forms.Button();
            this.ringsAdd = new System.Windows.Forms.Button();
            this.armorAdd = new System.Windows.Forms.Button();
            this.shieldAdd = new System.Windows.Forms.Button();
            this.weaponAdd = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.materialsComboBox = new System.Windows.Forms.ComboBox();
            this.ringsComboBox = new System.Windows.Forms.ComboBox();
            this.keysComboBox = new System.Windows.Forms.ComboBox();
            this.spellsComboBox = new System.Windows.Forms.ComboBox();
            this.utilityComboBox = new System.Windows.Forms.ComboBox();
            this.armorComboBox = new System.Windows.Forms.ComboBox();
            this.shieldsComboBox = new System.Windows.Forms.ComboBox();
            this.weaponComboBox = new System.Windows.Forms.ComboBox();
            this.sanctuaryTab = new System.Windows.Forms.TabPage();
            this.merchant4ComboBox = new System.Windows.Forms.ComboBox();
            this.merchant3ComboBox = new System.Windows.Forms.ComboBox();
            this.merchant2ComboBox = new System.Windows.Forms.ComboBox();
            this.merchant1ComboBox = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.sanctuaryCreedComboBox = new System.Windows.Forms.ComboBox();
            this.sanctuaryCreedListComboBox = new System.Windows.Forms.ComboBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.flagsTab = new System.Windows.Forms.TabPage();
            this.playerflagsComboBox = new System.Windows.Forms.ComboBox();
            this.removeFlagButton = new System.Windows.Forms.Button();
            this.addFlagButton = new System.Windows.Forms.Button();
            this.flagTextBox = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.addflagManuallyButton = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.tabs.SuspendLayout();
            this.inventoryTab.SuspendLayout();
            this.sanctuaryTab.SuspendLayout();
            this.flagsTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1166, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadMenuItem,
            this.saveMenuItem,
            this.goodbyeMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadMenuItem
            // 
            this.loadMenuItem.Name = "loadMenuItem";
            this.loadMenuItem.Size = new System.Drawing.Size(122, 22);
            this.loadMenuItem.Text = "Load";
            this.loadMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // saveMenuItem
            // 
            this.saveMenuItem.Name = "saveMenuItem";
            this.saveMenuItem.Size = new System.Drawing.Size(122, 22);
            this.saveMenuItem.Text = "Save";
            this.saveMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // goodbyeMenuItem
            // 
            this.goodbyeMenuItem.Name = "goodbyeMenuItem";
            this.goodbyeMenuItem.Size = new System.Drawing.Size(122, 22);
            this.goodbyeMenuItem.Text = "Goodbye";
            this.goodbyeMenuItem.Click += new System.EventHandler(this.goodbyeMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hardcore";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Kills";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Deaths";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Sanctuary Rest Count";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Corruption";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 177);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Playthrough number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 199);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Current Creed";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 250);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "The Iron Ones";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 272);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Devara\'s Light";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 294);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "The Three";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 316);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 13;
            this.label13.Text = "Stone Roots";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 338);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Order of the Betrayer";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 360);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 13);
            this.label15.TabIndex = 15;
            this.label15.Text = "House of Splendor";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 382);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "Keepers of Fire and Sky";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 404);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 13);
            this.label17.TabIndex = 17;
            this.label17.Text = "Expunged Count";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 427);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 13);
            this.label18.TabIndex = 18;
            this.label18.Text = "Salt";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 449);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 13);
            this.label19.TabIndex = 19;
            this.label19.Text = "Gold";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(153, 33);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(100, 20);
            this.nameBox.TabIndex = 20;
            this.nameBox.TextChanged += new System.EventHandler(this.nameBox_TextChanged);
            // 
            // killsBox
            // 
            this.killsBox.Location = new System.Drawing.Point(153, 82);
            this.killsBox.Name = "killsBox";
            this.killsBox.Size = new System.Drawing.Size(100, 20);
            this.killsBox.TabIndex = 22;
            this.killsBox.TextChanged += new System.EventHandler(this.killsBox_TextChanged);
            // 
            // deathsBox
            // 
            this.deathsBox.Location = new System.Drawing.Point(153, 106);
            this.deathsBox.Name = "deathsBox";
            this.deathsBox.Size = new System.Drawing.Size(100, 20);
            this.deathsBox.TabIndex = 23;
            this.deathsBox.TextChanged += new System.EventHandler(this.deathsBox_TextChanged);
            // 
            // restCountBox
            // 
            this.restCountBox.Location = new System.Drawing.Point(153, 128);
            this.restCountBox.Name = "restCountBox";
            this.restCountBox.Size = new System.Drawing.Size(100, 20);
            this.restCountBox.TabIndex = 24;
            this.restCountBox.TextChanged += new System.EventHandler(this.restCountBox_TextChanged);
            // 
            // corruptionBox
            // 
            this.corruptionBox.Location = new System.Drawing.Point(153, 150);
            this.corruptionBox.Name = "corruptionBox";
            this.corruptionBox.Size = new System.Drawing.Size(100, 20);
            this.corruptionBox.TabIndex = 25;
            this.corruptionBox.TextChanged += new System.EventHandler(this.corruptionBox_TextChanged);
            // 
            // playthroughBox
            // 
            this.playthroughBox.Location = new System.Drawing.Point(153, 174);
            this.playthroughBox.Name = "playthroughBox";
            this.playthroughBox.Size = new System.Drawing.Size(100, 20);
            this.playthroughBox.TabIndex = 26;
            this.playthroughBox.TextChanged += new System.EventHandler(this.playthroughBox_TextChanged);
            // 
            // expungedBox
            // 
            this.expungedBox.Location = new System.Drawing.Point(153, 401);
            this.expungedBox.Name = "expungedBox";
            this.expungedBox.Size = new System.Drawing.Size(100, 20);
            this.expungedBox.TabIndex = 27;
            this.expungedBox.TextChanged += new System.EventHandler(this.expungedBox_TextChanged);
            // 
            // saltBox
            // 
            this.saltBox.Location = new System.Drawing.Point(153, 424);
            this.saltBox.Name = "saltBox";
            this.saltBox.Size = new System.Drawing.Size(100, 20);
            this.saltBox.TabIndex = 28;
            this.saltBox.TextChanged += new System.EventHandler(this.saltBox_TextChanged);
            // 
            // goldBox
            // 
            this.goldBox.Location = new System.Drawing.Point(153, 446);
            this.goldBox.Name = "goldBox";
            this.goldBox.Size = new System.Drawing.Size(100, 20);
            this.goldBox.TabIndex = 29;
            this.goldBox.TextChanged += new System.EventHandler(this.goldBox_TextChanged);
            // 
            // hardcoreCheck
            // 
            this.hardcoreCheck.AutoSize = true;
            this.hardcoreCheck.Location = new System.Drawing.Point(153, 60);
            this.hardcoreCheck.Name = "hardcoreCheck";
            this.hardcoreCheck.Size = new System.Drawing.Size(15, 14);
            this.hardcoreCheck.TabIndex = 30;
            this.hardcoreCheck.UseVisualStyleBackColor = true;
            this.hardcoreCheck.CheckedChanged += new System.EventHandler(this.hardcoreCheck_CheckedChanged);
            // 
            // creedBox
            // 
            this.creedBox.FormattingEnabled = true;
            this.creedBox.Location = new System.Drawing.Point(153, 196);
            this.creedBox.Name = "creedBox";
            this.creedBox.Size = new System.Drawing.Size(121, 21);
            this.creedBox.TabIndex = 31;
            this.creedBox.SelectedIndexChanged += new System.EventHandler(this.creedBox_SelectedIndexChanged);
            // 
            // ironStanding
            // 
            this.ironStanding.FormattingEnabled = true;
            this.ironStanding.Location = new System.Drawing.Point(153, 247);
            this.ironStanding.Name = "ironStanding";
            this.ironStanding.Size = new System.Drawing.Size(121, 21);
            this.ironStanding.TabIndex = 32;
            this.ironStanding.SelectedIndexChanged += new System.EventHandler(this.ironStanding_SelectedIndexChanged);
            // 
            // devaraStanding
            // 
            this.devaraStanding.FormattingEnabled = true;
            this.devaraStanding.Location = new System.Drawing.Point(153, 269);
            this.devaraStanding.Name = "devaraStanding";
            this.devaraStanding.Size = new System.Drawing.Size(121, 21);
            this.devaraStanding.TabIndex = 33;
            this.devaraStanding.SelectedIndexChanged += new System.EventHandler(this.devaraStanding_SelectedIndexChanged);
            // 
            // threeStanding
            // 
            this.threeStanding.FormattingEnabled = true;
            this.threeStanding.Location = new System.Drawing.Point(153, 291);
            this.threeStanding.Name = "threeStanding";
            this.threeStanding.Size = new System.Drawing.Size(121, 21);
            this.threeStanding.TabIndex = 34;
            this.threeStanding.SelectedIndexChanged += new System.EventHandler(this.threeStanding_SelectedIndexChanged);
            // 
            // stoneStanding
            // 
            this.stoneStanding.FormattingEnabled = true;
            this.stoneStanding.Location = new System.Drawing.Point(153, 313);
            this.stoneStanding.Name = "stoneStanding";
            this.stoneStanding.Size = new System.Drawing.Size(121, 21);
            this.stoneStanding.TabIndex = 35;
            this.stoneStanding.SelectedIndexChanged += new System.EventHandler(this.stoneStanding_SelectedIndexChanged);
            // 
            // darkStanding
            // 
            this.darkStanding.FormattingEnabled = true;
            this.darkStanding.Location = new System.Drawing.Point(153, 335);
            this.darkStanding.Name = "darkStanding";
            this.darkStanding.Size = new System.Drawing.Size(121, 21);
            this.darkStanding.TabIndex = 36;
            this.darkStanding.SelectedIndexChanged += new System.EventHandler(this.darkStanding_SelectedIndexChanged);
            // 
            // splendorStanding
            // 
            this.splendorStanding.FormattingEnabled = true;
            this.splendorStanding.Location = new System.Drawing.Point(153, 357);
            this.splendorStanding.Name = "splendorStanding";
            this.splendorStanding.Size = new System.Drawing.Size(121, 21);
            this.splendorStanding.TabIndex = 37;
            this.splendorStanding.SelectedIndexChanged += new System.EventHandler(this.splendorStanding_SelectedIndexChanged);
            // 
            // keeperStanding
            // 
            this.keeperStanding.FormattingEnabled = true;
            this.keeperStanding.Location = new System.Drawing.Point(153, 379);
            this.keeperStanding.Name = "keeperStanding";
            this.keeperStanding.Size = new System.Drawing.Size(121, 21);
            this.keeperStanding.TabIndex = 38;
            this.keeperStanding.SelectedIndexChanged += new System.EventHandler(this.keeperStanding_SelectedIndexChanged);
            // 
            // keeperLevel
            // 
            this.keeperLevel.FormattingEnabled = true;
            this.keeperLevel.Location = new System.Drawing.Point(280, 379);
            this.keeperLevel.Name = "keeperLevel";
            this.keeperLevel.Size = new System.Drawing.Size(121, 21);
            this.keeperLevel.TabIndex = 45;
            this.keeperLevel.SelectedIndexChanged += new System.EventHandler(this.keeperLevel_SelectedIndexChanged);
            // 
            // splendorLevel
            // 
            this.splendorLevel.FormattingEnabled = true;
            this.splendorLevel.Location = new System.Drawing.Point(280, 357);
            this.splendorLevel.Name = "splendorLevel";
            this.splendorLevel.Size = new System.Drawing.Size(121, 21);
            this.splendorLevel.TabIndex = 44;
            this.splendorLevel.SelectedIndexChanged += new System.EventHandler(this.splendorLevel_SelectedIndexChanged);
            // 
            // darkLevel
            // 
            this.darkLevel.FormattingEnabled = true;
            this.darkLevel.Location = new System.Drawing.Point(280, 335);
            this.darkLevel.Name = "darkLevel";
            this.darkLevel.Size = new System.Drawing.Size(121, 21);
            this.darkLevel.TabIndex = 43;
            this.darkLevel.SelectedIndexChanged += new System.EventHandler(this.darkLevel_SelectedIndexChanged);
            // 
            // stoneLevel
            // 
            this.stoneLevel.FormattingEnabled = true;
            this.stoneLevel.Location = new System.Drawing.Point(280, 313);
            this.stoneLevel.Name = "stoneLevel";
            this.stoneLevel.Size = new System.Drawing.Size(121, 21);
            this.stoneLevel.TabIndex = 42;
            this.stoneLevel.SelectedIndexChanged += new System.EventHandler(this.stoneLevel_SelectedIndexChanged);
            // 
            // threeLevel
            // 
            this.threeLevel.FormattingEnabled = true;
            this.threeLevel.Location = new System.Drawing.Point(280, 291);
            this.threeLevel.Name = "threeLevel";
            this.threeLevel.Size = new System.Drawing.Size(121, 21);
            this.threeLevel.TabIndex = 41;
            this.threeLevel.SelectedIndexChanged += new System.EventHandler(this.threeLevel_SelectedIndexChanged);
            // 
            // devaraLevel
            // 
            this.devaraLevel.FormattingEnabled = true;
            this.devaraLevel.Location = new System.Drawing.Point(280, 269);
            this.devaraLevel.Name = "devaraLevel";
            this.devaraLevel.Size = new System.Drawing.Size(121, 21);
            this.devaraLevel.TabIndex = 40;
            this.devaraLevel.SelectedIndexChanged += new System.EventHandler(this.devaraLevel_SelectedIndexChanged);
            // 
            // ironLevel
            // 
            this.ironLevel.FormattingEnabled = true;
            this.ironLevel.Location = new System.Drawing.Point(280, 247);
            this.ironLevel.Name = "ironLevel";
            this.ironLevel.Size = new System.Drawing.Size(121, 21);
            this.ironLevel.TabIndex = 39;
            this.ironLevel.SelectedIndexChanged += new System.EventHandler(this.ironLevel_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 224);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 46;
            this.label8.Text = "Last Sanctuary";
            // 
            // lastSanctuaryComboBox
            // 
            this.lastSanctuaryComboBox.FormattingEnabled = true;
            this.lastSanctuaryComboBox.Location = new System.Drawing.Point(153, 221);
            this.lastSanctuaryComboBox.Name = "lastSanctuaryComboBox";
            this.lastSanctuaryComboBox.Size = new System.Drawing.Size(248, 21);
            this.lastSanctuaryComboBox.TabIndex = 47;
            this.lastSanctuaryComboBox.SelectedIndexChanged += new System.EventHandler(this.lastSanctuaryComboBox_SelectedIndexChanged);
            // 
            // tabs
            // 
            this.tabs.Controls.Add(this.inventoryTab);
            this.tabs.Controls.Add(this.sanctuaryTab);
            this.tabs.Controls.Add(this.flagsTab);
            this.tabs.Location = new System.Drawing.Point(430, 28);
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.tabs.Size = new System.Drawing.Size(723, 438);
            this.tabs.TabIndex = 48;
            // 
            // inventoryTab
            // 
            this.inventoryTab.BackColor = System.Drawing.Color.White;
            this.inventoryTab.Controls.Add(this.materialsEdit);
            this.inventoryTab.Controls.Add(this.keysEdit);
            this.inventoryTab.Controls.Add(this.spellsEdit);
            this.inventoryTab.Controls.Add(this.utilityEdit);
            this.inventoryTab.Controls.Add(this.ringsEdit);
            this.inventoryTab.Controls.Add(this.armorEdit);
            this.inventoryTab.Controls.Add(this.shieldEdit);
            this.inventoryTab.Controls.Add(this.weaponEdit);
            this.inventoryTab.Controls.Add(this.materialsAdd);
            this.inventoryTab.Controls.Add(this.keysAdd);
            this.inventoryTab.Controls.Add(this.spellsAdd);
            this.inventoryTab.Controls.Add(this.utilityAdd);
            this.inventoryTab.Controls.Add(this.ringsAdd);
            this.inventoryTab.Controls.Add(this.armorAdd);
            this.inventoryTab.Controls.Add(this.shieldAdd);
            this.inventoryTab.Controls.Add(this.weaponAdd);
            this.inventoryTab.Controls.Add(this.label27);
            this.inventoryTab.Controls.Add(this.label26);
            this.inventoryTab.Controls.Add(this.label25);
            this.inventoryTab.Controls.Add(this.label24);
            this.inventoryTab.Controls.Add(this.label23);
            this.inventoryTab.Controls.Add(this.label22);
            this.inventoryTab.Controls.Add(this.label21);
            this.inventoryTab.Controls.Add(this.label20);
            this.inventoryTab.Controls.Add(this.materialsComboBox);
            this.inventoryTab.Controls.Add(this.ringsComboBox);
            this.inventoryTab.Controls.Add(this.keysComboBox);
            this.inventoryTab.Controls.Add(this.spellsComboBox);
            this.inventoryTab.Controls.Add(this.utilityComboBox);
            this.inventoryTab.Controls.Add(this.armorComboBox);
            this.inventoryTab.Controls.Add(this.shieldsComboBox);
            this.inventoryTab.Controls.Add(this.weaponComboBox);
            this.inventoryTab.Location = new System.Drawing.Point(4, 22);
            this.inventoryTab.Name = "inventoryTab";
            this.inventoryTab.Padding = new System.Windows.Forms.Padding(3);
            this.inventoryTab.Size = new System.Drawing.Size(715, 412);
            this.inventoryTab.TabIndex = 1;
            this.inventoryTab.Text = "Inventory";
            // 
            // materialsEdit
            // 
            this.materialsEdit.Location = new System.Drawing.Point(625, 383);
            this.materialsEdit.Name = "materialsEdit";
            this.materialsEdit.Size = new System.Drawing.Size(79, 23);
            this.materialsEdit.TabIndex = 31;
            this.materialsEdit.Text = "Edit Item";
            this.materialsEdit.UseVisualStyleBackColor = true;
            this.materialsEdit.Click += new System.EventHandler(this.materialsEdit_Click);
            // 
            // keysEdit
            // 
            this.keysEdit.Location = new System.Drawing.Point(449, 383);
            this.keysEdit.Name = "keysEdit";
            this.keysEdit.Size = new System.Drawing.Size(79, 23);
            this.keysEdit.TabIndex = 30;
            this.keysEdit.Text = "Edit Item";
            this.keysEdit.UseVisualStyleBackColor = true;
            this.keysEdit.Click += new System.EventHandler(this.keysEdit_Click);
            // 
            // spellsEdit
            // 
            this.spellsEdit.Location = new System.Drawing.Point(273, 383);
            this.spellsEdit.Name = "spellsEdit";
            this.spellsEdit.Size = new System.Drawing.Size(79, 23);
            this.spellsEdit.TabIndex = 29;
            this.spellsEdit.Text = "Edit Item";
            this.spellsEdit.UseVisualStyleBackColor = true;
            this.spellsEdit.Click += new System.EventHandler(this.spellsEdit_Click);
            // 
            // utilityEdit
            // 
            this.utilityEdit.Location = new System.Drawing.Point(97, 383);
            this.utilityEdit.Name = "utilityEdit";
            this.utilityEdit.Size = new System.Drawing.Size(79, 23);
            this.utilityEdit.TabIndex = 28;
            this.utilityEdit.Text = "Edit Item";
            this.utilityEdit.UseVisualStyleBackColor = true;
            this.utilityEdit.Click += new System.EventHandler(this.utilityEdit_Click);
            // 
            // ringsEdit
            // 
            this.ringsEdit.Location = new System.Drawing.Point(625, 181);
            this.ringsEdit.Name = "ringsEdit";
            this.ringsEdit.Size = new System.Drawing.Size(79, 23);
            this.ringsEdit.TabIndex = 27;
            this.ringsEdit.Text = "Edit Item";
            this.ringsEdit.UseVisualStyleBackColor = true;
            this.ringsEdit.Click += new System.EventHandler(this.ringsEdit_Click);
            // 
            // armorEdit
            // 
            this.armorEdit.Location = new System.Drawing.Point(449, 181);
            this.armorEdit.Name = "armorEdit";
            this.armorEdit.Size = new System.Drawing.Size(79, 23);
            this.armorEdit.TabIndex = 26;
            this.armorEdit.Text = "Edit Item";
            this.armorEdit.UseVisualStyleBackColor = true;
            this.armorEdit.Click += new System.EventHandler(this.armorEdit_Click);
            // 
            // shieldEdit
            // 
            this.shieldEdit.Location = new System.Drawing.Point(273, 181);
            this.shieldEdit.Name = "shieldEdit";
            this.shieldEdit.Size = new System.Drawing.Size(79, 23);
            this.shieldEdit.TabIndex = 25;
            this.shieldEdit.Text = "Edit Item";
            this.shieldEdit.UseVisualStyleBackColor = true;
            this.shieldEdit.Click += new System.EventHandler(this.shieldEdit_Click);
            // 
            // weaponEdit
            // 
            this.weaponEdit.Location = new System.Drawing.Point(97, 181);
            this.weaponEdit.Name = "weaponEdit";
            this.weaponEdit.Size = new System.Drawing.Size(79, 23);
            this.weaponEdit.TabIndex = 24;
            this.weaponEdit.Text = "Edit Item";
            this.weaponEdit.UseVisualStyleBackColor = true;
            this.weaponEdit.Click += new System.EventHandler(this.weaponEdit_Click);
            // 
            // materialsAdd
            // 
            this.materialsAdd.Location = new System.Drawing.Point(534, 383);
            this.materialsAdd.Name = "materialsAdd";
            this.materialsAdd.Size = new System.Drawing.Size(85, 23);
            this.materialsAdd.TabIndex = 23;
            this.materialsAdd.Text = "Add Item";
            this.materialsAdd.UseVisualStyleBackColor = true;
            this.materialsAdd.Click += new System.EventHandler(this.materialsAdd_Click);
            // 
            // keysAdd
            // 
            this.keysAdd.Location = new System.Drawing.Point(358, 383);
            this.keysAdd.Name = "keysAdd";
            this.keysAdd.Size = new System.Drawing.Size(85, 23);
            this.keysAdd.TabIndex = 22;
            this.keysAdd.Text = "Add Item";
            this.keysAdd.UseVisualStyleBackColor = true;
            this.keysAdd.Click += new System.EventHandler(this.keysAdd_Click);
            // 
            // spellsAdd
            // 
            this.spellsAdd.Location = new System.Drawing.Point(182, 383);
            this.spellsAdd.Name = "spellsAdd";
            this.spellsAdd.Size = new System.Drawing.Size(84, 23);
            this.spellsAdd.TabIndex = 21;
            this.spellsAdd.Text = "Add Item";
            this.spellsAdd.UseVisualStyleBackColor = true;
            this.spellsAdd.Click += new System.EventHandler(this.spellsAdd_Click);
            // 
            // utilityAdd
            // 
            this.utilityAdd.Location = new System.Drawing.Point(6, 383);
            this.utilityAdd.Name = "utilityAdd";
            this.utilityAdd.Size = new System.Drawing.Size(85, 23);
            this.utilityAdd.TabIndex = 20;
            this.utilityAdd.Text = "Add Item";
            this.utilityAdd.UseVisualStyleBackColor = true;
            this.utilityAdd.Click += new System.EventHandler(this.utilityAdd_Click);
            // 
            // ringsAdd
            // 
            this.ringsAdd.Location = new System.Drawing.Point(534, 181);
            this.ringsAdd.Name = "ringsAdd";
            this.ringsAdd.Size = new System.Drawing.Size(85, 23);
            this.ringsAdd.TabIndex = 19;
            this.ringsAdd.Text = "Add Item";
            this.ringsAdd.UseVisualStyleBackColor = true;
            this.ringsAdd.Click += new System.EventHandler(this.ringsAdd_Click);
            // 
            // armorAdd
            // 
            this.armorAdd.Location = new System.Drawing.Point(358, 181);
            this.armorAdd.Name = "armorAdd";
            this.armorAdd.Size = new System.Drawing.Size(85, 23);
            this.armorAdd.TabIndex = 18;
            this.armorAdd.Text = "Add Item";
            this.armorAdd.UseVisualStyleBackColor = true;
            this.armorAdd.Click += new System.EventHandler(this.armorAdd_Click);
            // 
            // shieldAdd
            // 
            this.shieldAdd.Location = new System.Drawing.Point(182, 181);
            this.shieldAdd.Name = "shieldAdd";
            this.shieldAdd.Size = new System.Drawing.Size(84, 23);
            this.shieldAdd.TabIndex = 17;
            this.shieldAdd.Text = "Add Item";
            this.shieldAdd.UseVisualStyleBackColor = true;
            this.shieldAdd.Click += new System.EventHandler(this.shieldAdd_Click);
            // 
            // weaponAdd
            // 
            this.weaponAdd.Location = new System.Drawing.Point(6, 181);
            this.weaponAdd.Name = "weaponAdd";
            this.weaponAdd.Size = new System.Drawing.Size(85, 23);
            this.weaponAdd.TabIndex = 16;
            this.weaponAdd.Text = "Add Item";
            this.weaponAdd.UseVisualStyleBackColor = true;
            this.weaponAdd.Click += new System.EventHandler(this.weaponAdd_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(531, 214);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(49, 13);
            this.label27.TabIndex = 15;
            this.label27.Text = "Materials";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(355, 214);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(92, 13);
            this.label26.TabIndex = 14;
            this.label26.Text = "Keys + bloody writ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(179, 214);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 13;
            this.label25.Text = "Spells";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 214);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 12;
            this.label24.Text = "Utility";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(531, 11);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(126, 13);
            this.label23.TabIndex = 11;
            this.label23.Text = "Rings + Charms + Brands";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(355, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 13);
            this.label22.TabIndex = 10;
            this.label22.Text = "Armor";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(179, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 13);
            this.label21.TabIndex = 9;
            this.label21.Text = "Shields";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 11);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "Weapons";
            // 
            // materialsComboBox
            // 
            this.materialsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.materialsComboBox.FormattingEnabled = true;
            this.materialsComboBox.Location = new System.Drawing.Point(534, 230);
            this.materialsComboBox.Name = "materialsComboBox";
            this.materialsComboBox.Size = new System.Drawing.Size(170, 150);
            this.materialsComboBox.TabIndex = 7;
            // 
            // ringsComboBox
            // 
            this.ringsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.ringsComboBox.FormattingEnabled = true;
            this.ringsComboBox.Location = new System.Drawing.Point(534, 28);
            this.ringsComboBox.Name = "ringsComboBox";
            this.ringsComboBox.Size = new System.Drawing.Size(170, 150);
            this.ringsComboBox.TabIndex = 6;
            // 
            // keysComboBox
            // 
            this.keysComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.keysComboBox.FormattingEnabled = true;
            this.keysComboBox.Location = new System.Drawing.Point(358, 230);
            this.keysComboBox.Name = "keysComboBox";
            this.keysComboBox.Size = new System.Drawing.Size(170, 150);
            this.keysComboBox.TabIndex = 5;
            // 
            // spellsComboBox
            // 
            this.spellsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.spellsComboBox.FormattingEnabled = true;
            this.spellsComboBox.Location = new System.Drawing.Point(182, 230);
            this.spellsComboBox.Name = "spellsComboBox";
            this.spellsComboBox.Size = new System.Drawing.Size(170, 150);
            this.spellsComboBox.TabIndex = 4;
            // 
            // utilityComboBox
            // 
            this.utilityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.utilityComboBox.FormattingEnabled = true;
            this.utilityComboBox.Location = new System.Drawing.Point(6, 230);
            this.utilityComboBox.Name = "utilityComboBox";
            this.utilityComboBox.Size = new System.Drawing.Size(170, 150);
            this.utilityComboBox.TabIndex = 3;
            // 
            // armorComboBox
            // 
            this.armorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.armorComboBox.FormattingEnabled = true;
            this.armorComboBox.Location = new System.Drawing.Point(358, 28);
            this.armorComboBox.Name = "armorComboBox";
            this.armorComboBox.Size = new System.Drawing.Size(170, 150);
            this.armorComboBox.TabIndex = 2;
            // 
            // shieldsComboBox
            // 
            this.shieldsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.shieldsComboBox.FormattingEnabled = true;
            this.shieldsComboBox.Location = new System.Drawing.Point(182, 28);
            this.shieldsComboBox.Name = "shieldsComboBox";
            this.shieldsComboBox.Size = new System.Drawing.Size(170, 150);
            this.shieldsComboBox.TabIndex = 1;
            // 
            // weaponComboBox
            // 
            this.weaponComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.weaponComboBox.FormattingEnabled = true;
            this.weaponComboBox.Location = new System.Drawing.Point(6, 28);
            this.weaponComboBox.Name = "weaponComboBox";
            this.weaponComboBox.Size = new System.Drawing.Size(170, 150);
            this.weaponComboBox.TabIndex = 0;
            // 
            // sanctuaryTab
            // 
            this.sanctuaryTab.BackColor = System.Drawing.Color.White;
            this.sanctuaryTab.Controls.Add(this.merchant4ComboBox);
            this.sanctuaryTab.Controls.Add(this.merchant3ComboBox);
            this.sanctuaryTab.Controls.Add(this.merchant2ComboBox);
            this.sanctuaryTab.Controls.Add(this.merchant1ComboBox);
            this.sanctuaryTab.Controls.Add(this.label29);
            this.sanctuaryTab.Controls.Add(this.label28);
            this.sanctuaryTab.Controls.Add(this.sanctuaryCreedComboBox);
            this.sanctuaryTab.Controls.Add(this.sanctuaryCreedListComboBox);
            this.sanctuaryTab.Location = new System.Drawing.Point(4, 22);
            this.sanctuaryTab.Name = "sanctuaryTab";
            this.sanctuaryTab.Padding = new System.Windows.Forms.Padding(3);
            this.sanctuaryTab.Size = new System.Drawing.Size(715, 412);
            this.sanctuaryTab.TabIndex = 2;
            this.sanctuaryTab.Text = "Sanctuaries";
            // 
            // merchant4ComboBox
            // 
            this.merchant4ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.merchant4ComboBox.FormattingEnabled = true;
            this.merchant4ComboBox.Location = new System.Drawing.Point(599, 200);
            this.merchant4ComboBox.Name = "merchant4ComboBox";
            this.merchant4ComboBox.Size = new System.Drawing.Size(110, 150);
            this.merchant4ComboBox.TabIndex = 7;
            this.merchant4ComboBox.SelectedIndexChanged += new System.EventHandler(this.merchant4ComboBox_SelectedIndexChanged);
            // 
            // merchant3ComboBox
            // 
            this.merchant3ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.merchant3ComboBox.FormattingEnabled = true;
            this.merchant3ComboBox.Location = new System.Drawing.Point(483, 200);
            this.merchant3ComboBox.Name = "merchant3ComboBox";
            this.merchant3ComboBox.Size = new System.Drawing.Size(110, 150);
            this.merchant3ComboBox.TabIndex = 6;
            this.merchant3ComboBox.SelectedIndexChanged += new System.EventHandler(this.merchant3ComboBox_SelectedIndexChanged);
            // 
            // merchant2ComboBox
            // 
            this.merchant2ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.merchant2ComboBox.FormattingEnabled = true;
            this.merchant2ComboBox.Location = new System.Drawing.Point(367, 200);
            this.merchant2ComboBox.Name = "merchant2ComboBox";
            this.merchant2ComboBox.Size = new System.Drawing.Size(110, 150);
            this.merchant2ComboBox.TabIndex = 5;
            this.merchant2ComboBox.SelectedIndexChanged += new System.EventHandler(this.merchant2ComboBox_SelectedIndexChanged);
            // 
            // merchant1ComboBox
            // 
            this.merchant1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.merchant1ComboBox.FormattingEnabled = true;
            this.merchant1ComboBox.Location = new System.Drawing.Point(251, 201);
            this.merchant1ComboBox.Name = "merchant1ComboBox";
            this.merchant1ComboBox.Size = new System.Drawing.Size(110, 150);
            this.merchant1ComboBox.TabIndex = 4;
            this.merchant1ComboBox.SelectedIndexChanged += new System.EventHandler(this.merchant1ComboBox_SelectedIndexChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(252, 173);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 13);
            this.label29.TabIndex = 3;
            this.label29.Text = "NPCs";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(252, 11);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 13);
            this.label28.TabIndex = 2;
            this.label28.Text = "Creed";
            // 
            // sanctuaryCreedComboBox
            // 
            this.sanctuaryCreedComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.sanctuaryCreedComboBox.FormattingEnabled = true;
            this.sanctuaryCreedComboBox.Location = new System.Drawing.Point(251, 30);
            this.sanctuaryCreedComboBox.Name = "sanctuaryCreedComboBox";
            this.sanctuaryCreedComboBox.Size = new System.Drawing.Size(121, 137);
            this.sanctuaryCreedComboBox.TabIndex = 1;
            this.sanctuaryCreedComboBox.SelectedIndexChanged += new System.EventHandler(this.sanctuaryCreedComboBox_SelectedIndexChanged);
            // 
            // sanctuaryCreedListComboBox
            // 
            this.sanctuaryCreedListComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.sanctuaryCreedListComboBox.FormattingEnabled = true;
            this.sanctuaryCreedListComboBox.Location = new System.Drawing.Point(4, 10);
            this.sanctuaryCreedListComboBox.Name = "sanctuaryCreedListComboBox";
            this.sanctuaryCreedListComboBox.Size = new System.Drawing.Size(241, 397);
            this.sanctuaryCreedListComboBox.TabIndex = 0;
            this.sanctuaryCreedListComboBox.SelectedIndexChanged += new System.EventHandler(this.sanctuaryCreedListComboBox_SelectedIndexChanged);
            // 
            // flagsTab
            // 
            this.flagsTab.BackColor = System.Drawing.Color.White;
            this.flagsTab.Controls.Add(this.label31);
            this.flagsTab.Controls.Add(this.addflagManuallyButton);
            this.flagsTab.Controls.Add(this.label30);
            this.flagsTab.Controls.Add(this.flagTextBox);
            this.flagsTab.Controls.Add(this.addFlagButton);
            this.flagsTab.Controls.Add(this.removeFlagButton);
            this.flagsTab.Controls.Add(this.playerflagsComboBox);
            this.flagsTab.Location = new System.Drawing.Point(4, 22);
            this.flagsTab.Name = "flagsTab";
            this.flagsTab.Padding = new System.Windows.Forms.Padding(3);
            this.flagsTab.Size = new System.Drawing.Size(715, 412);
            this.flagsTab.TabIndex = 3;
            this.flagsTab.Text = "Flags";
            // 
            // playerflagsComboBox
            // 
            this.playerflagsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.playerflagsComboBox.FormattingEnabled = true;
            this.playerflagsComboBox.Location = new System.Drawing.Point(7, 11);
            this.playerflagsComboBox.Name = "playerflagsComboBox";
            this.playerflagsComboBox.Size = new System.Drawing.Size(223, 397);
            this.playerflagsComboBox.TabIndex = 0;
            // 
            // removeFlagButton
            // 
            this.removeFlagButton.Location = new System.Drawing.Point(237, 11);
            this.removeFlagButton.Name = "removeFlagButton";
            this.removeFlagButton.Size = new System.Drawing.Size(123, 23);
            this.removeFlagButton.TabIndex = 1;
            this.removeFlagButton.Text = "Remove selected";
            this.removeFlagButton.UseVisualStyleBackColor = true;
            this.removeFlagButton.Click += new System.EventHandler(this.removeFlagButton_Click);
            // 
            // addFlagButton
            // 
            this.addFlagButton.Location = new System.Drawing.Point(237, 41);
            this.addFlagButton.Name = "addFlagButton";
            this.addFlagButton.Size = new System.Drawing.Size(123, 23);
            this.addFlagButton.TabIndex = 2;
            this.addFlagButton.Text = "Add new flag from list";
            this.addFlagButton.UseVisualStyleBackColor = true;
            this.addFlagButton.Click += new System.EventHandler(this.addFlagButton_Click);
            // 
            // flagTextBox
            // 
            this.flagTextBox.Location = new System.Drawing.Point(240, 120);
            this.flagTextBox.Name = "flagTextBox";
            this.flagTextBox.Size = new System.Drawing.Size(120, 20);
            this.flagTextBox.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(237, 100);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(90, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Add flag manually";
            // 
            // addflagManuallyButton
            // 
            this.addflagManuallyButton.Location = new System.Drawing.Point(240, 146);
            this.addflagManuallyButton.Name = "addflagManuallyButton";
            this.addflagManuallyButton.Size = new System.Drawing.Size(120, 23);
            this.addflagManuallyButton.TabIndex = 5;
            this.addflagManuallyButton.Text = "Add flag manually";
            this.addflagManuallyButton.UseVisualStyleBackColor = true;
            this.addflagManuallyButton.Click += new System.EventHandler(this.addflagManuallyButton_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(539, 388);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(170, 20);
            this.label31.TabIndex = 6;
            this.label31.Text = "DON\'T FUCK SHIT UP";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 477);
            this.Controls.Add(this.tabs);
            this.Controls.Add(this.lastSanctuaryComboBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.keeperLevel);
            this.Controls.Add(this.splendorLevel);
            this.Controls.Add(this.darkLevel);
            this.Controls.Add(this.stoneLevel);
            this.Controls.Add(this.threeLevel);
            this.Controls.Add(this.devaraLevel);
            this.Controls.Add(this.ironLevel);
            this.Controls.Add(this.keeperStanding);
            this.Controls.Add(this.splendorStanding);
            this.Controls.Add(this.darkStanding);
            this.Controls.Add(this.stoneStanding);
            this.Controls.Add(this.threeStanding);
            this.Controls.Add(this.devaraStanding);
            this.Controls.Add(this.ironStanding);
            this.Controls.Add(this.creedBox);
            this.Controls.Add(this.hardcoreCheck);
            this.Controls.Add(this.goldBox);
            this.Controls.Add(this.saltBox);
            this.Controls.Add(this.expungedBox);
            this.Controls.Add(this.playthroughBox);
            this.Controls.Add(this.corruptionBox);
            this.Controls.Add(this.restCountBox);
            this.Controls.Add(this.deathsBox);
            this.Controls.Add(this.killsBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Pepper and Church Savegame Editor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabs.ResumeLayout(false);
            this.inventoryTab.ResumeLayout(false);
            this.inventoryTab.PerformLayout();
            this.sanctuaryTab.ResumeLayout(false);
            this.sanctuaryTab.PerformLayout();
            this.flagsTab.ResumeLayout(false);
            this.flagsTab.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goodbyeMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox killsBox;
        private System.Windows.Forms.TextBox deathsBox;
        private System.Windows.Forms.TextBox restCountBox;
        private System.Windows.Forms.TextBox corruptionBox;
        private System.Windows.Forms.TextBox playthroughBox;
        private System.Windows.Forms.TextBox expungedBox;
        private System.Windows.Forms.TextBox saltBox;
        private System.Windows.Forms.TextBox goldBox;
        private System.Windows.Forms.CheckBox hardcoreCheck;
        private System.Windows.Forms.ComboBox creedBox;
        private System.Windows.Forms.ComboBox ironStanding;
        private System.Windows.Forms.ComboBox devaraStanding;
        private System.Windows.Forms.ComboBox threeStanding;
        private System.Windows.Forms.ComboBox stoneStanding;
        private System.Windows.Forms.ComboBox darkStanding;
        private System.Windows.Forms.ComboBox splendorStanding;
        private System.Windows.Forms.ComboBox keeperStanding;
        private System.Windows.Forms.ComboBox keeperLevel;
        private System.Windows.Forms.ComboBox splendorLevel;
        private System.Windows.Forms.ComboBox darkLevel;
        private System.Windows.Forms.ComboBox stoneLevel;
        private System.Windows.Forms.ComboBox threeLevel;
        private System.Windows.Forms.ComboBox devaraLevel;
        private System.Windows.Forms.ComboBox ironLevel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox lastSanctuaryComboBox;
        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage inventoryTab;
        private System.Windows.Forms.ComboBox weaponComboBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox materialsComboBox;
        private System.Windows.Forms.ComboBox ringsComboBox;
        private System.Windows.Forms.ComboBox keysComboBox;
        private System.Windows.Forms.ComboBox spellsComboBox;
        private System.Windows.Forms.ComboBox utilityComboBox;
        private System.Windows.Forms.ComboBox armorComboBox;
        private System.Windows.Forms.ComboBox shieldsComboBox;
        private System.Windows.Forms.Button materialsAdd;
        private System.Windows.Forms.Button keysAdd;
        private System.Windows.Forms.Button spellsAdd;
        private System.Windows.Forms.Button utilityAdd;
        private System.Windows.Forms.Button ringsAdd;
        private System.Windows.Forms.Button armorAdd;
        private System.Windows.Forms.Button shieldAdd;
        private System.Windows.Forms.Button weaponAdd;
        private System.Windows.Forms.Button materialsEdit;
        private System.Windows.Forms.Button keysEdit;
        private System.Windows.Forms.Button spellsEdit;
        private System.Windows.Forms.Button utilityEdit;
        private System.Windows.Forms.Button ringsEdit;
        private System.Windows.Forms.Button armorEdit;
        private System.Windows.Forms.Button shieldEdit;
        private System.Windows.Forms.Button weaponEdit;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.TabPage sanctuaryTab;
        private System.Windows.Forms.ComboBox sanctuaryCreedComboBox;
        private System.Windows.Forms.ComboBox sanctuaryCreedListComboBox;
        private System.Windows.Forms.ComboBox merchant4ComboBox;
        private System.Windows.Forms.ComboBox merchant3ComboBox;
        private System.Windows.Forms.ComboBox merchant2ComboBox;
        private System.Windows.Forms.ComboBox merchant1ComboBox;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabPage flagsTab;
        private System.Windows.Forms.ComboBox playerflagsComboBox;
        private System.Windows.Forms.Button removeFlagButton;
        private System.Windows.Forms.Button addFlagButton;
        private System.Windows.Forms.Button addflagManuallyButton;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox flagTextBox;
        private System.Windows.Forms.Label label31;
    }
}

