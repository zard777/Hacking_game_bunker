﻿using System.Text;

namespace SaltSaveEditor
{
    // Token: 0x02000068 RID: 104
    public class LocStrings
    {
        // Token: 0x060002C0 RID: 704 RVA: 0x0005E411 File Offset: 0x0005C611
        public static string GetLocStr(int i)
        {
            return Game1.dialog.GetLocStr(i);
        }

        // Token: 0x060002C1 RID: 705 RVA: 0x0005E41E File Offset: 0x0005C61E
        public static StringBuilder GetLocString(int i)
        {
            return Game1.dialog.GetLocString(i);
        }

    }
}
