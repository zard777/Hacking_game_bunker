﻿using System;
using System.Collections.Generic;

namespace SaltSaveEditor
{
	// Token: 0x020001D0 RID: 464
	public class PlayerChallenges
	{
		// Token: 0x060008FB RID: 2299 RVA: 0x000D6DD0 File Offset: 0x000D4FD0
		public PlayerChallenges(Player p)
		{
			this.p = p;
			this.category = new ChallengeCategory[5];
			this.category[0] = new ChallengeCatHardcoreMode(p);
			this.category[1] = new ChallengeCatLoadout(p);
			this.category[2] = new ChallengeCatArmor(p);
			this.category[3] = new ChallengeCatShield(p);
			this.category[4] = new ChallengeCatHealing(p);
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x000D6E3C File Offset: 0x000D503C
		public void WriteFlags()
		{
			int i;
			ChallengeCategory challengeCategory;
			string item;
			i = 0;
			while (i < this.category.Length)
			{
				challengeCategory = this.category[i];
				if (!(challengeCategory.activeChallenge <= -1))
				{
					item = string.Concat("ch@n_", i.ToString(), "_", challengeCategory.activeChallenge.ToString());
					if (!this.p.flags.Contains(item))
					{
						this.p.flags.Add(item);
					}
				}
				i = i + 1;
			}
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x000D6EB4 File Offset: 0x000D50B4
		public void ReadFlags()
		{
			ChallengeCategory[] array;
			int i;
			ChallengeCategory challengeCategory;
			List<string>.Enumerator enumerator;
			string current;
			string[] array2;
			int num;
			int activeChallenge;
			array = this.category;
			i = 0;
			while (i < array.Length)
			{
				challengeCategory = array[i];
				challengeCategory.activeChallenge = -1;
				i = i + 1;
			}
			enumerator = this.p.flags.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					current = enumerator.Current;
					if (!(!current.StartsWith("ch@n_")))
					{
						array2 = current.Split(new char[]
						{
							'_'
						});
						if (!(array2.Length <= 2))
						{
							try
							{
								num = Convert.ToInt32(array2[1]);
								activeChallenge = Convert.ToInt32(array2[2]);
								this.category[num].activeChallenge = activeChallenge;
							}
							catch
							{
							}
						}
					}
				}
			}
			finally
			{
				((IDisposable)enumerator).Dispose();
			}
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x000D6F8C File Offset: 0x000D518C
		internal bool CanCoop()
		{
			int i;
			i = 0;
			while (i < this.category.Length)
			{
				if (!(this.category[i].activeChallenge <= -1))
				{
					return false;
				}
				i = i + 1;
			}
			return true;
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x000D6FC0 File Offset: 0x000D51C0
		internal void Reset()
		{
			ChallengeCategory[] array;
			int i;
			ChallengeCategory challengeCategory;
			array = this.category;
			i = 0;
			while (i < array.Length)
			{
				challengeCategory = array[i];
				challengeCategory.activeChallenge = -1;
				i = i + 1;
			}
		}

		// Token: 0x040014F2 RID: 5362
		public const int CATEGORY_HARDCORE = 0;

		// Token: 0x040014F3 RID: 5363
		public const int CATEGORY_LOADOUT = 1;

		// Token: 0x040014F4 RID: 5364
		public const int CATEGORY_ARMOR = 2;

		// Token: 0x040014F5 RID: 5365
		public const int CATEGORY_SHIELDS = 3;

		// Token: 0x040014F6 RID: 5366
		public const int CATEGORY_HEALING = 4;

		// Token: 0x040014F7 RID: 5367
		public const int TOTAL_CATEGORIES = 5;

		// Token: 0x040014F8 RID: 5368
		private const string CHALLENGE_STR = "ch@n_";

		// Token: 0x040014F9 RID: 5369
		public ChallengeCategory[] category;

		// Token: 0x040014FA RID: 5370
		private Player p;
	}
}
