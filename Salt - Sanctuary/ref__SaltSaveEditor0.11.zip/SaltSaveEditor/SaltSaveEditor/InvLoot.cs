﻿using System.IO;
using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200020B RID: 523
	public class InvLoot
	{
		// Token: 0x06000A54 RID: 2644 RVA: 0x000FE613 File Offset: 0x000FC813
		public InvLoot()
		{
		}

		// Token: 0x06000A57 RID: 2647 RVA: 0x000FE8B5 File Offset: 0x000FCAB5
		public InvLoot(BinaryReader reader)
		{
			this.Read(reader);
            this.baseName = Game1.lootCatalog.category[this.category].loot[this.catalogIdx].title[Game1.language];

        }

        // Token: 0x06000A58 RID: 2648 RVA: 0x000FE8CA File Offset: 0x000FCACA
        public InvLoot(InvLoot loot)
		{
			this.CopyFrom(loot);
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x000FE8E0 File Offset: 0x000FCAE0
		public void InitFromName(string name)
		{
			LootDef lootDef;
			this.SetIndex(name);
            this.baseName = Game1.lootCatalog.category[this.category].loot[this.catalogIdx].title[Game1.language];
            if (!(this.catalogIdx <= -1))
			{
				this.upgrade = 0;
				lootDef = Game1.lootCatalog.category[this.category].loot[this.catalogIdx];
				this.durability = lootDef.durability;
				this.count = 1;
			}
		}

		// Token: 0x06000A5A RID: 2650 RVA: 0x000FE938 File Offset: 0x000FCB38
		public void CopyFrom(InvLoot other)
		{
			this.SetIndex(other.name);
			this.durability = other.durability;
			this.count = other.count;
			this.sanctuaryConsumableCreed = other.sanctuaryConsumableCreed;
			this.upgrade = other.upgrade;
			this.elemental = other.elemental;
			this.equipped = other.equipped;
            this.baseName = Game1.lootCatalog.category[this.category].loot[this.catalogIdx].title[Game1.language];

        }

        // Token: 0x06000A5B RID: 2651 RVA: 0x000FE99C File Offset: 0x000FCB9C
        public void SetIndex(string name)
		{
			int i;
			int j;
			this.name = name;
			this.catalogIdx = -1;
			i = 0;
			while (i < Game1.lootCatalog.category.Length)
			{
				j = 0;
				while (j < Game1.lootCatalog.category[i].loot.Length)
				{
					if (Game1.lootCatalog.category[i].loot[j].name==name)
					{
						this.category = i;
						this.catalogIdx = j;
						return;
					}
					j = j + 1;
				}
				i = i + 1;
			}
		}

		// Token: 0x06000A5C RID: 2652 RVA: 0x000FEA2C File Offset: 0x000FCC2C
		public void Write(BinaryWriter writer)
		{
			writer.Write(this.name);
			writer.Write(this.durability);
			writer.Write(this.count);
			writer.Write(this.category);
			writer.Write(this.upgrade);
			writer.Write(this.elemental);
			writer.Write(this.sanctuaryConsumableCreed);
		}

		// Token: 0x06000A5D RID: 2653 RVA: 0x000FEA90 File Offset: 0x000FCC90
		public void Read(BinaryReader reader)
		{
			this.name = reader.ReadString();
			this.SetIndex(this.name);
			this.durability = reader.ReadSingle();
			this.count = reader.ReadInt32();
			this.category = reader.ReadInt32();
			this.upgrade = reader.ReadInt32();
			this.elemental = reader.ReadInt32();
			this.sanctuaryConsumableCreed = reader.ReadInt32();

		}
		// Token: 0x04001828 RID: 6184
		public int category;

		// Token: 0x04001829 RID: 6185
		public string name;

		// Token: 0x0400182A RID: 6186
		public StringBuilder title;

        public string baseName { get; set; }

		// Token: 0x0400182B RID: 6187
		public int catalogIdx;

		// Token: 0x0400182C RID: 6188
		public int count;

		// Token: 0x0400182D RID: 6189
		public float durability;

		// Token: 0x0400182E RID: 6190
		public int upgrade;

		// Token: 0x0400182F RID: 6191
		public int elemental;

		// Token: 0x04001830 RID: 6192
		public bool equipped;

		// Token: 0x04001831 RID: 6193
		public int sanctuaryConsumableCreed;
	}
}
