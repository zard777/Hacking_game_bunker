﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x020001DC RID: 476
	public class Layer
	{
		// Token: 0x06000961 RID: 2401 RVA: 0x000E780A File Offset: 0x000E5A0A
		public Layer()
		{
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x000E7814 File Offset: 0x000E5A14
		public void Read(BinaryReader reader)
		{
			int num;
			int i;
			num = reader.ReadInt32();
			this.seg = new Seg[num];
			i = 0;
			while (i < num)
			{
				this.seg[i] = new Seg();
				this.seg[i].Read(reader);
				i = i + 1;
			}
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x000E785C File Offset: 0x000E5A5C
		public void RefreshDepths()
		{
			float num;
			int i;
			num = this.depth;
			i = 0;
			while (i < this.seg.Length)
			{
				this.seg[i].depth = num;
				i = i + 1;
			}
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x000E7894 File Offset: 0x000E5A94
		public void ReadEntities(BinaryReader reader)
		{
			int num;
			int i;
			num = reader.ReadInt32();
			this.seg = new Seg[num];
			i = 0;
			while (i < num)
			{
				this.seg[i] = new Seg();
				this.seg[i].ReadEntity(reader);
				i = i + 1;
			}
		}

		// Token: 0x040015B7 RID: 5559
		public Seg[] seg;

		// Token: 0x040015B8 RID: 5560
		public float depth;
	}
}
