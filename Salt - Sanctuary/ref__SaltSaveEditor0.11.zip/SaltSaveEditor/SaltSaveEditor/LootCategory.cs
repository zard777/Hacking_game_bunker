﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x02000014 RID: 20
	public class LootCategory
	{
		// Token: 0x06000056 RID: 86 RVA: 0x00003D65 File Offset: 0x00001F65
		public LootCategory()
		{
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00003D70 File Offset: 0x00001F70
		internal void Read(BinaryReader reader)
		{
			int num;
			int i;
			num = reader.ReadInt32();
			this.loot = new LootDef[num];
			i = 0;
			while (i < num)
			{
				this.loot[i] = new LootDef();
				this.loot[i].Read(reader);
				i = i + 1;
			}
		}

		// Token: 0x040000AB RID: 171
		public LootDef[] loot;
	}
}
