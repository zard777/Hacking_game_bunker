﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x0200000F RID: 15
	public class NPCDialog
	{
		// Token: 0x06000045 RID: 69 RVA: 0x0000367E File Offset: 0x0000187E
		public NPCDialog()
		{
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00003688 File Offset: 0x00001888
		internal void Read(BinaryReader reader)
		{
			int num;
			InvLoot invLoot;
			int i;
			string[] giveScript;
			int j;
			string text;
			this.name = reader.ReadString();
			this.rune = -1;
			num = reader.ReadInt32();
			invLoot = new InvLoot();
			this.nodeList = new DialogNode[num];
			i = 0;
			while (i < num)
			{
				this.nodeList[i] = new DialogNode();
				this.nodeList[i].Read(reader);
				if (!(!(this.nodeList[i].giveScript != null)))
				{
					giveScript = this.nodeList[i].giveScript;
					j = 0;
					while (j < giveScript.Length)
					{
						text = giveScript[j];
						invLoot.InitFromName(text);
						if (!(!(invLoot != null) || invLoot.category != 3 || Game1.lootCatalog.category[invLoot.category].loot[invLoot.catalogIdx].type != 2))
						{
							this.rune = Game1.lootCatalog.category[invLoot.category].loot[invLoot.catalogIdx].flags;
						}
						j = j + 1;
					}
				}
				i = i + 1;
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00003788 File Offset: 0x00001988
		internal int GetNodeIdx(string p)
		{
			int i;
			i = 0;
			while (i < this.nodeList.Length)
			{
				if (this.nodeList[i].name==p)
				{
					return i;
				}
				i = i + 1;
			}
			return -1;
		}

		// Token: 0x04000030 RID: 48
		public string name;

		// Token: 0x04000031 RID: 49
		public DialogNode[] nodeList;

		// Token: 0x04000032 RID: 50
		public int rune;
	}
}
