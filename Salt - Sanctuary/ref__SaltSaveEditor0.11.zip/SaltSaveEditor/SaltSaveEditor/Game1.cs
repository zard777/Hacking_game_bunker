﻿namespace SaltSaveEditor
{
	// Token: 0x0200021B RID: 539
	public class Game1
	{
		// Token: 0x06000B31 RID: 2865 RVA: 0x001104D3 File Offset: 0x0010E6D3
		public static void init()
		{
            Game1.lootCatalog = new LootCatalog();
            Game1.lootCatalog.ReadMaster();
            Game1.monsterCatalog = new MonsterCatalog();
            Game1.monsterCatalog.ReadMaster();
            Game1.dialog = new DialogMgr();
            Game1.dialog.ReadLocText();
            Game1.dialog.ReadMaster();
            Game1.language = 0;
            SkillTree.Init();
            Textures.Init();
            Map.Read();
            SanctuaryMgr.Init();
            c = new Character();
            p = new Player();
        }

        public static int getSanctIdFromName(string name)
        {
            switch (name)
            {
                case "Ashen Shore": return SANCTUARY_ASHEN_SHORE;
                case "Village of Smiles": return SANCTUARY_FORSAKEN_VILLAGE;
                case "Bandit's Pass": return SANCTUARY_BANDITS_PASS;
                case "Castle of Storms": return SANCTUARY_CASTLE_OF_STORMS;
                case "Sunken Keep": return SANCTUARY_SUNKEN_KEEP;
                case "Red Hall of Cages": return SANCTUARY_RED_DUNGEON;
                case "The Watching Woods": return SANCTUARY_LOST_WOODS;
                case "Hager's Cavern": return SANCTUARY_CAVES;
                case "Mire of Stench": return SANCTUARY_SWAMP;
                case "Dome of the Forgotten": return SANCTUARY_DOME;
                case "Mal's Floating Castle": return SANCTUARY_SKY_CASTLE;
                case "Cran's Pass": return SANCTUARY_DUNGEON_CAVE;
                case "The Far Beach": return SANCTUARY_FAR_BEACH;
                case "Fort-Beyond-The-Mire": return SANCTUARY_COASTAL_FORT;
                case "Siam Lake": return SANCTUARY_SIAM_LAKE;
                case "Pitchwoods": return SANCTUARY_DARKWOOD;
                case "Ziggurat of Dust": return SANCTUARY_ZIGGURAT;
                case "The Ruined Temple": return SANCTUARY_RUINS;
                case "Salt Alkymancy": return SANCTUARY_LAB;
                case "Crypt of Dead Gods": return SANCTUARY_TOMB;
                case "Blackest Vault": return SANCTUARY_BLACKEST_VAULT;
                case "The Festering Banquet Shrine": return SHRINE_PARTY_FORT;
                case "Sunken Keep Shrine": return SHRINE_SUNKEN_KEEP;
                case "Red Hall of Cages Shrine": return SHRINE_RED_DUNGEON;
                case "Dome of the Forgotten Shrine": return SHRINE_DOME;
                case "Mire of Stench Shrine": return SHRINE_SWAMP;
                case "Castle of Storms Shrine": return SHRINE_CASTLE_OF_STORMS;
                case "Hager's Cavern Shrine": return SHRINE_CAVES;
                case "Crypt of the Dead Gods Shrine": return SHRINE_TOMB;
                case "The Still Palace Shrine": return SHRINE_PALACE;
                case "Pitchwoods Shrine": return SHRINE_DARKWOODS;
                case "Shrine between Ziggurat and Ruined Temple": return SHRINE_UNKNOWN;

                default: return -1;
            }
        }

        public static string getSanctNameFromId(int id)
        {
            switch (id)
            {
                case -1: return "None";
                case SANCTUARY_ASHEN_SHORE: return "Ashen Shore";
                case SANCTUARY_FORSAKEN_VILLAGE: return "Village of Smiles";
                case SANCTUARY_BANDITS_PASS: return "Bandit's Pass";
                case SANCTUARY_CASTLE_OF_STORMS: return "Castle of Storms";
                case SANCTUARY_SUNKEN_KEEP: return "Sunken Keep";
                case SANCTUARY_RED_DUNGEON: return "Red Hall of Cages";
                case SANCTUARY_LOST_WOODS: return "The Watching Woods";
                case SANCTUARY_CAVES: return "Hager's Cavern";
                case SANCTUARY_SWAMP: return "Mire of Stench";
                case SANCTUARY_DOME: return "Dome of the Forgotten";
                case SANCTUARY_SKY_CASTLE: return "Mal's Floating Castle";
                case SANCTUARY_DUNGEON_CAVE: return "Cran's Pass";
                case SANCTUARY_FAR_BEACH: return "The Far Beach";
                case SANCTUARY_COASTAL_FORT: return "Fort-Beyond-The-Mire";
                case SANCTUARY_SIAM_LAKE: return "Siam Lake";
                case SANCTUARY_DARKWOOD: return "Pitchwoods";
                case SANCTUARY_ZIGGURAT: return "Ziggurat of Dust";
                case SANCTUARY_RUINS: return "The Ruined Temple";
                case SANCTUARY_LAB: return "Salt Alkymancy";
                case SANCTUARY_TOMB: return "Crypt of Dead Gods";
                case SANCTUARY_BLACKEST_VAULT: return "Blackest Vault";
                case SHRINE_PARTY_FORT: return "The Festering Banquet Shrine";
                case SHRINE_SUNKEN_KEEP: return "Sunken Keep Shrine";
                case SHRINE_RED_DUNGEON: return "Red Hall of Cages Shrine";
                case SHRINE_DOME: return "Dome of the Forgotten Shrine";
                case SHRINE_SWAMP: return "Mire of Stench Shrine";
                case SHRINE_CASTLE_OF_STORMS: return "Castle of Storms Shrine";
                case SHRINE_CAVES: return "Hager's Cavern Shrine";
                case SHRINE_TOMB: return "Crypt of the Dead Gods Shrine";
                case SHRINE_PALACE: return "The Still Palace Shrine";
                case SHRINE_DARKWOODS: return "Pitchwoods Shrine";
                case SHRINE_UNKNOWN: return "Shrine between Ziggurat and Ruined Temple";
                default: return "";
            }

        }

        public static string getCreedFromId(int id)
        {
            switch (id) {
                case Creeds.CREED_CLERIC: return "Devara's Light";
                case Creeds.CREED_DARK: return "Order of the Betrayer";
                case Creeds.CREED_FIRE: return "Keepers of Fire and Sky";
                case Creeds.CREED_IRON: return "The Iron Ones";
                case Creeds.CREED_THREE: return "The Three";
                case Creeds.CREED_WOODS: return "The Stone Roots";
                case Creeds.CREED_SPLENDOR: return "The House of Splendor";
                default: return "None";
            }
        }

        public static int getIdFromCreed(string creed)
        {
            switch (creed)
            {
                case "Devara's Light": return Creeds.CREED_CLERIC;
                case "Order of the Betrayer": return Creeds.CREED_DARK;
                case "Keepers of Fire and Sky": return Creeds.CREED_FIRE;
                case "The Iron Ones": return Creeds.CREED_IRON;
                case "The Three": return Creeds.CREED_THREE;
                case "The Stone Roots": return Creeds.CREED_WOODS;
                case "The House of Splendor": return Creeds.CREED_SPLENDOR;
                default: return Creeds.CREED_NONE;
            }
        }

        public static int getMerchantIdFromName(string name)
        {
            switch (name)
            {
                case "Priest": return Sanctuary.MERCHANT_PRIEST;
                case "Sellsword": return Sanctuary.MERCHANT_SELLSWORD;
                case "Leader": return Sanctuary.MERCHANT_LEADER;
                case "Mage": return Sanctuary.MERCHANT_MAGE;
                case "Alchemist": return Sanctuary.MERCHANT_ALCHEMIST;
                case "Guide": return Sanctuary.MERCHANT_GUIDE;
                case "Blacksmith": return Sanctuary.MERCHANT_BLACKSMITH;
                case "Merchant": return Sanctuary.MERCHANT_MERCHANT;
                case "None": return Sanctuary.MERCHANT_OFF;
                default: return -1;
            }
        }


        public static string getMerchantNameFromId(int id)
        {
            switch (id)
            {
                case Sanctuary.MERCHANT_PRIEST: return "Priest";
                case Sanctuary.MERCHANT_SELLSWORD: return "Sellsword";
                case Sanctuary.MERCHANT_LEADER: return "Leader";
                case Sanctuary.MERCHANT_MAGE: return "Mage";
                case Sanctuary.MERCHANT_ALCHEMIST: return "Alchemist";
                case Sanctuary.MERCHANT_GUIDE: return "Guide";
                case Sanctuary.MERCHANT_BLACKSMITH: return "Blacksmith";
                case Sanctuary.MERCHANT_MERCHANT: return "Merchant";
                default: return "None";
            }
        }

        // Token: 0x04001A61 RID: 6753
        public const int SANCTUARY_ASHEN_SHORE = 0;

        // Token: 0x04001A62 RID: 6754
        public const int SANCTUARY_FORSAKEN_VILLAGE = 1;

        // Token: 0x04001A63 RID: 6755
        public const int SANCTUARY_BANDITS_PASS = 2;

        // Token: 0x04001A64 RID: 6756
        public const int SANCTUARY_CASTLE_OF_STORMS = 3;

        // Token: 0x04001A65 RID: 6757
        public const int SANCTUARY_SUNKEN_KEEP = 4;

        // Token: 0x04001A66 RID: 6758
        public const int SANCTUARY_RED_DUNGEON = 5;

        // Token: 0x04001A67 RID: 6759
        public const int SANCTUARY_LOST_WOODS = 6;

        // Token: 0x04001A68 RID: 6760
        public const int SANCTUARY_CAVES = 7;

        // Token: 0x04001A69 RID: 6761
        public const int SANCTUARY_SWAMP = 8;

        // Token: 0x04001A6A RID: 6762
        public const int SANCTUARY_DOME = 9;

        // Token: 0x04001A6B RID: 6763
        public const int SANCTUARY_SKY_CASTLE = 10;

        // Token: 0x04001A6C RID: 6764
        public const int SANCTUARY_DUNGEON_CAVE = 11;

        // Token: 0x04001A6D RID: 6765
        public const int SANCTUARY_FAR_BEACH = 12;

        // Token: 0x04001A6E RID: 6766
        public const int SANCTUARY_COASTAL_FORT = 13;

        // Token: 0x04001A6F RID: 6767
        public const int SANCTUARY_SIAM_LAKE = 14;

        // Token: 0x04001A70 RID: 6768
        public const int SANCTUARY_DARKWOOD = 15;

        // Token: 0x04001A71 RID: 6769
        public const int SANCTUARY_ZIGGURAT = 16;

        // Token: 0x04001A72 RID: 6770
        public const int SANCTUARY_RUINS = 17;

        // Token: 0x04001A73 RID: 6771
        public const int SHRINE_PARTY_FORT = 18;

        // Token: 0x04001A74 RID: 6772
        public const int SHRINE_SUNKEN_KEEP = 19;

        // Token: 0x04001A75 RID: 6773
        public const int SHRINE_RED_DUNGEON = 20;

        // Token: 0x04001A76 RID: 6774
        public const int SHRINE_DOME = 21;

        // Token: 0x04001A77 RID: 6775
        public const int SANCTUARY_LAB = 22;

        // Token: 0x04001A78 RID: 6776
        public const int SHRINE_SWAMP = 23;

        // Token: 0x04001A79 RID: 6777
        public const int SHRINE_CASTLE_OF_STORMS = 24;

        // Token: 0x04001A7A RID: 6778
        public const int SHRINE_CAVES = 25;

        // Token: 0x04001A7B RID: 6779
        public const int SANCTUARY_TOMB = 26;

        // Token: 0x04001A7C RID: 6780
        public const int SHRINE_TOMB = 27;

        // Token: 0x04001A7D RID: 6781
        public const int SHRINE_PALACE = 28;

        // Token: 0x04001A7E RID: 6782
        public const int SHRINE_DARKWOODS = 29;

        // Token: 0x04001A7F RID: 6783
        public const int SHRINE_UNKNOWN = 30;

        // Token: 0x04001A80 RID: 6784
        public const int SANCTUARY_BLACKEST_VAULT = 31;

        // Token: 0x04001A0B RID: 6667
        public static LootCatalog lootCatalog;

		// Token: 0x04001A0C RID: 6668
		public static MonsterCatalog monsterCatalog;

		public static DialogMgr dialog;

		public static int language;

        public static Character c;

        public static Player p;

	}
}
