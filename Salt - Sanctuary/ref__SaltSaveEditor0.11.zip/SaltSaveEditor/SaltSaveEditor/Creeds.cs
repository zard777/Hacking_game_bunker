﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaltSaveEditor
{
    class Creeds
    {
        // Token: 0x06000B50 RID: 2896 RVA: 0x001127B0 File Offset: 0x001109B0
        public static void Init()
        {
            Creeds.creedDef = new Creeds.CreedDef[10];
            Creeds.creedDef[1] = new Creeds.CreedDef(1, "_iron", "roll", "mana_crystal", "buff_sanclit", "horn_sanc_will");
            Creeds.creedDef[2] = new Creeds.CreedDef(2, "_cleric", "water", "mana_cloth", "potion_holy", "buff_sancholy");
            Creeds.creedDef[3] = new Creeds.CreedDef(3, "_three", "potion", "mana_mead", "buff_sancfire", "buff_threelit");
            Creeds.creedDef[4] = new Creeds.CreedDef(4, "_woods", "heal_herb", "mana_herb", "buff_sancpoison", "throw_w_dagger/25");
            Creeds.creedDef[8] = new Creeds.CreedDef(8, "_fire", "fire_flask", "blue_sky", "buff_crystal", "buff_sancfocus");
            Creeds.creedDef[5] = new Creeds.CreedDef(5, "_dark", "blood_vial", "black_salt", "buff_sancdark", "blood_pot/3");
            Creeds.creedDef[6] = new Creeds.CreedDef(6, "_splendor", "red_wine", "blue_wine", "gold_wine", "cleansing_cloth/2");
            Creeds.creedDef[7] = new Creeds.CreedDef(7, "_fool", "potion", "mana_mead", "buff_sancfire", "buff_threelit");
            Creeds.creedDef[9] = new Creeds.CreedDef(9, "_bones", "potion", "mana_mead", "buff_sancfire", "buff_threelit");
        }

        // Token: 0x06000B51 RID: 2897 RVA: 0x00112972 File Offset: 0x00110B72
        public Creeds()
        {
            Init();
        }

        // Token: 0x04001A18 RID: 6680
        public const int CREED_NONE = 0;

        // Token: 0x04001A19 RID: 6681
        public const int CREED_IRON = 1;

        // Token: 0x04001A1A RID: 6682
        public const int CREED_CLERIC = 2;

        // Token: 0x04001A1B RID: 6683
        public const int CREED_THREE = 3;

        // Token: 0x04001A1C RID: 6684
        public const int CREED_WOODS = 4;

        // Token: 0x04001A1D RID: 6685
        public const int CREED_DARK = 5;

        // Token: 0x04001A1E RID: 6686
        public const int CREED_SPLENDOR = 6;

        // Token: 0x04001A1F RID: 6687
        public const int CREED_UNUSED_1 = 7;

        // Token: 0x04001A20 RID: 6688
        public const int CREED_FIRE = 8;

        // Token: 0x04001A21 RID: 6689
        public const int CREED_UNUSED_2 = 9;

        // Token: 0x04001A22 RID: 6690
        public const int CREED_CANDLE = 10;

        // Token: 0x04001A23 RID: 6691
        public const int TOTAL_CREEDS = 10;

        // Token: 0x04001A24 RID: 6692
        public const int CREED_LEVEL_APOSTATE = -1;

        // Token: 0x04001A25 RID: 6693
        public const int CREED_LEVEL_UNAFFILIATED = 0;

        // Token: 0x04001A26 RID: 6694
        public const int CREED_LEVEL_BUFF = 1;

        // Token: 0x04001A27 RID: 6695
        public const int TOTAL_UNLOCKS = 4;

        // Token: 0x04001A28 RID: 6696
        public static Creeds.CreedDef[] creedDef;

        // Token: 0x0200021F RID: 543
        public struct CreedDef
        {
            // Token: 0x06000B52 RID: 2898 RVA: 0x0011297C File Offset: 0x00110B7C
            public CreedDef(int ID, string altMonsterStr, string consumableHP, string consumableMP, string consumableSlot1, string consumableSlot2)
            {
                this.ID = ID;
                this.altMonsterStr = altMonsterStr;
                this.consumable = new string[]
                {
                    consumableHP,
                    consumableMP,
                    consumableSlot1,
                    consumableSlot2
                };
            }

            // Token: 0x04001A29 RID: 6697
            public const int CONSUMABLE_HP = 0;

            // Token: 0x04001A2A RID: 6698
            public const int CONSUMABLE_MP = 1;

            // Token: 0x04001A2B RID: 6699
            public const int CONSUMABLE_SLOT_1 = 2;

            // Token: 0x04001A2C RID: 6700
            public const int CONSUMABLE_SLOT_2 = 3;

            // Token: 0x04001A2D RID: 6701
            public int ID;

            // Token: 0x04001A2E RID: 6702
            public string altMonsterStr;

            // Token: 0x04001A2F RID: 6703
            public string[] consumable;
        }
    }
}
