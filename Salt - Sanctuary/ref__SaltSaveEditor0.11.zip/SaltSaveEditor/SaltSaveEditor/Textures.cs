﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace SaltSaveEditor
{
	// Token: 0x02000237 RID: 567
	public class Textures
	{
		// Token: 0x06000C19 RID: 3097 RVA: 0x0011B462 File Offset: 0x00119662
		public static int GetTextureIdx(string s)
		{
			if (!(!Textures.textures.ContainsKey(s)))
			{
				return Textures.textures[s];
			}
			return 0;
		}

		// Token: 0x06000C1A RID: 3098 RVA: 0x0011B480 File Offset: 0x00119680
		public static void Init()
		{
			int num;
			int i;
			XTexture xTexture;
			int j;
			Textures.textureSemaphore = new object();
            Assembly _assembly = Assembly.GetExecutingAssembly();
            Stream _fileStream = _assembly.GetManifestResourceStream("SaltSaveEditor.texturesheet.data.master.zcm");
            BinaryReader br = new BinaryReader(_fileStream);
            //FileMgr.Open("texturesheet/data/master.zcm");
			num = br.ReadInt32();
			Textures.tex = new XTexture[num + 1];
			Textures.textures = new Dictionary<string, int>();
			i = 0;
			while (i < num)
			{
				xTexture = new XTexture(br);
				Textures.textures.Add(xTexture.name, i);
				Textures.tex[i] = xTexture;
				i = i + 1;
			}
            br.Close();

        }

        // Token: 0x06000C1B RID: 3099 RVA: 0x0011B550 File Offset: 0x00119750
        public Textures()
		{
		}

		// Token: 0x04001B54 RID: 6996
		public static long saveTick;

		// Token: 0x04001B55 RID: 6997
		public static XTexture[] tex;

		// Token: 0x04001B56 RID: 6998
		private static Dictionary<string, int> textures;


		// Token: 0x04001B58 RID: 7000
		public static object textureSemaphore;

		// Token: 0x04001B59 RID: 7001
		public static bool loading;
	}
}
