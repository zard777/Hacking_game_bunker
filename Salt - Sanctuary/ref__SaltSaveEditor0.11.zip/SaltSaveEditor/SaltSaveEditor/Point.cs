﻿using System;

namespace SaltSaveEditor
{
        public struct Point : IEquatable<Point>
        {
            // Token: 0x1700031C RID: 796
            // (get) Token: 0x06000BEA RID: 3050 RVA: 0x0003D234 File Offset: 0x0003C634
            public static Point Zero
            {
                get
                {
                    return Point._zero;
                }
            }

            // Token: 0x06000BEB RID: 3051 RVA: 0x0003D248 File Offset: 0x0003C648
            public Point(int x, int y)
            {
                this.X = x;
                this.Y = y;
            }

            // Token: 0x06000BEC RID: 3052 RVA: 0x0003D264 File Offset: 0x0003C664
            public bool Equals(Point other)
            {
                return this.X == other.X && this.Y == other.Y;
            }


            // Token: 0x06000BEE RID: 3054 RVA: 0x0003D2BC File Offset: 0x0003C6BC
            public override int GetHashCode()
            {
                return this.X.GetHashCode() + this.Y.GetHashCode();
            }


            // Token: 0x06000BF0 RID: 3056 RVA: 0x0003D324 File Offset: 0x0003C724
            public static bool operator ==(Point a, Point b)
            {
                return a.Equals(b);
            }

            // Token: 0x06000BF1 RID: 3057 RVA: 0x0003D33C File Offset: 0x0003C73C
            public static bool operator !=(Point a, Point b)
            {
                return a.X != b.X || a.Y != b.Y;
            }

            // Token: 0x06000BF2 RID: 3058 RVA: 0x0003D370 File Offset: 0x0003C770
            static Point()
            {
                // Note: this type is marked as 'beforefieldinit'.
                Point._zero = default(Point);
            }

            // Token: 0x040005E6 RID: 1510
            public int X;

            // Token: 0x040005E7 RID: 1511
            public int Y;

            // Token: 0x040005E8 RID: 1512
            private static Point _zero;
        }
    }
