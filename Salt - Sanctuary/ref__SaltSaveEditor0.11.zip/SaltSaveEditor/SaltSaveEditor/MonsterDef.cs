﻿using System.IO;
using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200001C RID: 28
	public class MonsterDef
	{
		// Token: 0x06000082 RID: 130 RVA: 0x00005630 File Offset: 0x00003830
		public MonsterDef(BinaryReader reader)
		{
			this.stepSnd = "";
			this.jabSnd = "";
			this.fierceSnd = "";
			this.growlSnd = "";
			this.laughSnd = "";
			this.dieSnd = "";
			this.screamSnd = "";
			this.hitSnd = "";
			this.scale = 1f;
			this.attackAnim = "attack";
			this.strongAnim = "strong";
			this.specialAnim = "special";
			this.idleAnim = "idle";
			this.runStartAnim = "runstart";
			this.runEndAnim = "runend";
			this.runAnim = "run";
			this.blockAnim = "block";
			this.blockInAnim = "blockin";
			this.blockOutAnim = "blockout";
			this.blockAdvAnim = "blockadv";
			this.blockRetAnim = "blockret";
			this.blockAbsAnim = "blockabs";
			this.runSpeed = 300f;
			this.Read(reader);
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00005DD8 File Offset: 0x00003FD8
		public void Write(BinaryWriter writer)
		{
			int i;
			int j;
			int k;
			writer.Write(this.name);
			i = 0;
			while (i < this.title.Length)
			{
				writer.Write(this.title[i]);
				i = i + 1;
			}
			j = 0;
			while (j < this.desc.Length)
			{
				writer.Write(this.desc[j]);
				j = j + 1;
			}
			writer.Write(this.boxWidth);
			writer.Write(this.boxHeight);
			writer.Write(this.phaseThresh);
			writer.Write(this.crazeThresh);
			writer.Write(this.def);
			writer.Write(this.texture);
			writer.Write(this.helm);
			writer.Write(this.armor);
			writer.Write(this.gloves);
			writer.Write(this.boots);
			writer.Write(this.weapon);
			writer.Write(this.shield);
			writer.Write(this.stepSnd);
			writer.Write(this.jabSnd);
			writer.Write(this.fierceSnd);
			writer.Write(this.hitSnd);
			writer.Write(this.growlSnd);
			writer.Write(this.laughSnd);
			writer.Write(this.dieSnd);
			writer.Write(this.screamSnd);
			writer.Write(this.hair);
			writer.Write(this.hairColor);
			writer.Write(this.beard);
			writer.Write(this.beardColor);
			writer.Write(this.skinIdx);
			writer.Write(this.skinClass);
			writer.Write(this.eyes);
			writer.Write(this.hp);
			writer.Write(this.attack);
			writer.Write(this.defense);
			writer.Write(this.poise);
			writer.Write(this.stamina);
			writer.Write(this.poiseAttack);
			writer.Write(this.blockReduce);
			writer.Write(this.blockDeflect);
			writer.Write(this.blockDmgReduce);
			writer.Write(this.blockMagReduce);
			writer.Write(this.runSpeed);
			writer.Write(this.fireDef);
			writer.Write(this.litDef);
			writer.Write(this.bladedDef);
			writer.Write(this.poisonDef);
			writer.Write(this.holyDef);
			writer.Write(this.darkDef);
			writer.Write(this.salt);
			writer.Write(this.ai);
			writer.Write(this.type);
			writer.Write(this.flags);
			writer.Write(this.giant);
			writer.Write(this.hover);
			writer.Write(this.creature);
			writer.Write(this.slowBack);
			writer.Write(this.bestiary);
			writer.Write(this.fadeLayer);
			writer.Write(this.attackAnim);
			writer.Write(this.strongAnim);
			writer.Write(this.specialAnim);
			writer.Write(this.attackReach);
			writer.Write(this.strongReach);
			writer.Write(this.specialReach);
			writer.Write(this.idleAnim);
			writer.Write(this.runAnim);
			writer.Write(this.runStartAnim);
			writer.Write(this.runEndAnim);
			writer.Write(this.blockAnim);
			writer.Write(this.blockInAnim);
			writer.Write(this.blockOutAnim);
			writer.Write(this.blockAdvAnim);
			writer.Write(this.blockRetAnim);
			writer.Write(this.blockAbsAnim);
			k = 0;
			while (k < this.monsterDrop.Length)
			{
				this.monsterDrop[k].Write(writer);
				k = k + 1;
			}
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000061A0 File Offset: 0x000043A0
		public void Read(BinaryReader reader)
		{
			int i;
			int j;
			int k;
			this.name = reader.ReadString();
			this.title = new string[7];
			this.desc = new string[7];
			i = 0;
			while (i < this.title.Length)
			{
				this.title[i] = reader.ReadString();
				i = i + 1;
			}
			j = 0;
			while (j < this.desc.Length)
			{
				this.desc[j] = reader.ReadString();
				j = j + 1;
			}
			this.boxWidth = (float)reader.ReadInt32();
			this.boxHeight = (float)reader.ReadInt32();
			this.phaseThresh = reader.ReadSingle();
			this.crazeThresh = reader.ReadSingle();
			this.def = reader.ReadString();
			this.texture = reader.ReadString();
			this.helm = reader.ReadString();
			this.armor = reader.ReadString();
			this.gloves = reader.ReadString();
			this.boots = reader.ReadString();
			this.weapon = reader.ReadString();
			this.shield = reader.ReadString();
			this.stepSnd = reader.ReadString();
			this.jabSnd = reader.ReadString();
			this.fierceSnd = reader.ReadString();
			this.hitSnd = reader.ReadString();
			this.growlSnd = reader.ReadString();
			this.laughSnd = reader.ReadString();
			this.dieSnd = reader.ReadString();
			this.screamSnd = reader.ReadString();
			this.hair = reader.ReadInt32();
			this.hairColor = reader.ReadInt32();
			this.beard = reader.ReadInt32();
			this.beardColor = reader.ReadInt32();
			this.skinIdx = reader.ReadInt32();
			this.skinClass = reader.ReadInt32();
			this.eyes = reader.ReadInt32();
			this.hp = reader.ReadSingle();
			this.attack = reader.ReadSingle();
			this.defense = reader.ReadSingle();
			this.poise = reader.ReadSingle();
			this.stamina = reader.ReadSingle();
			this.poiseAttack = reader.ReadSingle();
			this.blockReduce = reader.ReadSingle();
			this.blockDeflect = reader.ReadSingle();
			this.blockDmgReduce = reader.ReadSingle();
			this.blockMagReduce = reader.ReadSingle();
			this.runSpeed = reader.ReadSingle();
			this.fireDef = reader.ReadSingle();
			this.litDef = reader.ReadSingle();
			this.bladedDef = reader.ReadSingle();
			this.poisonDef = reader.ReadSingle();
			this.holyDef = reader.ReadSingle();
			this.darkDef = reader.ReadSingle();
			this.salt = reader.ReadInt32();
			this.ai = reader.ReadInt32();
			this.type = reader.ReadInt32();
			this.flags = reader.ReadInt32();
			this.giant = reader.ReadBoolean();
			this.hover = reader.ReadBoolean();
			this.creature = reader.ReadInt32();
			this.slowBack = reader.ReadBoolean();
			this.bestiary = reader.ReadBoolean();
			this.fadeLayer = reader.ReadBoolean();
			this.attackAnim = reader.ReadString();
			this.strongAnim = reader.ReadString();
			this.specialAnim = reader.ReadString();
			this.attackReach = reader.ReadInt32();
			this.strongReach = reader.ReadInt32();
			this.specialReach = reader.ReadInt32();
			this.idleAnim = reader.ReadString();
			this.runAnim = reader.ReadString();
			this.runStartAnim = reader.ReadString();
			this.runEndAnim = reader.ReadString();
			this.blockAnim = reader.ReadString();
			this.blockInAnim = reader.ReadString();
			this.blockOutAnim = reader.ReadString();
			this.blockAdvAnim = reader.ReadString();
			this.blockRetAnim = reader.ReadString();
			this.blockAbsAnim = reader.ReadString();
			this.monsterDrop = new MonsterDef.MonsterDrop[6];
			k = 0;
			while (k < this.monsterDrop.Length)
			{
				this.monsterDrop[k] = new MonsterDef.MonsterDrop(reader);
				k = k + 1;
			}
		}
       
        // Token: 0x0400027C RID: 636
		public string name;

		// Token: 0x0400027D RID: 637
		public string[] title;

		// Token: 0x0400027E RID: 638
		public string[] desc;

		// Token: 0x0400027F RID: 639
		public StringBuilder titleStr;

		// Token: 0x04000280 RID: 640
		public string def;

		// Token: 0x04000281 RID: 641
		public string texture;

		// Token: 0x04000282 RID: 642
		public bool canJump;

		// Token: 0x04000283 RID: 643
		public bool slowBack;

		// Token: 0x04000284 RID: 644
		public bool bestiary;

		// Token: 0x04000285 RID: 645
		public string helm;

		// Token: 0x04000286 RID: 646
		public string armor;

		// Token: 0x04000287 RID: 647
		public string gloves;

		// Token: 0x04000288 RID: 648
		public string boots;

		// Token: 0x04000289 RID: 649
		public string weapon;

		// Token: 0x0400028A RID: 650
		public string shield;

		// Token: 0x0400028B RID: 651
		public int hair;

		// Token: 0x0400028C RID: 652
		public int hairColor;

		// Token: 0x0400028D RID: 653
		public int beard;

		// Token: 0x0400028E RID: 654
		public int beardColor;

		// Token: 0x0400028F RID: 655
		public int skinClass;

		// Token: 0x04000290 RID: 656
		public int skinIdx;

		// Token: 0x04000291 RID: 657
		public int eyes;

		// Token: 0x04000292 RID: 658
		public float hp;

		// Token: 0x04000293 RID: 659
		public float attack;

		// Token: 0x04000294 RID: 660
		public float defense;

		// Token: 0x04000295 RID: 661
		public float poise;

		// Token: 0x04000296 RID: 662
		public float stamina;

		// Token: 0x04000297 RID: 663
		public float poiseAttack;

		// Token: 0x04000298 RID: 664
		public float blockReduce;

		// Token: 0x04000299 RID: 665
		public float blockDeflect;

		// Token: 0x0400029A RID: 666
		public float blockDmgReduce;

		// Token: 0x0400029B RID: 667
		public float blockMagReduce;

		// Token: 0x0400029C RID: 668
		public float fireDef;

		// Token: 0x0400029D RID: 669
		public float litDef;

		// Token: 0x0400029E RID: 670
		public float bladedDef;

		// Token: 0x0400029F RID: 671
		public float poisonDef;

		// Token: 0x040002A0 RID: 672
		public float holyDef;

		// Token: 0x040002A1 RID: 673
		public float darkDef;

		// Token: 0x040002A2 RID: 674
		public float phaseThresh;

		// Token: 0x040002A3 RID: 675
		public float crazeThresh;

		// Token: 0x040002A4 RID: 676
		public bool fadeLayer;

		// Token: 0x040002A5 RID: 677
		public int salt;

		// Token: 0x040002A6 RID: 678
		public int ai;

		// Token: 0x040002A7 RID: 679
		public int type;

		// Token: 0x040002A8 RID: 680
		public int flags;

		// Token: 0x040002A9 RID: 681
		public int creature;

		// Token: 0x040002AA RID: 682
		public int bloodType;

		// Token: 0x040002AB RID: 683
		public float boxWidth;

		// Token: 0x040002AC RID: 684
		public float boxHeight;

		// Token: 0x040002AD RID: 685
		public string stepSnd;

		// Token: 0x040002AE RID: 686
		public string jabSnd;

		// Token: 0x040002AF RID: 687
		public string fierceSnd;

		// Token: 0x040002B0 RID: 688
		public string growlSnd;

		// Token: 0x040002B1 RID: 689
		public string laughSnd;

		// Token: 0x040002B2 RID: 690
		public string dieSnd;

		// Token: 0x040002B3 RID: 691
		public string screamSnd;

		// Token: 0x040002B4 RID: 692
		public string hitSnd;

		// Token: 0x040002B5 RID: 693
		public MonsterDef.MonsterDrop[] monsterDrop;

		// Token: 0x040002B6 RID: 694
		public int defIdx;

		// Token: 0x040002B7 RID: 695
		public float scale;

		// Token: 0x040002B8 RID: 696
		public bool giant;

		// Token: 0x040002B9 RID: 697
		public bool hover;

		// Token: 0x040002BA RID: 698
		public string attackAnim;

		// Token: 0x040002BB RID: 699
		public string strongAnim;

		// Token: 0x040002BC RID: 700
		public string specialAnim;

		// Token: 0x040002BD RID: 701
		public string idleAnim;

		// Token: 0x040002BE RID: 702
		public string runStartAnim;

		// Token: 0x040002BF RID: 703
		public string runEndAnim;

		// Token: 0x040002C0 RID: 704
		public string runAnim;

		// Token: 0x040002C1 RID: 705
		public string blockAnim;

		// Token: 0x040002C2 RID: 706
		public string blockInAnim;

		// Token: 0x040002C3 RID: 707
		public string blockOutAnim;

		// Token: 0x040002C4 RID: 708
		public string blockAdvAnim;

		// Token: 0x040002C5 RID: 709
		public string blockRetAnim;

		// Token: 0x040002C6 RID: 710
		public string blockAbsAnim;

		// Token: 0x040002C7 RID: 711
		public int attackReach;

		// Token: 0x040002C8 RID: 712
		public int strongReach;

		// Token: 0x040002C9 RID: 713
		public int specialReach;

		// Token: 0x040002CA RID: 714
		public float runSpeed;

		// Token: 0x0200001D RID: 29
		public struct MonsterDrop
		{
			// Token: 0x06000090 RID: 144 RVA: 0x000073D5 File Offset: 0x000055D5
			public MonsterDrop(float rate, string loot)
			{
				this.dropRate = rate;
				this.dropLoot = loot;
				this.dropCount = 1;
			}

			// Token: 0x06000091 RID: 145 RVA: 0x000073EC File Offset: 0x000055EC
			public MonsterDrop(BinaryReader reader)
			{
				this.dropRate = reader.ReadSingle();
				this.dropLoot = reader.ReadString();
				this.dropCount = reader.ReadInt32();
			}

			// Token: 0x06000092 RID: 146 RVA: 0x00007412 File Offset: 0x00005612
			public void Write(BinaryWriter writer)
			{
				writer.Write(this.dropRate);
				writer.Write((!(this.dropLoot != null)) ? "" : this.dropLoot);
				writer.Write(this.dropCount);
			}

			// Token: 0x040002CB RID: 715
			public string dropLoot;

			// Token: 0x040002CC RID: 716
			public float dropRate;

			// Token: 0x040002CD RID: 717
			public int dropCount;
		}
	}
}
