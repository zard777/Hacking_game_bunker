﻿using System.Collections.Generic;
using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x020001E7 RID: 487
	public class Seg
	{

	
		// Token: 0x060009A5 RID: 2469 RVA: 0x000F0928 File Offset: 0x000EEB28
		internal void Read(BinaryReader reader)
		{
			XTexture xTexture;
			XSprite originalCell;
			int flags;
			string a;
			this.idx = reader.ReadInt32();
			this.loc = new Vector2(reader.ReadSingle(), reader.ReadSingle());
			this.rotation = reader.ReadSingle();
			this.scaling = new Vector2(reader.ReadSingle(), reader.ReadSingle());
			this.texture = reader.ReadString();
			this.hasVisRect = false;
			this.textureIdx = Textures.GetTextureIdx(this.texture);
			xTexture = Textures.tex[this.textureIdx];
			if (!(xTexture.type != 3))
			{
				this.strFlag = reader.ReadString();
				this.intFlag = reader.ReadInt32();
			}
			if (!(xTexture.type != 2))
			{
				originalCell = xTexture.GetOriginalCell(this.idx);
				flags = originalCell.flags;
				switch (flags)
				{
				case 9:
				case 10:
				case 11:
				case 13:
				case 14:
				case 15:
				{
					break;
				}
				case 12:
				{
					return;
				}
				default:
				{
					if (!(flags == 22))
					{
						switch (flags)
						{
						case 29:
						case 30:
						{
							break;
						}
						default:
						{
							return;
						}
						}
					}
					break;
				}
				}
				a = reader.ReadString();
				if (a=="")
				{
					this.strFlag = null;
				}
				else
				{
					this.strFlag = a;
				}
				this.intFlag = reader.ReadInt32();
				if (!(originalCell.flags != 22))
				{
					this.intFlag = -1;
				}
			}
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x000F0C2C File Offset: 0x000EEE2C
		internal void ReadEntity(BinaryReader reader)
		{
			this.idx = reader.ReadInt32();
			this.loc = new Vector2(reader.ReadSingle(), reader.ReadSingle());
			this.intFlag = reader.ReadInt32();
			this.texture = reader.ReadString();
			this.strFlag = reader.ReadString();
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x000F0C80 File Offset: 0x000EEE80
		public Seg()
		{
		}

		// Token: 0x04001636 RID: 5686
		public Vector2 loc;

		// Token: 0x04001637 RID: 5687
		public int idx;

		// Token: 0x04001638 RID: 5688
		public string texture;

		// Token: 0x04001639 RID: 5689
		public int textureIdx;

		// Token: 0x0400163A RID: 5690
		public float rotation;

		// Token: 0x0400163B RID: 5691
		public Vector2 scaling;

		// Token: 0x0400163C RID: 5692
		public bool hasVisRect;

		// Token: 0x0400163D RID: 5693
		public Vector2 visTL;

		// Token: 0x0400163E RID: 5694
		public Vector2 visBR;

		// Token: 0x0400163F RID: 5695
		public int intFlag;

		// Token: 0x04001640 RID: 5696
		public string strFlag;

		// Token: 0x04001641 RID: 5697
		public float depth;
	}
}
