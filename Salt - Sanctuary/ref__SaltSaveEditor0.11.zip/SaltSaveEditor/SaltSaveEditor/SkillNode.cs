﻿using System.IO;
using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200001F RID: 31
	public class SkillNode
	{
		// Token: 0x06000098 RID: 152 RVA: 0x0000756C File Offset: 0x0000576C
		public SkillNode(int ID)
		{
			int i;
			int j;
			int k;
			int l;
			this.name = "new_node";
			this.title = new string[7];
			this.desc = new string[7];
			this.baseDesc = new string[7];
			i = 0;
			while (i < this.title.Length)
			{
				this.title[i] = "";
				i = i + 1;
			}
			j = 0;
			while (j < this.desc.Length)
			{
				this.desc[j] = "";
				j = j + 1;
			}
			k = 0;
			while (k < this.baseDesc.Length)
			{
				this.baseDesc[k] = "";
				k = k + 1;
			}
			this.title[0] = "New Skill";
			this.desc[0] = "New Description";
			this.baseDesc[0] = "";
			this.cost = 1;
			this.ID = ID;
			this.parent = new int[2];
			l = 0;
			while (l < 2)
			{
				this.parent[l] = -1;
				l = l + 1;
			}
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00007664 File Offset: 0x00005864
		public SkillNode(BinaryReader reader, int ID)
		{
			int i;
			int j;
			int k;
			int l;
			this.name = reader.ReadString();
			this.title = new string[7];
			this.desc = new string[7];
			this.baseDesc = new string[7];
			i = 0;
			while (i < this.title.Length)
			{
				this.title[i] = reader.ReadString();
				i = i + 1;
			}
			this.ID = ID;
			this.titleStr = new StringBuilder(this.title[Game1.language]);
			j = 0;
			while (j < this.desc.Length)
			{
				this.desc[j] = reader.ReadString();
				j = j + 1;
			}
			k = 0;
			while (k < this.baseDesc.Length)
			{
				this.baseDesc[k] = reader.ReadString();
				k = k + 1;
			}
			this.type = reader.ReadInt32();
			this.value = reader.ReadInt32();
			this.cost = reader.ReadInt32();
			this.parent = new int[2];
			l = 0;
			while (l < 2)
			{
				this.parent[l] = reader.ReadInt32();
				l = l + 1;
			}
			this.loc = new Vector2(reader.ReadSingle(), reader.ReadSingle());
			this.img = reader.ReadInt32();
			this.max = this.GetMaxTreeUnlock();
		}

		// Token: 0x0600009A RID: 154 RVA: 0x000077A4 File Offset: 0x000059A4
		internal int GetMaxTreeUnlock()
		{
			if (!(this.cost <= 1))
			{
				return 1;
			}
			switch (this.type)
			{
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
			case 22:
			{
				return 5;
			}
			default:
			{
				return 1;
			}
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x000077EC File Offset: 0x000059EC
		internal void CopyFrom(SkillNode other)
		{
			int i;
			int j;
			int k;
			int l;
			this.name = other.name;
			this.title = new string[other.title.Length];
			this.desc = new string[other.desc.Length];
			this.baseDesc = new string[other.baseDesc.Length];
			i = 0;
			while (i < this.title.Length)
			{
				this.title[i] = other.title[i];
				i = i + 1;
			}
			j = 0;
			while (j < this.desc.Length)
			{
				this.desc[j] = other.desc[j];
				j = j + 1;
			}
			k = 0;
			while (k < this.baseDesc.Length)
			{
				this.baseDesc[k] = other.baseDesc[k];
				k = k + 1;
			}
			this.type = other.type;
			this.value = other.value;
			this.cost = other.cost;
			l = 0;
			while (l < 2)
			{
				this.parent[l] = other.parent[l];
				l = l + 1;
			}
			this.loc = other.loc;
			this.img = other.img;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00007900 File Offset: 0x00005B00
		internal void Write(BinaryWriter writer)
		{
			int i;
			int j;
			int k;
			int l;
			writer.Write(this.name);
			i = 0;
			while (i < this.title.Length)
			{
				writer.Write(this.title[i]);
				i = i + 1;
			}
			j = 0;
			while (j < this.desc.Length)
			{
				writer.Write(this.desc[j]);
				j = j + 1;
			}
			k = 0;
			while (k < this.baseDesc.Length)
			{
				writer.Write(this.baseDesc[k]);
				k = k + 1;
			}
			writer.Write(this.type);
			writer.Write(this.value);
			writer.Write(this.cost);
			l = 0;
			while (l < 2)
			{
				writer.Write(this.parent[l]);
				l = l + 1;
			}
			writer.Write(this.loc.X);
			writer.Write(this.loc.Y);
			writer.Write(this.img);
		}

				// Token: 0x040002D2 RID: 722
		public const int TYPE_SWORD_CLASS = 0;

		// Token: 0x040002D3 RID: 723
		public const int TYPE_AXE_CLASS_DEP = 1;

		// Token: 0x040002D4 RID: 724
		public const int TYPE_MACE_CLASS = 2;

		// Token: 0x040002D5 RID: 725
		public const int TYPE_DAGGER_CLASS = 3;

		// Token: 0x040002D6 RID: 726
		public const int TYPE_SPEAR_CLASS_DEP = 4;

		// Token: 0x040002D7 RID: 727
		public const int TYPE_SHIELD_CLASS = 5;

		// Token: 0x040002D8 RID: 728
		public const int TYPE_GREATSWORD_CLASS_DEP = 6;

		// Token: 0x040002D9 RID: 729
		public const int TYPE_GREATAXE_CLASS_DEP = 7;

		// Token: 0x040002DA RID: 730
		public const int TYPE_GREATHAMMER_CLASS = 8;

		// Token: 0x040002DB RID: 731
		public const int TYPE_WHIP_CLASS = 9;

		// Token: 0x040002DC RID: 732
		public const int TYPE_STAFF_CLASS = 10;

		// Token: 0x040002DD RID: 733
		public const int TYPE_BOW_CLASS = 11;

		// Token: 0x040002DE RID: 734
		public const int TYPE_CROSSBOW_CLASS = 12;

		// Token: 0x040002DF RID: 735
		public const int TYPE_PISTOL_CLASS_DEP = 13;

		// Token: 0x040002E0 RID: 736
		public const int TYPE_POLEAXE_CLASS = 14;

		// Token: 0x040002E1 RID: 737
		public const int TYPE_HALBERD_CLASS_DEP = 15;

		// Token: 0x040002E2 RID: 738
		public const int TYPE_ARMOR_CLASS = 16;

		// Token: 0x040002E3 RID: 739
		public const int TYPE_STR = 17;

		// Token: 0x040002E4 RID: 740
		public const int TYPE_DEX = 18;

		// Token: 0x040002E5 RID: 741
		public const int TYPE_MAG = 19;

		// Token: 0x040002E6 RID: 742
		public const int TYPE_WIS = 20;

		// Token: 0x040002E7 RID: 743
		public const int TYPE_END = 21;

		// Token: 0x040002E8 RID: 744
		public const int TYPE_WILL = 22;

		// Token: 0x040002E9 RID: 745
		public const int TYPE_HEALTH_POT = 23;

		// Token: 0x040002EA RID: 746
		public const int TYPE_MANA_POT = 24;

		// Token: 0x040002EB RID: 747
		public const int TYPE_PRAYER_CLASS = 25;

		// Token: 0x040002EC RID: 748
		public const int TYPE_MAGIC_CLASS = 26;

		// Token: 0x040002ED RID: 749
		public const int TYPE_WAND_CLASS = 27;

		// Token: 0x040002EE RID: 750
		public const int TYPE_LIGHT_ARMOR_CLASS = 28;

		// Token: 0x040002EF RID: 751
		public const int TOTAL_CLASSES = 29;

		// Token: 0x040002F0 RID: 752
		private const int MAX_UPGRADES_PER_STAT_NODE = 5;

		// Token: 0x040002F1 RID: 753
		public const int MAX_PARENTS = 2;

		// Token: 0x040002F2 RID: 754
		public string name;

		// Token: 0x040002F3 RID: 755
		public string[] title;

		// Token: 0x040002F4 RID: 756
		public string[] desc;

		// Token: 0x040002F5 RID: 757
		public string[] baseDesc;

		// Token: 0x040002F6 RID: 758
		public int ID;

		// Token: 0x040002F7 RID: 759
		public StringBuilder titleStr;

		// Token: 0x040002F8 RID: 760
		public StringBuilder[] descStr;

		// Token: 0x040002F9 RID: 761
		public StringBuilder[] baseDescStr;

		// Token: 0x040002FA RID: 762
		public int type;

		// Token: 0x040002FB RID: 763
		public int value;

		// Token: 0x040002FC RID: 764
		public int cost;

		// Token: 0x040002FD RID: 765
		public int[] parent;

		// Token: 0x040002FE RID: 766
		public int img;

		// Token: 0x040002FF RID: 767
		public Vector2 loc;

		// Token: 0x04000300 RID: 768
		public int max;
	}
}
