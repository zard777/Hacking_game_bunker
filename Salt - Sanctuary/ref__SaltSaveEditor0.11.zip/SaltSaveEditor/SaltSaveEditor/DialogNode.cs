﻿using System.Collections.Generic;
using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x0200000D RID: 13
	public class DialogNode
	{
		// Token: 0x0600003E RID: 62 RVA: 0x00003170 File Offset: 0x00001370
		public DialogNode()
		{
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00003178 File Offset: 0x00001378
		public DialogNode(DialogNode dialogNode)
		{
			int i;
			int j;
			int k;
			this.name = dialogNode.name;
			this.text = new TextSeries[dialogNode.text.Length];
			i = 0;
			while (i < this.text.Length)
			{
				this.text[i].text = dialogNode.text[i].text;
				i = i + 1;
			}
			this.option = new NodeOption[5];
			j = 0;
			while (j < 5)
			{
				this.option[j] = new NodeOption(dialogNode.option[j]);
				j = j + 1;
			}
			this.precheckFlagStr = new string[dialogNode.precheckFlagStr.Length];
			this.precheckFlagGoto = new string[dialogNode.precheckFlagGoto.Length];
			k = 0;
			while (k < 4)
			{
				this.precheckFlagStr[k] = dialogNode.precheckFlagStr[k];
				this.precheckFlagGoto[k] = dialogNode.precheckFlagGoto[k];
				k = k + 1;
			}
			this.postSetFlagStr = dialogNode.postSetFlagStr;
			this.postGoto = dialogNode.postGoto;
			this.giveScript = dialogNode.giveScript;
			this.storeScript = dialogNode.storeScript;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00003288 File Offset: 0x00001488
		internal void Read(BinaryReader reader)
		{
			int i;
			string text;
			List<NodeOption> list;
			int j;
			NodeOption nodeOption;
			int k;
			string text2;
			string[] array;
			int l;
			string str;
			string[] array2;
			int m;
			string str2;
			this.name = reader.ReadString();
			this.text = new TextSeries[7];
			i = 0;
			while (i < this.text.Length)
			{
				this.text[i] = new TextSeries();
				text = reader.ReadString();
				if (text ==  "")
				{
					this.text[i].text = null;
				}
				else
				{
					if (!(i != 6))
					{
						if (!(!text.StartsWith(">") || text.Length <= 1))
						{
							text = text.Substring(1);
						}
						this.text[i].text = text.Split(new char[]
						{
							'>'
						});
					}
					else
					{
						this.text[i].text = text.Split(new char[]
						{
							'\n'
						});
					}
				}
				i = i + 1;
			}
			this.precheckFlagStr = new string[4];
			this.precheckFlagGoto = new string[4];
			list = new List<NodeOption>();
			j = 0;
			while (j < 5)
			{
				nodeOption = new NodeOption();
				nodeOption.Read(reader);
				if (nodeOption.text[0]!= "")
				{
					list.Add(nodeOption);
				}
				j = j + 1;
			}
			if (!(list.Count <= 0))
			{
				this.option = list.ToArray();
			}
			else
			{
				this.option = null;
			}
			k = 0;
			while (k < 4)
			{
				this.precheckFlagStr[k] = reader.ReadString();
				this.precheckFlagGoto[k] = reader.ReadString();
				k = k + 1;
			}
			this.postSetFlagStr = reader.ReadString();
			this.postGoto = reader.ReadString();
			text2 = reader.ReadString();
			if (text2!= "")
			{
				this.giveScript = text2.Split(new char[]
				{
					'\r'
				});
				text2 = "";
				array = this.giveScript;
				l = 0;
				while (l < array.Length)
				{
					str = array[l];
					text2 = string.Concat(text2, str);
					l = l + 1;
				}
				this.giveScript = text2.Split(new char[]
				{
					'\n'
				});
			}
			else
			{
				this.giveScript = null;
			}
			text2 = reader.ReadString();
			if (text2!= "")
			{
				this.storeScript = text2.Split(new char[]
				{
					'\r'
				});
				text2 = "";
				array2 = this.storeScript;
				m = 0;
				while (m < array2.Length)
				{
					str2 = array2[m];
					text2 = string.Concat(text2, str2);
					m = m + 1;
				}
				this.storeScript = text2.Split(new char[]
				{
					'\n'
				});
				return;
			}
			this.storeScript = null;
		}

		// Token: 0x04000022 RID: 34
		private const int TOTAL_PRECHECKS = 4;

		// Token: 0x04000023 RID: 35
		public const int TOTAL_NODE_OPTIONS = 5;

		// Token: 0x04000024 RID: 36
		public string name;

		// Token: 0x04000025 RID: 37
		public TextSeries[] text;

		// Token: 0x04000026 RID: 38
		public NodeOption[] option;

		// Token: 0x04000027 RID: 39
		public string[] precheckFlagStr;

		// Token: 0x04000028 RID: 40
		public string[] precheckFlagGoto;

		// Token: 0x04000029 RID: 41
		public string postSetFlagStr;

		// Token: 0x0400002A RID: 42
		public string postGoto;

		// Token: 0x0400002B RID: 43
		public string[] giveScript;

		// Token: 0x0400002C RID: 44
		public string[] storeScript;
	}
}
