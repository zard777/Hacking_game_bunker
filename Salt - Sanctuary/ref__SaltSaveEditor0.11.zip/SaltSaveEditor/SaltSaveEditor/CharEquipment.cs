﻿using System;
using System.IO;
using System.Linq;

namespace SaltSaveEditor
{
	// Token: 0x0200004A RID: 74
	public class CharEquipment
	{
		// Token: 0x060001B3 RID: 435 RVA: 0x00026758 File Offset: 0x00024958
		public CharEquipment()
		{
			int i;
			int j;
			int k;
			int l;
			int m;
			this.helm.Reset();
			this.armor.Reset();
			this.gloves.Reset();
			this.boots.Reset();
			this.loadout = new CharEquipment.EquippedLoot[2, 3];
			i = 0;
			while (i < 2)
			{
				j = 0;
				while (j < 3)
				{
					this.loadout[i, j].Reset();
					j = j + 1;
				}
				i = i + 1;
			}
			this.twoHanded = new bool[2];
			this.consumable = new CharEquipment.EquippedLoot[6];
			k = 0;
			while (k < this.consumable.Length)
			{
				this.consumable[k].Reset();
				k = k + 1;
			}
			this.incantation = new CharEquipment.EquippedLoot[6];
			l = 0;
			while (l < this.incantation.Length)
			{
				this.incantation[l].Reset();
				l = l + 1;
			}
			this.ring = new CharEquipment.EquippedLoot[4];
			m = 0;
			while (m < this.ring.Length)
			{
				this.ring[m].Reset();
				m = m + 1;
			}
		}
        
		// Token: 0x060001C3 RID: 451 RVA: 0x00027DEC File Offset: 0x00025FEC
		internal void Write(BinaryWriter writer)
		{
			int i;
			int j;
			int k;
			int l;
			int m;
			int n;
			this.helm.Write(writer);
			this.armor.Write(writer);
			this.gloves.Write(writer);
			this.boots.Write(writer);
			i = 0;
			while (i < 2)
			{
				j = 0;
				while (j < 3)
				{
					this.loadout[i, j].Write(writer);
					j = j + 1;
				}
				i = i + 1;
			}
			k = 0;
			while (k < this.consumable.Length)
			{
				this.consumable[k].Write(writer);
				k = k + 1;
			}
			l = 0;
			while (l < this.incantation.Length)
			{
				this.incantation[l].Write(writer);
				l = l + 1;
			}
			m = 0;
			while (m < this.ring.Length)
			{
				this.ring[m].Write(writer);
				m = m + 1;
			}
			n = 0;
			while (n < 2)
			{
				writer.Write(this.twoHanded[n]);
				n = n + 1;
			}
			writer.Write(this.selConsumable);
			writer.Write(this.selIncantation);
			writer.Write(this.selectedUseRow);
			writer.Write(this.loadoutIdx);
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00027F18 File Offset: 0x00026118
		internal void Read(BinaryReader reader)
		{
			int i;
			int j;
			int k;
			int l;
			int m;
			int n;
			this.helm.Read(reader);
			this.armor.Read(reader);
			this.gloves.Read(reader);
			this.boots.Read(reader);
			i = 0;
			while (i < 2)
			{
				j = 0;
				while (j < 3)
				{
					this.loadout[i, j].Read(reader);
					j = j + 1;
				}
				i = i + 1;
			}
			k = 0;
			while (k < this.consumable.Length)
			{
				this.consumable[k].Read(reader);
				k = k + 1;
			}
			l = 0;
			while (l < this.incantation.Length)
			{
				this.incantation[l].Read(reader);
				l = l + 1;
			}
			m = 0;
			while (m < this.ring.Length)
			{
				this.ring[m].Read(reader);
				m = m + 1;
			}
			n = 0;
			while (n < 2)
			{
				this.twoHanded[n] = reader.ReadBoolean();
				n = n + 1;
			}
			this.selConsumable = reader.ReadInt32();
			this.selIncantation = reader.ReadInt32();
			this.selectedUseRow = reader.ReadInt32();
			this.loadoutIdx = reader.ReadInt32();
			this.usePickerConsumableInvIdx = -1;
		}

		
		// Token: 0x040006F7 RID: 1783
		public CharEquipment.EquippedLoot helm;

		// Token: 0x040006F8 RID: 1784
		public CharEquipment.EquippedLoot armor;

		// Token: 0x040006F9 RID: 1785
		public CharEquipment.EquippedLoot gloves;

		// Token: 0x040006FA RID: 1786
		public CharEquipment.EquippedLoot boots;

		// Token: 0x040006FB RID: 1787
		public CharEquipment.EquippedLoot[,] loadout;

		// Token: 0x040006FC RID: 1788
		public CharEquipment.EquippedLoot[] consumable;

		// Token: 0x040006FD RID: 1789
		public CharEquipment.EquippedLoot[] ring;

		// Token: 0x040006FE RID: 1790
		public CharEquipment.EquippedLoot[] incantation;

		// Token: 0x040006FF RID: 1791
		public int loadoutIdx;

		// Token: 0x04000700 RID: 1792
		public bool[] twoHanded;

		// Token: 0x04000701 RID: 1793
		public int selConsumable;

		// Token: 0x04000702 RID: 1794
		public int selIncantation;

		// Token: 0x04000703 RID: 1795
		public int selectedUseRow;

		// Token: 0x04000704 RID: 1796
		public int useConsumable;

		// Token: 0x04000705 RID: 1797
		public int useIncantation;

		// Token: 0x04000706 RID: 1798
		public int useUseRow;

		// Token: 0x04000707 RID: 1799
		public int usePickerConsumableInvIdx;

		// Token: 0x04000708 RID: 1800
		public int hair;

		// Token: 0x04000709 RID: 1801
		public int hairColor;

		// Token: 0x0400070A RID: 1802
		public int beard;

		// Token: 0x0400070B RID: 1803
		public int beardColor;

		// Token: 0x0400070C RID: 1804
		public int skinIdx;

		// Token: 0x0400070D RID: 1805
		public int skinClass;

		// Token: 0x0400070E RID: 1806
		public int eyeColor;

		// Token: 0x0400070F RID: 1807
		public bool active;

		// Token: 0x04000710 RID: 1808
		public int propCreed;

		// Token: 0x0200004B RID: 75
		public struct EquippedLoot
		{
			// Token: 0x060001CA RID: 458 RVA: 0x00028AA7 File Offset: 0x00026CA7
			public void Reset()
			{
				this.catalogIdx = -1;
				this.category = -1;
				this.invIdx = -1;
			}

			// Token: 0x060001CF RID: 463 RVA: 0x00028EC0 File Offset: 0x000270C0
			internal void Write(BinaryWriter writer)
			{
				writer.Write(this.catalogIdx);
				writer.Write(this.category);
				writer.Write(this.invIdx);
			}

			// Token: 0x060001D0 RID: 464 RVA: 0x00028EE6 File Offset: 0x000270E6
			internal void Read(BinaryReader reader)
			{
				this.catalogIdx = reader.ReadInt32();
				this.category = reader.ReadInt32();
				this.invIdx = reader.ReadInt32();
             /*   if(invIdx >= 0 && category >= 0)
                    Console.WriteLine(Game1.lootCatalog.category[category].loot[catalogIdx].title[0] + " " + Game1.lootCatalog.category[category].loot[catalogIdx].desc[0]);*/
			}

			// Token: 0x060001D1 RID: 465 RVA: 0x00028F0C File Offset: 0x0002710C
			internal void CopyFrom(CharEquipment.EquippedLoot equippedLoot)
			{
				this.invIdx = equippedLoot.invIdx;
				this.catalogIdx = equippedLoot.catalogIdx;
				this.category = equippedLoot.category;
			}

			// Token: 0x04000711 RID: 1809
			public int catalogIdx;

			// Token: 0x04000712 RID: 1810
			public int category;

			// Token: 0x04000713 RID: 1811
			public int invIdx;
		}
	}
}
