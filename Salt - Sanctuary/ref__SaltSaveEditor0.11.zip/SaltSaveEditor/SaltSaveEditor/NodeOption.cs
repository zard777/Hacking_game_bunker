﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x0200000E RID: 14
	public class NodeOption
	{
		// Token: 0x06000041 RID: 65 RVA: 0x00003534 File Offset: 0x00001734
		public NodeOption()
		{
			int i;
			this.text = new string[7];
			i = 0;
			while (i < this.text.Length)
			{
				this.text[i] = "";
				i = i + 1;
			}
			this.action = "";
			this.coopAction = "";
		}

		// Token: 0x06000042 RID: 66 RVA: 0x0000358C File Offset: 0x0000178C
		public NodeOption(NodeOption nodeOption)
		{
			int i;
			this.text = new string[nodeOption.text.Length];
			i = 0;
			while (i < this.text.Length)
			{
				this.text[i] = nodeOption.text[i];
				i = i + 1;
			}
			this.action = nodeOption.action;
			this.coopAction = nodeOption.coopAction;
		}

		// Token: 0x06000043 RID: 67 RVA: 0x000035F0 File Offset: 0x000017F0
		internal void Write(BinaryWriter writer)
		{
			int i;
			i = 0;
			while (i < this.text.Length)
			{
				writer.Write(this.text[i]);
				i = i + 1;
			}
			writer.Write(this.action);
			writer.Write(this.coopAction);
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00003638 File Offset: 0x00001838
		internal void Read(BinaryReader reader)
		{
			int i;
			i = 0;
			while (i < this.text.Length)
			{
				this.text[i] = reader.ReadString();
				i = i + 1;
			}
			this.action = reader.ReadString();
			this.coopAction = reader.ReadString();
		}

		// Token: 0x0400002D RID: 45
		public string[] text;

		// Token: 0x0400002E RID: 46
		public string action;

		// Token: 0x0400002F RID: 47
		public string coopAction;
	}
}
