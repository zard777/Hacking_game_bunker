﻿using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x02000188 RID: 392
	internal class ChallengeCatHardcoreMode : ChallengeCategory
	{
		// Token: 0x060007D6 RID: 2006 RVA: 0x000B67C0 File Offset: 0x000B49C0
		public ChallengeCatHardcoreMode(Player p)
		{
			this.itemStr = new StringBuilder[]
			{
				new StringBuilder(LocStrings.GetLocStr(425))
			};
			base.Init(p);
		}

		// Token: 0x0400121F RID: 4639
		public const int HARDCORE = 0;

		// Token: 0x04001220 RID: 4640
		public const string HARDCORE_STR = "_#_DED4EVAR_#_";
	}
}
