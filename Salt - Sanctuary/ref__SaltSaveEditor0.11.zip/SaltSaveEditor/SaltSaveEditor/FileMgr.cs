﻿using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x020000A6 RID: 166
	public class FileMgr
	{
		// Token: 0x0600041A RID: 1050 RVA: 0x000758B4 File Offset: 0x00073AB4
		public static void Open(string path)
		{
			FileMgr.reader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x000758C8 File Offset: 0x00073AC8
		public static void Close()
		{
			FileMgr.reader.Close();
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x000758D4 File Offset: 0x00073AD4
		public FileMgr()
		{
		}

		// Token: 0x04001028 RID: 4136
		public static BinaryReader reader;
	}
}
