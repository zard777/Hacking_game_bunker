﻿using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200018B RID: 395
	internal class ChallengeCatShield : ChallengeCategory
	{
		// Token: 0x060007D9 RID: 2009 RVA: 0x000B6898 File Offset: 0x000B4A98
		public ChallengeCatShield(Player p)
		{
			this.itemStr = new StringBuilder[]
			{
				new StringBuilder(LocStrings.GetLocStr(430))
			};
			base.Init(p);
		}

		// Token: 0x04001225 RID: 4645
		public const int NO_BLOCKING = 0;
	}
}
