﻿using System.Text;
using System.IO;

namespace SaltSaveEditor
{
	// Token: 0x02000214 RID: 532
	public class PlayerStats
	{
		// Token: 0x06000AFC RID: 2812 RVA: 0x0010B2E4 File Offset: 0x001094E4
		public static void Init()
		{
			PlayerStats.strs = new StringBuilder[]
			{
				new StringBuilder(""),
				LocStrings.GetLocString(159),
				LocStrings.GetLocString(160),
				LocStrings.GetLocString(161),
				LocStrings.GetLocString(162),
				LocStrings.GetLocString(163),
				LocStrings.GetLocString(164),
				LocStrings.GetLocString(165),
				LocStrings.GetLocString(166),
				LocStrings.GetLocString(167),
				LocStrings.GetLocString(168),
				LocStrings.GetLocString(169),
				LocStrings.GetLocString(170),
				LocStrings.GetLocString(171),
				LocStrings.GetLocString(172),
				LocStrings.GetLocString(173),
				LocStrings.GetLocString(174),
				LocStrings.GetLocString(175),
				LocStrings.GetLocString(176),
				LocStrings.GetLocString(177),
				LocStrings.GetLocString(178),
				LocStrings.GetLocString(179),
				LocStrings.GetLocString(180),
				LocStrings.GetLocString(181),
				LocStrings.GetLocString(182),
				LocStrings.GetLocString(183),
				LocStrings.GetLocString(184),
				LocStrings.GetLocString(185),
				LocStrings.GetLocString(186),
				LocStrings.GetLocString(187),
				new StringBuilder(string.Concat('ȿ', " ", LocStrings.GetLocStr(188))),
				new StringBuilder(string.Concat('ȿ', " ", LocStrings.GetLocStr(189))),
				new StringBuilder(string.Concat('ȿ', " ", LocStrings.GetLocStr(190))),
				LocStrings.GetLocString(191),
				LocStrings.GetLocString(192),
				LocStrings.GetLocString(193),
				LocStrings.GetLocString(194),
				LocStrings.GetLocString(195),
				LocStrings.GetLocString(196),
				LocStrings.GetLocString(197),
				LocStrings.GetLocString(198),
				LocStrings.GetLocString(199),
				LocStrings.GetLocString(200),
				LocStrings.GetLocString(201),
				LocStrings.GetLocString(202),
				LocStrings.GetLocString(203),
				LocStrings.GetLocString(204),
				LocStrings.GetLocString(205)
			};
		}

		// Token: 0x06000AFD RID: 2813 RVA: 0x0010B5E1 File Offset: 0x001097E1
		public PlayerStats(Player p)
		{
			this.p = p;
			this.Reset();
		}

		// Token: 0x06000AFE RID: 2814 RVA: 0x0010B5F8 File Offset: 0x001097F8
		public void Reset()
		{
			int i;
			this.level = 1;
			this.treeUnlocks = new int[500];
			this.itemClass = new int[30];
			this.classUnlocks = new int[2];
			this.stat = new int[6];
			i = 0;
			while (i < this.stat.Length)
			{
				this.stat[i] = 10;
				i = i + 1;
			}
			this.pageAlpha = new float[3];
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x0010E384 File Offset: 0x0010C584
		internal void Write(BinaryWriter writer)
		{
			int i;
			int j;
			int k;
			writer.Write(this.level);
			i = 0;
			while (i < 30)
			{
				writer.Write(this.itemClass[i]);
				i = i + 1;
			}
			j = 0;
			while (j < 500)
			{
				writer.Write(this.treeUnlocks[j]);
				j = j + 1;
			}
			k = 0;
			while (k < 2)
			{
				writer.Write(this.classUnlocks[k]);
				k = k + 1;
			}
		}

		// Token: 0x06000B0E RID: 2830 RVA: 0x0010E450 File Offset: 0x0010C650
		public void UpdateStats()
		{
			int i;
			int j;
			int k;
			SkillNode skillNode;
			i = 0;
			while (i < this.stat.Length)
			{
				this.stat[i] = 5;
				i = i + 1;
			}
			j = 0;
			while (j < this.itemClass.Length)
			{
				this.itemClass[j] = 0;
				j = j + 1;
			}
			k = 0;
			while (k < SkillTree.nodes.Length)
			{
				if (!(this.treeUnlocks[k] <= 0 && this.classUnlocks[0] != k && this.classUnlocks[1] != k))
				{
					skillNode = SkillTree.nodes[k];
					if (!(skillNode.img <= -1))
					{
						switch (skillNode.type)
						{
						case 0:
						case 1:
						case 2:
						case 3:
						case 4:
						case 5:
						case 6:
						case 7:
						case 8:
						case 9:
						case 10:
						case 11:
						case 12:
						case 13:
						case 14:
						case 15:
						case 16:
						case 25:
						case 26:
						case 27:
						case 28:
						{
							if (!(skillNode.value <= this.itemClass[skillNode.type]))
							{
								this.itemClass[skillNode.type] = skillNode.value;
							}
							switch (skillNode.type)
							{
							case 0:
							case 1:
							case 2:
							case 6:
							case 7:
							case 8:
							{
								this.stat[0] += skillNode.value;
								break;
							}
							case 3:
							case 4:
							case 5:
							case 9:
							{
								this.stat[3] += skillNode.value;
								break;
							}
							case 10:
							case 26:
							case 27:
							{
								this.stat[4] += skillNode.value;
								break;
							}
							case 11:
							case 12:
							case 13:
							case 14:
							case 15:
							{
								this.stat[2] += skillNode.value;
								break;
							}
							case 16:
							case 28:
							{
								this.stat[1] += skillNode.value;
								break;
							}
							case 25:
							{
								this.stat[5] += skillNode.value;
								break;
							}
							}
							break;
						}
						case 17:
						{
							this.stat[0] += ((skillNode.value > 1) ? skillNode.value : this.treeUnlocks[k]);
							break;
						}
						case 18:
						{
							this.stat[2] += ((skillNode.value > 1) ? skillNode.value : this.treeUnlocks[k]);
							break;
						}
						case 19:
						{
							this.stat[4] += ((skillNode.value > 1) ? skillNode.value : this.treeUnlocks[k]);
							break;
						}
						case 20:
						{
							this.stat[5] += ((skillNode.value > 1) ? skillNode.value : this.treeUnlocks[k]);
							break;
						}
						case 21:
						{
							this.stat[1] += ((skillNode.value > 1) ? skillNode.value : this.treeUnlocks[k]);
							break;
						}
						case 22:
						{
							this.stat[3] += ((skillNode.value > 1) ? skillNode.value : this.treeUnlocks[k]);
							break;
						}
						case 23:
						case 24:
						{
							this.itemClass[skillNode.type] += skillNode.value;
							break;
						}
						}
					}
				}
				k = k + 1;
			}
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x0010E850 File Offset: 0x0010CA50
		internal void Read(BinaryReader reader)
		{
			int i;
			int j;
			int k;
			this.level = reader.ReadInt32();
			i = 0;
			while (i < 30)
			{
				this.itemClass[i] = reader.ReadInt32();
				i = i + 1;
			}
			j = 0;
			while (j < 500)
			{
				this.treeUnlocks[j] = reader.ReadInt32();
				j = j + 1;
			}
			k = 0;
			while (k < 2)
			{
				this.classUnlocks[k] = reader.ReadInt32();
				k = k + 1;
			}
			this.UpdateStats();
		}

		// Token: 0x04001973 RID: 6515
		public const int STAT_STR = 0;

		// Token: 0x04001974 RID: 6516
		public const int STAT_END = 1;

		// Token: 0x04001975 RID: 6517
		public const int STAT_DEX = 2;

		// Token: 0x04001976 RID: 6518
		public const int STAT_WILL = 3;

		// Token: 0x04001977 RID: 6519
		public const int STAT_MAG = 4;

		// Token: 0x04001978 RID: 6520
		public const int STAT_WIS = 5;

		// Token: 0x04001979 RID: 6521
		public const int TOTAL_STATS = 6;

		// Token: 0x0400197A RID: 6522
		public const int STAT_ITEM_FIND = 99;

		// Token: 0x0400197B RID: 6523
		public const int STR_NAME = 0;

		// Token: 0x0400197C RID: 6524
		public const int STR_LEVEL = 1;

		// Token: 0x0400197D RID: 6525
		public const int STR_EQUIP = 2;

		// Token: 0x0400197E RID: 6526
		public const int STR_VITALITY = 3;

		// Token: 0x0400197F RID: 6527
		public const int STR_STRENGTH = 4;

		// Token: 0x04001980 RID: 6528
		public const int STR_STAMINA = 5;

		// Token: 0x04001981 RID: 6529
		public const int STR_DEXTERITY = 6;

		// Token: 0x04001982 RID: 6530
		public const int STR_MAGIC = 7;

		// Token: 0x04001983 RID: 6531
		public const int STR_WISDOM = 8;

		// Token: 0x04001984 RID: 6532
		public const int STR_EQUIP_L = 9;

		// Token: 0x04001985 RID: 6533
		public const int STR_EQUIP_M = 10;

		// Token: 0x04001986 RID: 6534
		public const int STR_EQUIP_H = 11;

		// Token: 0x04001987 RID: 6535
		public const int STR_EQUIP_O = 12;

		// Token: 0x04001988 RID: 6536
		public const int STR_PHYS_DEF = 13;

		// Token: 0x04001989 RID: 6537
		public const int STR_FIRE_DEF = 14;

		// Token: 0x0400198A RID: 6538
		public const int STR_LIT_DEF = 15;

		// Token: 0x0400198B RID: 6539
		public const int STR_BLADED_DEF = 16;

		// Token: 0x0400198C RID: 6540
		public const int STR_POISON_DEF = 17;

		// Token: 0x0400198D RID: 6541
		public const int STR_HOLY_DEF = 18;

		// Token: 0x0400198E RID: 6542
		public const int STR_DARK_DEF = 19;

		// Token: 0x0400198F RID: 6543
		public const int STR_POISE = 20;

		// Token: 0x04001990 RID: 6544
		public const int STR_ATTACK = 21;

		// Token: 0x04001991 RID: 6545
		public const int STR_SALT_COST = 22;

		// Token: 0x04001992 RID: 6546
		public const int STR_SALT_AVAIL = 23;

		// Token: 0x04001993 RID: 6547
		public const int STR_MAX_HP = 24;

		// Token: 0x04001994 RID: 6548
		public const int STR_MAX_MP = 25;

		// Token: 0x04001995 RID: 6549
		public const int STR_MAX_SP = 26;

		// Token: 0x04001996 RID: 6550
		public const int STR_SPIRIT = 27;

		// Token: 0x04001997 RID: 6551
		public const int STR_ENDURANCE = 28;

		// Token: 0x04001998 RID: 6552
		public const int STR_WILL = 29;

		// Token: 0x04001999 RID: 6553
		public const int STR_MAIN = 30;

		// Token: 0x0400199A RID: 6554
		public const int STR_STATS = 31;

		// Token: 0x0400199B RID: 6555
		public const int STR_DEFENSE = 32;

		// Token: 0x0400199C RID: 6556
		public const int STR_CREED = 33;

		// Token: 0x0400199D RID: 6557
		public const int STR_CREED_NONE = 34;

		// Token: 0x0400199E RID: 6558
		public const int STR_CREED_IRON = 35;

		// Token: 0x0400199F RID: 6559
		public const int STR_CREED_CLERIC = 36;

		// Token: 0x040019A0 RID: 6560
		public const int STR_CREED_THREE = 37;

		// Token: 0x040019A1 RID: 6561
		public const int STR_CREED_WOODS = 38;

		// Token: 0x040019A2 RID: 6562
		public const int STR_CREED_DARK = 39;

		// Token: 0x040019A3 RID: 6563
		public const int STR_CREED_SPLENDOR = 40;

		// Token: 0x040019A4 RID: 6564
		public const int STR_CREED_FOOL = 41;

		// Token: 0x040019A5 RID: 6565
		public const int STR_CREED_FIRE = 42;

		// Token: 0x040019A6 RID: 6566
		public const int STR_CREED_BONES = 43;

		// Token: 0x040019A7 RID: 6567
		public const int STR_DROP_RATE = 44;

		// Token: 0x040019A8 RID: 6568
		public const int STR_ARDOR_LEVEL = 45;

		// Token: 0x040019A9 RID: 6569
		public const int STR_LV = 46;

		// Token: 0x040019AA RID: 6570
		public const int STR_PR = 47;

		// Token: 0x040019AB RID: 6571
		public const float STAT_CAP = 50f;

		// Token: 0x040019AC RID: 6572
		private const int PAGE_MAIN = 0;

		// Token: 0x040019AD RID: 6573
		private const int PAGE_STATS = 1;

		// Token: 0x040019AE RID: 6574
		private const int PAGE_DEF = 2;

		// Token: 0x040019AF RID: 6575
		private const int TOTAL_PAGES = 3;

		// Token: 0x040019B0 RID: 6576
		public const int MAX_TREE_UNLOCKS = 500;

		// Token: 0x040019B1 RID: 6577
		public const int TOTAL_ITEM_CLASSES = 30;

		// Token: 0x040019B2 RID: 6578
		public const int TOTAL_CLASS_UNLOCKS = 2;

		// Token: 0x040019B3 RID: 6579
		public bool active;

		// Token: 0x040019B4 RID: 6580
		public float alpha;

		// Token: 0x040019B5 RID: 6581
		public int level;

		// Token: 0x040019B6 RID: 6582
		public int[] stat;

		// Token: 0x040019B7 RID: 6583
		public float[] pageAlpha;

		// Token: 0x040019B8 RID: 6584
		public int page;

		// Token: 0x040019B9 RID: 6585
		public bool percentMode;

		// Token: 0x040019BA RID: 6586
		private float percentAlpha;

		// Token: 0x040019BB RID: 6587
		public static StringBuilder[] strs;

		// Token: 0x040019BC RID: 6588
		public int[] treeUnlocks;

		// Token: 0x040019BD RID: 6589
		public int[] classUnlocks;

		// Token: 0x040019BE RID: 6590
		public int[] itemClass;

		// Token: 0x040019BF RID: 6591
		private Player p;
	}
}
