﻿using System.Text;

namespace SaltSaveEditor
{
	// Token: 0x0200018A RID: 394
	internal class ChallengeCatArmor : ChallengeCategory
	{
		// Token: 0x060007D8 RID: 2008 RVA: 0x000B685C File Offset: 0x000B4A5C
		public ChallengeCatArmor(Player p)
		{
			this.itemStr = new StringBuilder[]
			{
				new StringBuilder(LocStrings.GetLocStr(424))
			};
			base.Init(p);
		}

		// Token: 0x04001224 RID: 4644
		public const int NAKED = 0;
	}
}
